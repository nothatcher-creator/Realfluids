# Real Fluids (Fabric 1.20.1)

Real fluid simulation for Minecraft buckets. Hold a bucket, press **Z**, and design a fluid: colour, cloudiness, foam, thickness, density, gravity, splashiness, stickiness, heat and glow. Then pour it. It flows, splashes, pools in holes, runs down stairs and slabs, stacks oil on water, and you can swim in it, float in it, or get stuck in honey.

This is a true 3D **FLIP** fluid solver (the method used in film and game VFX), not block-based flowing water.

## Install
1. Fabric Loader 0.14.21+ (tested setup: 0.16.9) and **Fabric API** for 1.20.1.
2. Drop `realfluids-1.0.0+mc1.20.1.jar` into `mods/`.
3. Singleplayer works straight away. On a server, install it on the server **and** on every client.

## Controls
| Action | How |
|---|---|
| Open the bucket editor | Hold an empty, water or lava bucket in your main hand, press **Z** (rebind in Controls → Real Fluids) |
| Pour | Right-click with the real-fluid bucket |
| Scoop | Right-click simulated fluid with an empty bucket (it keeps that fluid's properties) |
| Back to vanilla | Editor → **Vanilla bucket** |
| Commands | `/realfluids stats`, `clear`, `pause`, `resume`, `quality low|medium|high` |

On Android launchers (Pojav/Zalith/Fold Craft), add a touch button mapped to **Z** in the control editor.

## What the settings do
- **Presets**: Water, Ocean, Swamp, Honey, Slime, Oil, Milk, Mercury, Lava.
- **Look**: name, RGB colour, cloudiness (0 = glass clear, 1 = solid colour), foam (white water), glows (full bright).
- **Physics**:
  - Thickness: viscosity, from water to tar. Thick fluids hold their shape and creep.
  - Density: lighter fluids float on heavier ones. You float in anything denser than about 1,010 kg/m³.
  - Gravity: a multiplier on how hard the fluid falls.
  - Splashiness: lively splashes or calm, damped flow.
  - Stickiness: surface tension. It rounds droplets and holds puddles together.
  - Hot: sets players on fire (stepping into normal water puts it out).
- **Pour**: amount (0.25–128 blocks), shape (cube, sphere, column, sheet), and how it comes out:
  - all at once
  - a stream from the bucket
  - a fountain upward, with jet speed and duration

## How it works
- **Simulation:** particles carry the fluid on a MAC grid, with an incomplete-Cholesky preconditioned pressure solve.
  - Implicit viscosity, with a yield stress so honey and lava heap up.
  - Buoyancy and drift between fluids of different density.
  - Cohesion, foam, evaporation of stray films, and sleeping once the fluid settles.
- **Terrain:** read per cell from real collision shapes, so slabs, stairs, fences and walls all work. Unloaded chunks count as walls. Fluid that flows into vanilla water or lava is absorbed into it (configurable).
- **Surface:** a smooth mesh (Surface Nets) shaded per vertex with Fresnel sky reflection, sun and moon glints, foam and clarity. It is drawn with vanilla's own position/colour shader, so no custom GLSL is needed and it runs on phones.
- **Threading:**
  - The solver runs on its own background thread, so a slow CPU slows the water down, not your frame rate.
  - The GPU buffer is only rebuilt when the fluid or the camera moves.
- **Multiplayer:** the server owns the buckets. It validates every pour and scoop, then tells all nearby players to simulate the same pour.
- **Saving:** fluid is saved when you leave (`.minecraft/realfluids/<world>.rfld.gz`) and restored once the terrain has loaded.

## Configuration
`config/realfluids.json` is created on first launch. Usually you only need `quality`:

| quality | cell size | particles per region | for |
|---|---|---|---|
| low | 1 block | 15,000 | older phones |
| medium | ½ block | 40,000 | default |
| high | ⅓ block | 90,000 | gaming PCs |

Other fields:
- `regionWidth` / `regionHeight`: the simulated box around a pour (24 × 20 blocks).
- `maxRegions`: 4 per dimension.
- `simulationHz`, `maxQuads`, `renderSpray`, `playerPhysics`, `absorbIntoVanillaWater`, `evaporateSeconds`, `saveWithWorld`, `simulateDistance`.

See [docs/TESTING.md](docs/TESTING.md) for the in-game checklist and [docs/COMPATIBILITY.md](docs/COMPATIBILITY.md) for Sodium/Iris/Android notes and known limits.

## Building
GitHub Actions builds the jar on every push (`.github/workflows/build.yml`). Get it from the run's **realfluids-mod** artifact. The workflow also:
- runs the engine test suite
- renders preview images

Locally: `gradle build` (Gradle 8.8+, Java 17).

On a phone without Gradle, in Termux run `sh tools/stubcheck/run.sh`. It compiles the whole mod against API stubs in seconds. Pass Yarn and Fabric API checkouts to also verify every API name.

Engine only, no Minecraft needed:
```
javac -d out src/main/java/net/realfluids/sim/*.java tools/SimTests.java tools/FluidPreview.java
java -cp out SimTests          # physics + mesh + save-file tests
java -cp out FluidPreview .    # renders preview PNGs offline
```

## License
MIT

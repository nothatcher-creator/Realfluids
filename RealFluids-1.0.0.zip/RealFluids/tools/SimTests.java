import net.realfluids.sim.FluidDomain;
import net.realfluids.sim.FluidProps;
import net.realfluids.sim.SurfaceMesher;

import java.util.Map;

/**
 * Headless physics tests for the solver (no Minecraft needed).
 *   javac -d out src/main/java/net/realfluids/sim/*.java tools/SimTests.java && java -cp out SimTests
 */
public class SimTests {
    static int checks, failed;
    static String test;

    static void check(boolean ok, String what) {
        checks++;
        if (!ok) { failed++; System.out.println("  FAIL [" + test + "] " + what); }
    }

    static void run(String name, Runnable r) {
        test = name;
        int before = failed;
        long t0 = System.nanoTime();
        r.run();
        System.out.printf("%s %s (%.0f ms)%n", failed == before ? "[ OK ]" : "[FAIL]", name, (System.nanoTime() - t0) / 1e6);
    }

    /** Box domain with a solid floor (row j=0) and optional extra solid cells. */
    static FluidDomain box(int nx, int ny, int nz, float h) {
        FluidDomain d = new FluidDomain(0, 0, 0, nx, ny, nz, h, 8, 200000, 42);
        byte[] m = new byte[nx * ny * nz];
        for (int k = 0; k < nz; k++) for (int i = 0; i < nx; i++) m[i + nx * (0 + ny * k)] = FluidDomain.SOLID;
        d.setWorld(m);
        return d;
    }

    static double meanY(FluidDomain d) {
        double s = 0; for (int n = 0; n < d.particleCount(); n++) s += d.py()[n];
        return d.particleCount() == 0 ? 0 : s / d.particleCount();
    }

    static double maxY(FluidDomain d) {
        double m = 0; for (int n = 0; n < d.particleCount(); n++) m = Math.max(m, d.py()[n]);
        return m;
    }

    static boolean anyInSolid(FluidDomain d) {
        for (int n = 0; n < d.particleCount(); n++)
            if (d.worldSolid((int) d.px()[n], (int) d.py()[n], (int) d.pz()[n])) return true;
        return false;
    }

    static void simulate(FluidDomain d, float seconds) {
        for (float t = 0; t < seconds; t += 0.05f) d.step(0.05f, 4);
    }

    public static void main(String[] args) {
        run("props round trip + sanitize", () -> {
            FluidProps p = FluidProps.preset("honey");
            Map<String, Object> m = p.toMap();
            FluidProps q = FluidProps.fromMap(m);
            check(q.name.equals("Honey") && Math.abs(q.viscosity - p.viscosity) < 1e-6 && q.color == p.color, "round trip");
            FluidProps bad = new FluidProps();
            bad.viscosity = Float.NaN; bad.volume = 1e9f; bad.density = -5; bad.name = null;
            bad.sanitize();
            check(bad.viscosity == 0f && bad.volume == 512f && bad.density == 50f && bad.name.equals("Custom"), "sanitize");
            check(FluidProps.preset("water").kinematicViscosity() == 0f, "water inviscid");
            check(FluidProps.preset("lava").kinematicViscosity() > 0.5f, "lava thick");
            check(Math.abs(FluidProps.sliderFromKinematic(FluidProps.preset("honey").kinematicViscosity()) - 0.85f) < 1e-3f, "slider inverse");
            for (String id : FluidProps.PRESETS) check(FluidProps.preset(id).name.equalsIgnoreCase(id), "preset " + id);
        });

        run("dam break conserves fluid and settles flat", () -> {
            FluidDomain d = box(32, 24, 24, 0.5f);
            FluidProps p = FluidProps.preset("water");
            p.volume = 8 * 10 * 24 * 0.125f; // 8x10x24 cells
            // fill a column against the -x wall
            int made = 0;
            for (int k = 0; k < 24; k++) for (int j = 1; j < 11; j++) for (int i = 0; i < 8; i++)
                for (int s = 0; s < 8; s++) made += d.addParticle(i + (s & 1) * 0.5f + 0.25f, j + ((s >> 1) & 1) * 0.5f + 0.25f, k + ((s >> 2) & 1) * 0.5f + 0.25f, 0, 0, 0, p) ? 1 : 0;
            int start = d.particleCount();
            check(made == 8 * 10 * 24 * 8, "seeded " + made);
            double y0 = meanY(d);
            simulate(d, 1.0f);
            check(d.lastPcgResidual < 0.01f, "pressure solve converged (residual " + d.lastPcgResidual + ", " + d.lastPcgIterations + " its)");
            simulate(d, 19.0f);
            check(d.particleCount() == start, "particle count conserved " + d.particleCount() + "/" + start);
            check(!anyInSolid(d), "no particles inside the floor");
            // final depth: 8 of 32 columns filled 10 high -> 2.5 cells deep -> mean y ~ 1 + 1.25
            double my = meanY(d);
            System.out.printf("    mean y %.2f -> %.2f cells, max y %.2f, max speed %.2f cells/s, pcg %d its%n", y0, my, maxY(d), d.lastMaxSpeed, d.lastPcgIterations);
            check(my < y0 - 2.0, "collapsed (mean height dropped)");
            check(my > 1.6 && my < 3.2, "settled to a plausible depth");
            double ms = 0; for (int n = 0; n < d.particleCount(); n++) ms += Math.sqrt(d.vx()[n] * d.vx()[n] + d.vy()[n] * d.vy()[n] + d.vz()[n] * d.vz()[n]);
            ms /= d.particleCount();
            System.out.printf("    mean speed %.3f cells/s%n", ms);
            check(ms < 0.1, "nearly at rest after 20 s");
            simulate(d, 25f);
            check(d.isSleeping(), "goes to sleep once settled (mean " + d.lastMeanSpeed + ", max " + d.lastMaxSpeed + ")");
            d.addImpulse(4, 1, 4, 1.5, 0, -3, 0, 1f);
            d.step(0.05f, 4);
            check(!d.isSleeping(), "wakes when disturbed");
        });

        run("cup holds water (no leaks through walls)", () -> {
            int nx = 24, ny = 24, nz = 24;
            FluidDomain d = new FluidDomain(0, 0, 0, nx, ny, nz, 0.5f, 8, 200000, 7);
            byte[] m = new byte[nx * ny * nz];
            // cup: floor at j=4, walls 8..15 in x/z, height to j=12
            for (int k = 8; k <= 15; k++) for (int i = 8; i <= 15; i++) m[i + nx * (4 + ny * k)] = FluidDomain.SOLID;
            for (int j = 4; j <= 12; j++) for (int t = 8; t <= 15; t++) {
                m[8 + nx * (j + ny * t)] = FluidDomain.SOLID; m[15 + nx * (j + ny * t)] = FluidDomain.SOLID;
                m[t + nx * (j + ny * 8)] = FluidDomain.SOLID; m[t + nx * (j + ny * 15)] = FluidDomain.SOLID;
            }
            d.setWorld(m);
            FluidProps p = FluidProps.preset("water");
            p.volume = 3f; p.shape = FluidProps.Shape.CUBE;
            d.spawn(6.0, 9.0, 6.0, 0, 0, 0, p); // centre of the cup, in blocks
            int start = d.particleCount();
            simulate(d, 6f);
            int outside = 0;
            for (int n = 0; n < d.particleCount(); n++) {
                float x = d.px()[n], y = d.py()[n], z = d.pz()[n];
                if (x < 9 || x > 15 || z < 9 || z > 15 || y < 5) outside++;
            }
            System.out.printf("    %d particles, %d outside the cup%n", d.particleCount(), outside);
            check(start > 0 && d.particleCount() == start, "conserved");
            check(outside == 0, "nothing escaped the cup");
            check(!anyInSolid(d), "no particles inside walls");
        });

        run("oil floats on water", () -> {
            FluidDomain d = box(8, 40, 8, 0.5f);      // 4x4-block shaft so the layers are several cells thick
            FluidProps water = FluidProps.preset("water"); water.volume = 24f;
            FluidProps oil = FluidProps.preset("oil"); oil.volume = 10f; oil.viscosity = 0.05f;
            d.spawn(2, 0.5, 2, 0, 0, 0, oil);   // oil at the bottom first
            d.spawn(2, 4.0, 2, 0, 0, 0, water); // water dropped on top
            simulate(d, 15f);
            double oilY = 0, waterY = 0; int no = 0, nw = 0;
            for (int n = 0; n < d.particleCount(); n++) {
                if ((d.colors()[n] & 0xFFFFFF) == oil.color) { oilY += d.py()[n]; no++; } else { waterY += d.py()[n]; nw++; }
            }
            oilY /= Math.max(1, no); waterY /= Math.max(1, nw);
            System.out.printf("    oil mean y %.2f, water mean y %.2f (cells)%n", oilY, waterY);
            check(no > 0 && nw > 0, "both present");
            check(oilY > waterY + 1.0, "lighter oil ends up above water");
        });

        run("viscous fluid spreads slower than water", () -> {
            double[] spread = new double[2];
            String[] ids = { "water", "honey" };
            for (int t = 0; t < 2; t++) {
                FluidDomain d = box(40, 16, 40, 0.5f);
                FluidProps p = FluidProps.preset(ids[t]); p.volume = 4f;
                d.spawn(10, 1.0, 10, 0, 0, 0, p);
                simulate(d, 1.5f);
                double s = 0;
                for (int n = 0; n < d.particleCount(); n++) s += Math.hypot(d.px()[n] - 20, d.pz()[n] - 20);
                spread[t] = s / d.particleCount();
            }
            System.out.printf("    mean radius after 1.5 s: water %.2f cells, honey %.2f cells%n", spread[0], spread[1]);
            check(spread[1] < spread[0] * 0.85, "honey stays more compact");
        });

        run("sinks absorb, emitters emit the requested volume", () -> {
            FluidDomain d = box(20, 20, 20, 0.5f);
            FluidProps p = FluidProps.preset("water");
            p.mode = FluidProps.Mode.STREAM; p.volume = 2f; p.duration = 1f; p.speed = 3f;
            d.spawn(5, 6, 5, 1, 0, 0, p);
            simulate(d, 1.5f);
            double vol = d.totalVolumeBlocks();
            System.out.printf("    streamed %.2f blocks (asked 2.0)%n", vol);
            check(Math.abs(vol - 2.0) < 0.3, "stream volume");
            check(d.emitterCount() == 0, "emitter finished");
            byte[] m = d.worldMask().clone();
            for (int k = 0; k < 20; k++) for (int i = 0; i < 20; i++) m[i + 20 * (1 + 20 * k)] = FluidDomain.SINK;
            d.setWorld(m);
            simulate(d, 3f);
            check(d.particleCount() < 50, "sink drained the fluid (" + d.particleCount() + " left)");
        });

        run("scooping returns the mix", () -> {
            FluidDomain d = box(16, 16, 16, 0.5f);
            FluidProps p = FluidProps.preset("slime"); p.volume = 2f;
            d.spawn(4, 1.0, 4, 0, 0, 0, p);
            var r = d.remove(4, 1.0, 4, 3.0, 100000);
            FluidProps back = r.toProps(null);
            check(r.removed > 0, "removed some");
            check(back.color == p.color, "colour preserved");
            check(Math.abs(back.viscosity - p.viscosity) < 0.02f, "viscosity preserved " + back.viscosity);
            check(Math.abs(r.volume(d) - 2f) < 0.3f, "volume ~2 blocks: " + r.volume(d));
        });

        run("blocks placed into fluid push it out", () -> {
            FluidDomain d = box(16, 16, 16, 0.5f);
            FluidProps p = FluidProps.preset("water"); p.volume = 2f;
            d.spawn(4, 1.0, 4, 0, 0, 0, p);
            simulate(d, 2f);
            byte[] m = d.worldMask().clone();
            for (int k = 0; k < 16; k++) for (int i = 0; i < 16; i++) m[i + 16 * (1 + 16 * k)] = FluidDomain.SOLID; // raise the floor
            d.setWorld(m);
            simulate(d, 2f);
            check(!anyInSolid(d), "nothing left inside the new blocks");
            check(d.particleCount() > 0, "fluid survived");
        });

        run("surface mesh is closed, smooth and faces outward", () -> {
            FluidDomain d = box(24, 16, 24, 0.5f);
            FluidProps p = FluidProps.preset("water"); p.volume = 0;
            for (int k = 0; k < 24; k++) for (int j = 1; j < 7; j++) for (int i = 0; i < 24; i++)
                for (int s = 0; s < 8; s++) d.addParticle(i + (s & 1) * 0.5f + 0.25f, j + ((s >> 1) & 1) * 0.5f + 0.25f, k + ((s >> 2) & 1) * 0.5f + 0.25f, 0, 0, 0, p);
            simulate(d, 3f);
            SurfaceMesher m = new SurfaceMesher();
            SurfaceMesher.Mesh mesh = m.build(d, 1, 200000, 5000, null);
            check(mesh.quads > 100, "has quads: " + mesh.quads);
            int agree = 0, top = 0; double topY = 0; int topN = 0;
            for (int q = 0; q < mesh.quads; q++) {
                float[] P = mesh.pos;
                int o = q * 12;
                // geometric normal from winding (a->b) x (b->c)
                float ax = P[o + 3] - P[o], ay = P[o + 4] - P[o + 1], az = P[o + 5] - P[o + 2];
                float bx = P[o + 6] - P[o + 3], by = P[o + 7] - P[o + 4], bz = P[o + 8] - P[o + 5];
                float gx = ay * bz - az * by, gy = az * bx - ax * bz, gz = ax * by - ay * bx;
                float sx = 0, sy = 0, sz = 0;
                for (int t = 0; t < 4; t++) { sx += mesh.nrm[o + t * 3]; sy += mesh.nrm[o + t * 3 + 1]; sz += mesh.nrm[o + t * 3 + 2]; }
                if (gx * sx + gy * sy + gz * sz > 0) agree++;
                if (sy > 3.6f) { top++; for (int t = 0; t < 4; t++) { topY += P[o + t * 3 + 1]; topN++; } }
            }
            double agreeFrac = agree / (double) mesh.quads;
            double surfaceY = topY / Math.max(1, topN);
            System.out.printf("    %d quads, %.1f%% winding agrees with normals, top surface at y=%.2f blocks (expected ~3.5)%n", mesh.quads, agreeFrac * 100, surfaceY);
            check(agreeFrac > 0.97, "winding consistent with outward normals");
            check(top > 50, "flat top found");
            check(Math.abs(surfaceY - 3.5) < 0.45, "surface height matches the fluid volume");
        });

        run("save file round trip", () -> {
            try {
                FluidDomain d = box(16, 16, 16, 0.5f);
                FluidProps p = FluidProps.preset("honey"); p.volume = 2f;
                d.spawn(4, 1.0, 4, 0, 0, 0, p);
                simulate(d, 0.5f);
                java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                net.realfluids.sim.DomainIO.write(new java.io.DataOutputStream(bos), java.util.List.of(new net.realfluids.sim.DomainIO.Saved("minecraft:overworld", d)));
                byte[] bytes = bos.toByteArray();
                var back = net.realfluids.sim.DomainIO.read(new java.io.DataInputStream(new java.io.ByteArrayInputStream(bytes)), 100000);
                check(back.size() == 1 && back.get(0).dimension().equals("minecraft:overworld"), "region restored");
                FluidDomain e = back.get(0).domain();
                check(e.particleCount() == d.particleCount(), "particles restored");
                check(e.colors()[0] == d.colors()[0] && ((e.colors()[0] >>> 24) & 0xFF) == Math.round(p.clarity * 255), "colour + clarity restored");
                int truncatedOk = 0;
                for (int cut = 0; cut < bytes.length; cut += Math.max(1, bytes.length / 50)) {
                    try {
                        net.realfluids.sim.DomainIO.read(new java.io.DataInputStream(new java.io.ByteArrayInputStream(java.util.Arrays.copyOf(bytes, cut))), 100000);
                    } catch (java.io.IOException expected) { truncatedOk++; }
                }
                check(truncatedOk >= 49, "truncated files fail cleanly (" + truncatedOk + ")");
            } catch (java.io.IOException ex) { check(false, ex.toString()); }
        });

        run("snapshot for the game thread", () -> {
            FluidDomain d = box(16, 16, 16, 0.5f);
            FluidProps p = FluidProps.preset("lava"); p.volume = 2f;
            d.spawn(4, 1.0, 4, 0, 0, 0, p);
            simulate(d, 0.5f);
            net.realfluids.sim.FluidSnapshot s = new net.realfluids.sim.FluidSnapshot();
            d.fillSnapshot(s);
            check(s.sx > 0, "has a box");
            float occ = s.occupancyAt(4.0, 1.2, 4.0);
            check(occ > 0.5f, "occupied at the pour point: " + occ);
            int idx = s.indexAt(4.0, 1.2, 4.0);
            check(idx >= 0 && s.hot[idx] == 1 && s.dens[idx] > 3000f, "lava properties visible");
            check(s.occupancyAt(4.0, 6.0, 4.0) == 0f, "empty above");
        });

        run("transparency sort is back to front", () -> {
            java.util.Random rnd = new java.util.Random(7);
            int n = 50000;
            float[] d = new float[n];
            for (int i = 0; i < n; i++) d[i] = (float) Math.pow(rnd.nextDouble() * 40, 2);
            int[] order = new int[n], counts = new int[net.realfluids.sim.QuadSort.BUCKETS + 1];
            net.realfluids.sim.QuadSort.backToFront(d, n, order, counts);
            boolean[] seen = new boolean[n];
            int dup = 0, inversions = 0;
            for (int i = 0; i < n; i++) { if (seen[order[i]]) dup++; seen[order[i]] = true; }
            float bucketWidth = 40f / net.realfluids.sim.QuadSort.BUCKETS;
            for (int i = 1; i < n; i++) if (Math.sqrt(d[order[i]]) > Math.sqrt(d[order[i - 1]]) + bucketWidth * 1.01) inversions++;
            check(dup == 0, "every quad exactly once");
            check(inversions == 0, "farthest first (within one bucket): " + inversions + " inversions");
            net.realfluids.sim.QuadSort.backToFront(new float[] { 0f }, 1, order, counts);
            check(order[0] == 0, "single quad at the camera");
        });

        run("scooped fluid is named", () -> {
            FluidProps honey = FluidProps.preset("honey");
            check(FluidProps.closestPresetName(honey).equals("Honey"), "honey stays honey");
            FluidProps lava = FluidProps.preset("lava"); lava.color = 0xF06010;
            check(FluidProps.closestPresetName(lava).equals("Lava"), "slightly different lava is still lava");
            FluidProps odd = new FluidProps(); odd.color = 0xFF00FF; odd.density = 5000; odd.viscosity = 0.5f;
            check(FluidProps.closestPresetName(odd).equals("Mixed fluid"), "unknown mix is 'Mixed fluid'");
        });

        run("performance budget (phone-sized)", () -> {
            FluidDomain d = box(48, 32, 48, 0.5f);
            FluidProps p = FluidProps.preset("water");
            for (int k = 0; k < 48; k++) for (int j = 1; j < 13; j++) for (int i = 0; i < 12; i++)
                for (int s = 0; s < 8; s++) d.addParticle(i + (s & 1) * 0.5f + 0.25f, j + ((s >> 1) & 1) * 0.5f + 0.25f, k + ((s >> 2) & 1) * 0.5f + 0.25f, 0, 0, 0, p);
            SurfaceMesher m = new SurfaceMesher();
            SurfaceMesher.Mesh mesh = null;
            for (int i = 0; i < 10; i++) { d.step(0.05f, 4); mesh = m.build(d, 1, 200000, 6000, mesh); } // warm-up JIT
            long t0 = System.nanoTime(); int steps = 40;
            double meshMs = 0;
            for (int i = 0; i < steps; i++) {
                d.step(0.05f, 4);
                long m0 = System.nanoTime();
                mesh = m.build(d, 1, 200000, 6000, mesh);
                meshMs += (System.nanoTime() - m0) / 1e6;
            }
            double ms = (System.nanoTime() - t0) / 1e6 / steps;
            System.out.printf("    %d particles, %.1f ms per 1/20 s tick incl. meshing (mesh %.1f ms, %d quads), pcg %d its%n",
                d.particleCount(), ms, meshMs / steps, mesh.quads, d.lastPcgIterations);
            check(ms < 120, "desktop budget (phones are ~3-5x slower; the mod adapts the tick rate)");
        });

        System.out.printf("%n%d checks, %d failed%n", checks, failed);
        System.exit(failed == 0 ? 0 : 1);
    }
}

import net.realfluids.sim.FluidDomain;
import net.realfluids.sim.FluidProps;
import net.realfluids.sim.SurfaceMesher;
import net.realfluids.sim.WaterShading;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Offline preview: runs the real solver + mesher + shading and software-rasterizes a small blocky scene.
 *   java -cp out FluidPreview outdir
 */
public class FluidPreview {
    static final int W = 1280, H = 720;
    static final int SKY = 0x9CC4FF;
    static final float[] SUN = norm(0.45f, 0.75f, 0.35f);

    // camera
    static float[] eye, fwd, right, up;
    static float fov = 1.0f;
    static float[] zbuf = new float[W * H];
    static int[] px = new int[W * H];

    public static void main(String[] args) throws Exception {
        String out = args.length > 0 ? args[0] : ".";
        new File(out).mkdirs();
        waterfall(out);
        honeyAndOil(out);
        System.out.println("done");
    }

    // ------------------------------------------------------------------ scenes

    static void waterfall(String out) throws Exception {
        int nx = 40, ny = 32, nz = 32; float h = 0.5f;
        FluidDomain d = new FluidDomain(0, 0, 0, nx, ny, nz, h, 8, 120000, 3);
        byte[] m = new byte[nx * ny * nz];
        int[][] colors = new int[nx * ny * nz][];
        // stone floor
        fill(m, nx, ny, 0, 0, 0, nx - 1, 1, nz - 1);
        // basin walls (blocks 2..17 x, 2..14 z, 2 blocks high)
        for (int y = 2; y <= 5; y++) for (int t = 8; t <= 35; t++) { set(m, nx, ny, t, y, 6); set(m, nx, ny, t, y, 25); }
        for (int y = 2; y <= 5; y++) for (int t = 6; t <= 25; t++) { set(m, nx, ny, 8, y, t); set(m, nx, ny, 35, y, t); }
        // cliff with a ledge the stream pours from
        fill(m, nx, ny, 26, 2, 8, 34, 17, 23);
        d.setWorld(m);
        FluidProps p = FluidProps.preset("water");
        p.mode = FluidProps.Mode.STREAM; p.volume = 50f; p.duration = 6f; p.speed = 3.0f;
        d.spawn(12.8, 8.2, 7.8, -1, 0, 0, p);   // world blocks: from the cliff edge, flowing -x
        FluidProps pool = FluidProps.preset("water"); pool.volume = 30f; pool.shape = FluidProps.Shape.SHEET;
        d.spawn(8.5, 1.05, 7.8, 0, 0, 0, pool);
        for (float t = 0; t < 4.5f; t += 0.05f) d.step(0.05f, 4);
        System.out.printf("waterfall: %d particles, last step %.1f ms%n", d.particleCount(), d.lastStepMillis);
        camera(new float[] { -4.5f, 12.5f, -6.0f }, new float[] { 9.5f, 2.0f, 8.0f });
        render(d, m, out + "/preview_waterfall.png");
    }

    static void honeyAndOil(String out) throws Exception {
        int nx = 36, ny = 24, nz = 28; float h = 0.5f;
        FluidDomain d = new FluidDomain(0, 0, 0, nx, ny, nz, h, 8, 120000, 5);
        byte[] m = new byte[nx * ny * nz];
        fill(m, nx, ny, 0, 0, 0, nx - 1, 1, nz - 1);
        // glass tank on the right (walls only)
        for (int y = 2; y <= 13; y++) for (int t = 20; t <= 33; t++) { set(m, nx, ny, t, y, 6); set(m, nx, ny, t, y, 19); }
        for (int y = 2; y <= 13; y++) for (int t = 6; t <= 19; t++) { set(m, nx, ny, 20, y, t); set(m, nx, ny, 33, y, t); }
        d.setWorld(m);
        FluidProps honey = FluidProps.preset("honey"); honey.volume = 10f; honey.shape = FluidProps.Shape.SPHERE;
        d.spawn(4.5, 1.1, 6.5, 0, 0, 0, honey);
        FluidProps water = FluidProps.preset("water"); water.volume = 20f;
        d.spawn(13.5, 1.1, 6.5, 0, 0, 0, water);
        FluidProps oil = FluidProps.preset("oil"); oil.volume = 7f;
        d.spawn(13.5, 4.5, 6.5, 0, 0, 0, oil);
        for (float t = 0; t < 6f; t += 0.05f) d.step(0.05f, 4);
        camera(new float[] { 2.0f, 9.5f, -5.5f }, new float[] { 9.0f, 1.5f, 7.0f });
        render(d, m, out + "/preview_honey_oil.png");
    }

    static void set(byte[] m, int nx, int ny, int i, int j, int k) { m[i + nx * (j + ny * k)] = FluidDomain.SOLID; }
    static void fill(byte[] m, int nx, int ny, int i0, int j0, int k0, int i1, int j1, int k1) {
        for (int k = k0; k <= k1; k++) for (int j = j0; j <= j1; j++) for (int i = i0; i <= i1; i++) set(m, nx, ny, i, j, k);
    }

    // ------------------------------------------------------------------ renderer

    static void camera(float[] e, float[] target) {
        eye = e;
        fwd = norm(target[0] - e[0], target[1] - e[1], target[2] - e[2]);
        right = norm(cross(fwd, new float[] { 0, 1, 0 }));
        up = cross(right, fwd);
    }

    static final class Tri { float[] x = new float[9]; int[] c = new int[3]; float depth; }

    static void render(FluidDomain d, byte[] m, String file) throws Exception {
        java.util.Arrays.fill(zbuf, Float.MAX_VALUE);
        for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
            float t = y / (float) H;
            px[y * W + x] = lerpRgb(0x6FA8F0, 0xD7E8FF, t);
        }
        int nx = d.nx, ny = d.ny, nz = d.nz; float h = d.h;
        // opaque blocks: cell faces between solid and non-solid
        for (int k = 0; k < nz; k++) for (int j = 0; j < ny; j++) for (int i = 0; i < nx; i++) {
            if (m[i + nx * (j + ny * k)] != FluidDomain.SOLID) continue;
            int[][] dirs = { { 1, 0, 0 }, { -1, 0, 0 }, { 0, 1, 0 }, { 0, -1, 0 }, { 0, 0, 1 }, { 0, 0, -1 } };
            for (int[] dd : dirs) {
                int a = i + dd[0], b = j + dd[1], c = k + dd[2];
                if (a >= 0 && b >= 0 && c >= 0 && a < nx && b < ny && c < nz && m[a + nx * (b + ny * c)] == FluidDomain.SOLID) continue;
                if (b < 0) continue;
                blockFace(i, j, k, dd, h);
            }
        }
        // fluid surface, back-to-front with alpha blending
        SurfaceMesher.Mesh mesh = new SurfaceMesher().build(d, 1, 400000, 20000, null);
        List<Tri> tris = new ArrayList<>();
        for (int q = 0; q < mesh.quads; q++) {
            int[] cols = new int[4];
            for (int t = 0; t < 4; t++) {
                int o = (q * 4 + t) * 3;
                float vx = eye[0] - mesh.pos[o], vy = eye[1] - mesh.pos[o + 1], vz = eye[2] - mesh.pos[o + 2];
                float[] v = norm(vx, vy, vz);
                cols[t] = WaterShading.shade(mesh.nrm[o], mesh.nrm[o + 1], mesh.nrm[o + 2], v[0], v[1], v[2], SUN[0], SUN[1], SUN[2],
                    1f, mesh.rgb[q * 4 + t], SKY, 1f, clarityFor(mesh.rgb[q * 4 + t]), mesh.foam[q * 4 + t], false);
            }
            for (int[] tri : new int[][] { { 0, 1, 2 }, { 0, 2, 3 } }) {
                Tri T = new Tri();
                for (int t = 0; t < 3; t++) {
                    int o = (q * 4 + tri[t]) * 3;
                    T.x[t * 3] = mesh.pos[o]; T.x[t * 3 + 1] = mesh.pos[o + 1]; T.x[t * 3 + 2] = mesh.pos[o + 2];
                    T.c[t] = cols[tri[t]];
                }
                float cx = (T.x[0] + T.x[3] + T.x[6]) / 3 - eye[0], cy = (T.x[1] + T.x[4] + T.x[7]) / 3 - eye[1], cz = (T.x[2] + T.x[5] + T.x[8]) / 3 - eye[2];
                T.depth = cx * cx + cy * cy + cz * cz;
                tris.add(T);
            }
        }
        tris.sort((a, b) -> Float.compare(b.depth, a.depth));
        for (Tri t : tris) raster(t, true, true);
        // spray: airborne droplets as small billboards, resting films as flat puddle splats
        for (int s = 0; s < mesh.sprayCount; s++) {
            float x = mesh.spray[s * 3], y = mesh.spray[s * 3 + 1], z = mesh.spray[s * 3 + 2];
            int rgb = mesh.sprayRgb[s];
            float[][] c = new float[4][];
            int col;
            if (mesh.sprayKind[s] == 1) {
                float r = 0.22f;
                float[] v = norm(eye[0] - x, eye[1] - y, eye[2] - z);
                col = WaterShading.shade(0, 1, 0, v[0], v[1], v[2], SUN[0], SUN[1], SUN[2], 1f, rgb, SKY, 1f, Math.max(0.15f, clarityFor(rgb) * 0.6f), 0f, false);
                col = (col & 0x00FFFFFF) | ((int) (((col >>> 24) & 255) * 0.7f) << 24);
                float yy = y + 0.02f;
                c[0] = new float[] { x - r, yy, z - r }; c[1] = new float[] { x - r, yy, z + r }; c[2] = new float[] { x + r, yy, z + r }; c[3] = new float[] { x + r, yy, z - r };
            } else {
                float r = 0.05f;
                float rr = ((rgb >> 16) & 255) / 255f, gg = ((rgb >> 8) & 255) / 255f, bb = (rgb & 255) / 255f;
                col = WaterShading.argb(0.8f, 0.55f + 0.45f * rr, 0.55f + 0.45f * gg, 0.6f + 0.4f * bb);
                float[][] off = { { -1, -1 }, { 1, -1 }, { 1, 1 }, { -1, 1 } };
                for (int t = 0; t < 4; t++) c[t] = new float[] { x + (right[0] * off[t][0] + up[0] * off[t][1]) * r, y + (right[1] * off[t][0] + up[1] * off[t][1]) * r, z + (right[2] * off[t][0] + up[2] * off[t][1]) * r };
            }
            Tri a = new Tri(), b = new Tri();
            put(a, c[0], c[1], c[2], col); put(b, c[0], c[2], c[3], col);
            raster(a, true, false); raster(b, true, false);
        }
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
        img.setRGB(0, 0, W, H, px, 0, W);
        ImageIO.write(img, "png", new File(file));
        System.out.println("wrote " + file + " (" + mesh.quads + " quads, " + mesh.sprayCount + " droplets)");
    }

    static float clarityFor(int rgb) {
        if (rgb == FluidProps.preset("honey").color) return FluidProps.preset("honey").clarity;
        if (rgb == FluidProps.preset("oil").color) return FluidProps.preset("oil").clarity;
        return 0.35f;
    }

    static void put(Tri t, float[] a, float[] b, float[] c, int col) {
        System.arraycopy(a, 0, t.x, 0, 3); System.arraycopy(b, 0, t.x, 3, 3); System.arraycopy(c, 0, t.x, 6, 3);
        t.c[0] = t.c[1] = t.c[2] = col;
    }

    static void blockFace(int i, int j, int k, int[] n, float h) {
        // unit face of the cell, wound CCW seen from outside
        float x0 = i * h, y0 = j * h, z0 = k * h, x1 = x0 + h, y1 = y0 + h, z1 = z0 + h;
        float[][] q;
        if (n[0] == 1) q = new float[][] { { x1, y0, z0 }, { x1, y1, z0 }, { x1, y1, z1 }, { x1, y0, z1 } };
        else if (n[0] == -1) q = new float[][] { { x0, y0, z0 }, { x0, y0, z1 }, { x0, y1, z1 }, { x0, y1, z0 } };
        else if (n[1] == 1) q = new float[][] { { x0, y1, z0 }, { x0, y1, z1 }, { x1, y1, z1 }, { x1, y1, z0 } };
        else if (n[1] == -1) q = new float[][] { { x0, y0, z0 }, { x1, y0, z0 }, { x1, y0, z1 }, { x0, y0, z1 } };
        else if (n[2] == 1) q = new float[][] { { x0, y0, z1 }, { x1, y0, z1 }, { x1, y1, z1 }, { x0, y1, z1 } };
        else q = new float[][] { { x0, y0, z0 }, { x0, y1, z0 }, { x1, y1, z0 }, { x1, y0, z0 } };
        float lam = 0.55f + 0.45f * Math.max(0, n[0] * SUN[0] + n[1] * SUN[1] + n[2] * SUN[2]);
        int bx = (int) Math.floor(i * h), by = (int) Math.floor(j * h), bz = (int) Math.floor(k * h);
        int base = n[1] == 1 && by >= 1 ? 0x8A8A8A : 0x7A7A7A;
        if (n[1] == 1 && by == 0) base = 0x5E9C3A; // grass top on the floor
        if (((bx + by + bz) & 1) == 0) base = lerpRgb(base, 0x000000, 0.07f);
        int r = (int) (((base >> 16) & 255) * lam), g = (int) (((base >> 8) & 255) * lam), b = (int) ((base & 255) * lam);
        int col = 0xFF000000 | (r << 16) | (g << 8) | b;
        Tri a = new Tri(), c = new Tri();
        put(a, q[0], q[1], q[2], col); put(c, q[0], q[2], q[3], col);
        raster(a, false, true); raster(c, false, true);
    }

    static float[] project(float x, float y, float z) {
        float dx = x - eye[0], dy = y - eye[1], dz = z - eye[2];
        float cz = dx * fwd[0] + dy * fwd[1] + dz * fwd[2];
        float cx = dx * right[0] + dy * right[1] + dz * right[2];
        float cy = dx * up[0] + dy * up[1] + dz * up[2];
        if (cz < 0.05f) return null;
        float f = (H * 0.5f) / (float) Math.tan(fov * 0.5f);
        return new float[] { W * 0.5f + cx / cz * f, H * 0.5f - cy / cz * f, cz };
    }

    static void raster(Tri t, boolean blend, boolean cull) {
        float[] a = project(t.x[0], t.x[1], t.x[2]), b = project(t.x[3], t.x[4], t.x[5]), c = project(t.x[6], t.x[7], t.x[8]);
        if (a == null || b == null || c == null) return;
        float area = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
        if (cull && area >= 0) return; // screen y is down: CCW in world = negative area here
        if (Math.abs(area) < 1e-6f) return;
        int x0 = Math.max(0, (int) Math.floor(Math.min(a[0], Math.min(b[0], c[0])))), x1 = Math.min(W - 1, (int) Math.ceil(Math.max(a[0], Math.max(b[0], c[0]))));
        int y0 = Math.max(0, (int) Math.floor(Math.min(a[1], Math.min(b[1], c[1])))), y1 = Math.min(H - 1, (int) Math.ceil(Math.max(a[1], Math.max(b[1], c[1]))));
        for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) {
            float pxf = x + 0.5f, pyf = y + 0.5f;
            float w0 = ((b[0] - pxf) * (c[1] - pyf) - (b[1] - pyf) * (c[0] - pxf)) / area;
            float w1 = ((c[0] - pxf) * (a[1] - pyf) - (c[1] - pyf) * (a[0] - pxf)) / area;
            float w2 = 1 - w0 - w1;
            if (w0 < 0 || w1 < 0 || w2 < 0) continue;
            float z = 1f / (w0 / a[2] + w1 / b[2] + w2 / c[2]);
            int idx = y * W + x;
            if (z >= zbuf[idx]) continue;
            int col = mix3(t.c[0], t.c[1], t.c[2], w0, w1, w2);
            if (!blend) { px[idx] = col; zbuf[idx] = z; continue; }
            float al = ((col >>> 24) & 255) / 255f;
            px[idx] = lerpRgb(px[idx], col, al);
            if (al > 0.6f) zbuf[idx] = z;
        }
    }

    static int mix3(int a, int b, int c, float wa, float wb, float wc) {
        int r = 0;
        for (int s = 0; s <= 24; s += 8) {
            float v = ((a >>> s) & 255) * wa + ((b >>> s) & 255) * wb + ((c >>> s) & 255) * wc;
            r |= (Math.min(255, Math.max(0, (int) v)) & 255) << s;
        }
        return r;
    }

    static int lerpRgb(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) + ((((b >> 16) & 255) - ((a >> 16) & 255)) * t));
        int g = (int) (((a >> 8) & 255) + ((((b >> 8) & 255) - ((a >> 8) & 255)) * t));
        int bl = (int) ((a & 255) + (((b & 255) - (a & 255)) * t));
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    static float[] norm(float x, float y, float z) { float l = (float) Math.sqrt(x * x + y * y + z * z); return new float[] { x / l, y / l, z / l }; }
    static float[] norm(float[] v) { return norm(v[0], v[1], v[2]); }
    static float[] cross(float[] a, float[] b) { return new float[] { a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0] }; }
}

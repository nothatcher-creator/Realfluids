# Checks every member declared in the compile stubs against the real Yarn 1.20.1 mappings and the
# Fabric API 1.20.1 sources, so the stub compile can't hide a wrong name or argument count.
import os, re, sys, glob
STUBS, YARN, FAPI = sys.argv[1], sys.argv[2], sys.argv[3]

# Real ancestors (Yarn names) whose mapping files may declare inherited members.
ANC = {
 "net/minecraft/client/world/ClientWorld": ["net/minecraft/world/World","net/minecraft/world/WorldView","net/minecraft/world/BlockRenderView","net/minecraft/world/LunarWorldView","net/minecraft/world/WorldAccess","net/minecraft/world/BlockView","net/minecraft/world/RedstoneView","net/minecraft/world/CollisionView","net/minecraft/world/HeightLimitView","net/minecraft/world/ModifiableWorld"],
 "net/minecraft/world/World": ["net/minecraft/world/WorldView","net/minecraft/world/BlockRenderView","net/minecraft/world/LunarWorldView","net/minecraft/world/WorldAccess","net/minecraft/world/BlockView","net/minecraft/world/HeightLimitView","net/minecraft/world/CollisionView","net/minecraft/world/ModifiableWorld"],
 "net/minecraft/server/world/ServerWorld": ["net/minecraft/world/World"],
 "net/minecraft/client/network/ClientPlayerEntity": ["net/minecraft/client/network/AbstractClientPlayerEntity","net/minecraft/entity/player/PlayerEntity","net/minecraft/entity/LivingEntity","net/minecraft/entity/Entity"],
 "net/minecraft/server/network/ServerPlayerEntity": ["net/minecraft/entity/player/PlayerEntity","net/minecraft/entity/LivingEntity","net/minecraft/entity/Entity"],
 "net/minecraft/entity/player/PlayerEntity": ["net/minecraft/entity/LivingEntity","net/minecraft/entity/Entity"],
 "net/minecraft/entity/LivingEntity": ["net/minecraft/entity/Entity"],
 "net/minecraft/block/BlockState": ["net/minecraft/block/AbstractBlock$AbstractBlockState"],
 "net/minecraft/util/math/BlockPos": ["net/minecraft/util/math/Vec3i"],
 "net/minecraft/util/math/BlockPos$Mutable": ["net/minecraft/util/math/BlockPos"],
 "net/minecraft/util/hit/BlockHitResult": ["net/minecraft/util/hit/HitResult"],
 "net/minecraft/client/render/BufferBuilder": ["net/minecraft/client/render/VertexConsumer","net/minecraft/client/render/FixedColorVertexConsumer"],
 "net/minecraft/client/gui/widget/ButtonWidget": ["net/minecraft/client/gui/widget/PressableWidget","net/minecraft/client/gui/widget/ClickableWidget"],
 "net/minecraft/client/gui/widget/SliderWidget": ["net/minecraft/client/gui/widget/ClickableWidget"],
 "net/minecraft/client/gui/widget/TextFieldWidget": ["net/minecraft/client/gui/widget/ClickableWidget"],
 "net/minecraft/text/MutableText": ["net/minecraft/text/Text"],
 "net/minecraft/item/Item": [], "net/minecraft/server/integrated/IntegratedServer": ["net/minecraft/server/MinecraftServer"],
 "net/minecraft/client/MinecraftClient": ["net/minecraft/util/thread/ReentrantThreadExecutor","net/minecraft/util/thread/ThreadExecutor"],
 "net/minecraft/server/MinecraftServer": ["net/minecraft/util/thread/ReentrantThreadExecutor","net/minecraft/util/thread/ThreadExecutor"],
 "net/minecraft/nbt/NbtCompound": ["net/minecraft/nbt/NbtElement"],
 "net/minecraft/entity/Entity": ["net/minecraft/world/entity/EntityLike","net/minecraft/util/Nameable","net/minecraft/server/command/CommandOutput"],
 "net/minecraft/text/Text": ["net/minecraft/text/StringVisitable"],
 "net/minecraft/client/gui/screen/Screen": ["net/minecraft/client/gui/Drawable","net/minecraft/client/gui/AbstractParentElement","net/minecraft/client/gui/ParentElement","net/minecraft/client/gui/Element"],
}
# Members that are fine without a Yarn entry (unobfuscated / JDK / netty / record / enum names)
UNMAPPED_OK = {"close","values","valueOf","hasSkyLight","readBoolean","readDouble","readFloat","readByte","readInt","writeBoolean","writeDouble",
  "writeFloat","writeByte","writeInt","execute","x","y","z","random",
  "getString"}  # Text.getString comes from brigadier's Message interface, so it is never renamed

def load_mapping(path):
    f = os.path.join(YARN, path + ".mapping")
    inner = None
    if "$" in path:
        path, inner = path.split("$", 1)
        f = os.path.join(YARN, path + ".mapping")
    if not os.path.exists(f): return None
    lines = open(f).read().split("\n")
    if inner is None:
        return [l for l in lines if l.startswith("\tMETHOD") or l.startswith("\tFIELD") or l.startswith("CLASS")]
    out, inside = [], False
    for l in lines:
        if l.startswith("\tCLASS"):
            inside = l.split()[-1] == inner
            if inside: out.append(l)
            continue
        if not l.startswith("\t\t"):
            if not l.startswith("\t\t\t"): pass
        if inside and (l.startswith("\t\tMETHOD") or l.startswith("\t\tFIELD")): out.append(l)
        if l.startswith("\t") and not l.startswith("\t\t") and not l.startswith("\tCLASS"): inside = False if not l.startswith("\tCLASS") else inside
    return out

def arity(desc):
    m = re.match(r"\((.*)\)", desc); s = m.group(1); n = 0; i = 0
    while i < len(s):
        ch = s[i]
        if ch == "L": i = s.index(";", i) + 1; n += 1
        elif ch == "[": i += 1; continue
        else: i += 1; n += 1
    return n

def members_of(lines):
    meth, fld = {}, set()
    for l in lines or []:
        p = l.split()
        if p[0] == "METHOD" and len(p) >= 4: meth.setdefault(p[2], set()).add(arity(p[3]))
        elif p[0] == "METHOD" and len(p) == 3: meth.setdefault(p[1], set()).add(arity(p[2]))  # name kept by Mojang
        if p[0] == "FIELD" and len(p) >= 4: fld.add(p[2])
    return meth, fld

decl_re = re.compile(r"(?:public|protected|static|abstract|final|\s)*[\w.<>\[\]?, &]+\s+(\w+)\s*\(([^)]*)\)\s*[{;]")
field_re = re.compile(r"public\s+(?:static\s+)?(?:final\s+)?[\w.<>\[\]]+\s+([\w, =]+?)\s*[;=]")
problems = 0; checked = 0
for jf in sorted(glob.glob(os.path.join(STUBS, "net/minecraft/**/*.java"), recursive=True)):
    rel = os.path.relpath(jf, STUBS)[:-5]
    src = open(jf).read()
    # split into the top-level body and nested class/interface bodies (brace matched)
    blocks = {}
    def nested_spans(text):
        out = []
        for m in re.finditer(r"\b(?:class|interface|enum|record)\s+(\w+)[^{;]*\{", text):
            depth, i = 1, m.end()
            while depth and i < len(text):
                depth += {"{": 1, "}": -1}.get(text[i], 0); i += 1
            out.append((m.group(1), m.start(), m.end(), i - 1))
        return out
    spans = nested_spans(src)
    if not spans:
        print("UNPARSED stub", rel); problems += 1; continue
    top = spans[0]
    inner = [sp for sp in spans[1:] if sp[1] > top[2]]
    # keep only direct children of the top-level type
    direct = [sp for sp in inner if not any(o[2] <= sp[1] and sp[3] <= o[3] for o in inner if o is not sp)]
    top_body = src[top[2]:top[3]]
    for name, a, b, e in sorted(direct, key=lambda t: -t[1]):
        blocks[rel + "$" + name] = src[b:e]
        top_body = top_body.replace(src[a:e + 1], "")
    blocks[rel] = top_body
    for cls, body in blocks.items():
        own = load_mapping(cls)
        if own is None:
            print("NO MAPPING FILE:", cls); problems += 1; continue
        meth, fld = members_of(own)
        for a in ANC.get(cls, []):
            m2, f2 = members_of(load_mapping(a)); 
            for k, v in m2.items(): meth.setdefault(k, set()).update(v)
            fld |= f2
        body_wo_nested = body
        for name, args in decl_re.findall(body_wo_nested):
            if name in ("if","for","while","switch","return","new","super"): continue
            if name == os.path.basename(cls.replace("$","/")): continue  # constructor
            n = 0 if not args.strip() else args.count(",") + 1 - args.count("<") + 0
            n = len([a for a in re.split(r",(?![^<]*>)", args) if a.strip()])
            checked += 1
            if name in UNMAPPED_OK: continue
            if name not in meth:
                print(f"MISSING method {cls}.{name}"); problems += 1
            elif n not in meth[name]:
                print(f"ARITY {cls}.{name}({n}) yarn has {sorted(meth[name])}"); problems += 1
        for grp in field_re.findall(body_wo_nested):
            for nm in [g.split("=")[0].strip() for g in grp.split(",")]:
                if not nm or nm in UNMAPPED_OK: continue
                checked += 1
                if nm not in fld and not nm.isupper():
                    print(f"MISSING field {cls}.{nm}"); problems += 1
                elif nm not in fld and nm.isupper():
                    print(f"(unverified constant {cls}.{nm})")
print(f"checked {checked} members, {problems} problems")

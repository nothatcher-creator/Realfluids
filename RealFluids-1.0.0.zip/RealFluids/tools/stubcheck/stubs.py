# Minimal compile-only stubs of the Minecraft 1.20.1 (Yarn) + Fabric API surface the mod uses.
# Names are cross-checked against the real Yarn mappings / Fabric sources by verify.py.
import os, sys, textwrap
OUT = sys.argv[1]
S = {}
def c(fq, body):
    S[fq] = textwrap.dedent(body)

# ---------------- java-ish libs
c("org.slf4j.Logger", "public interface Logger { void info(String s, Object... a); void warn(String s, Object... a); void error(String s, Throwable t); void debug(String s, Object... a); }")
c("org.slf4j.LoggerFactory", "public class LoggerFactory { public static Logger getLogger(String n){return null;} }")
c("com.google.gson.Gson", "public class Gson { public <T> T fromJson(java.io.Reader r, Class<T> c){return null;} public void toJson(Object o, Appendable w){} }")
c("com.google.gson.GsonBuilder", "public class GsonBuilder { public GsonBuilder setPrettyPrinting(){return this;} public Gson create(){return null;} }")
c("org.lwjgl.glfw.GLFW", "public class GLFW { public static final int GLFW_KEY_Z = 90; }")
c("org.joml.Matrix4f", "public class Matrix4f {}")
c("com.mojang.blaze3d.systems.RenderSystem", """
public class RenderSystem {
  public static void enableBlend(){} public static void disableBlend(){} public static void defaultBlendFunc(){}
  public static void enableDepthTest(){} public static void depthMask(boolean b){} public static void disableCull(){} public static void enableCull(){}
  public static void setShaderColor(float r,float g,float b,float a){}
}""")
# brigadier
c("com.mojang.brigadier.Command", "@FunctionalInterface public interface Command<S> { int run(com.mojang.brigadier.context.CommandContext<S> c) throws com.mojang.brigadier.exceptions.CommandSyntaxException; }")
c("com.mojang.brigadier.exceptions.CommandSyntaxException", "public class CommandSyntaxException extends Exception {}")
c("com.mojang.brigadier.context.CommandContext", "public class CommandContext<S> { public S getSource(){return null;} }")
c("com.mojang.brigadier.CommandDispatcher", "public class CommandDispatcher<S> { public Object register(com.mojang.brigadier.builder.LiteralArgumentBuilder<S> b){return null;} }")
c("com.mojang.brigadier.builder.ArgumentBuilder", """
public abstract class ArgumentBuilder<S, T extends ArgumentBuilder<S, T>> {
  public T then(ArgumentBuilder<S, ?> a){return null;}
  public T executes(com.mojang.brigadier.Command<S> c){return null;}
}""")
c("com.mojang.brigadier.builder.LiteralArgumentBuilder", "public class LiteralArgumentBuilder<S> extends ArgumentBuilder<S, LiteralArgumentBuilder<S>> {}")
c("com.mojang.brigadier.builder.RequiredArgumentBuilder", """
public class RequiredArgumentBuilder<S, T> extends ArgumentBuilder<S, RequiredArgumentBuilder<S, T>> {
  public RequiredArgumentBuilder<S, T> suggests(com.mojang.brigadier.suggestion.SuggestionProvider<S> p){return this;}
}""")
c("com.mojang.brigadier.arguments.ArgumentType", "public interface ArgumentType<T> {}")
c("com.mojang.brigadier.arguments.StringArgumentType", """
public class StringArgumentType implements ArgumentType<String> {
  public static StringArgumentType word(){return null;}
  public static String getString(com.mojang.brigadier.context.CommandContext<?> c, String n){return null;}
}""")
c("com.mojang.brigadier.suggestion.SuggestionProvider", "@FunctionalInterface public interface SuggestionProvider<S> { java.util.concurrent.CompletableFuture<Suggestions> getSuggestions(com.mojang.brigadier.context.CommandContext<S> c, SuggestionsBuilder b) throws com.mojang.brigadier.exceptions.CommandSyntaxException; }")
c("com.mojang.brigadier.suggestion.Suggestions", "public class Suggestions {}")
c("com.mojang.brigadier.suggestion.SuggestionsBuilder", "public class SuggestionsBuilder { public SuggestionsBuilder suggest(String s){return this;} public java.util.concurrent.CompletableFuture<Suggestions> buildFuture(){return null;} }")

# ---------------- minecraft: util / math
c("net.minecraft.util.Identifier", "public class Identifier { public Identifier(String ns, String path){} }")
c("net.minecraft.util.Hand", "public enum Hand { MAIN_HAND, OFF_HAND }")
c("net.minecraft.util.ActionResult", "public enum ActionResult { SUCCESS, CONSUME, CONSUME_PARTIAL, PASS, FAIL }")
c("net.minecraft.util.TypedActionResult", """
public class TypedActionResult<T> {
  public static <T> TypedActionResult<T> success(T t, boolean swing){return null;}
  public static <T> TypedActionResult<T> consume(T t){return null;}
  public static <T> TypedActionResult<T> pass(T t){return null;}
  public static <T> TypedActionResult<T> fail(T t){return null;}
  public net.minecraft.util.ActionResult getResult(){return null;}
}""")
c("net.minecraft.util.Formatting", "public enum Formatting { AQUA, GRAY, DARK_GRAY }")
c("net.minecraft.util.math.Vec3i", "public class Vec3i { public int getX(){return 0;} public int getY(){return 0;} public int getZ(){return 0;} }")
c("net.minecraft.util.math.BlockPos", """
public class BlockPos extends Vec3i {
  public BlockPos(int x, int y, int z){}
  public static BlockPos ofFloored(double x, double y, double z){return null;}
  public static class Mutable extends BlockPos { public Mutable(){super(0,0,0);} public Mutable set(int x, int y, int z){return this;} }
}""")
c("net.minecraft.util.math.Direction", "public enum Direction { DOWN, UP, NORTH, SOUTH, WEST, EAST; public Vec3i getVector(){return null;} }")
c("net.minecraft.util.math.Vec3d", """
public class Vec3d {
  public final double x, y, z;
  public Vec3d(double x, double y, double z){this.x=x;this.y=y;this.z=z;}
  public static Vec3d of(Vec3i v){return null;}
  public Vec3d add(Vec3d o){return null;} public Vec3d multiply(double d){return null;}
  public double distanceTo(Vec3d o){return 0;}
}""")
c("net.minecraft.util.math.Box", """
public class Box {
  public final double minX, minY, minZ, maxX, maxY, maxZ;
  public Box(double a,double b,double c,double d,double e,double f){minX=a;minY=b;minZ=c;maxX=d;maxY=e;maxZ=f;}
  public Box expand(double v){return this;} public boolean contains(Vec3d p){return false;}
}""")
c("net.minecraft.util.math.random.Random", "public interface Random { float nextFloat(); double nextDouble(); int nextInt(int b); }")
c("net.minecraft.util.shape.VoxelShape", "public abstract class VoxelShape { public boolean isEmpty(){return true;} public java.util.List<net.minecraft.util.math.Box> getBoundingBoxes(){return null;} }")
c("net.minecraft.util.hit.HitResult", """
public abstract class HitResult {
  public enum Type { MISS, BLOCK, ENTITY }
  public abstract Type getType();
  public net.minecraft.util.math.Vec3d getPos(){return null;}
}""")
c("net.minecraft.util.hit.BlockHitResult", """
public class BlockHitResult extends HitResult {
  public Type getType(){return null;}
  public net.minecraft.util.math.BlockPos getBlockPos(){return null;}
  public net.minecraft.util.math.Direction getSide(){return null;}
}""")
c("net.minecraft.text.Text", """
public interface Text {
  static MutableText literal(String s){return null;}
  static MutableText empty(){return null;}
  String getString();
}""")
c("net.minecraft.text.MutableText", "public abstract class MutableText implements Text { public MutableText formatted(net.minecraft.util.Formatting f){return this;} }")

# ---------------- nbt / network / registry
c("net.minecraft.nbt.NbtElement", """
public interface NbtElement {
  byte BYTE_TYPE = 1; byte INT_TYPE = 3; byte FLOAT_TYPE = 5; byte DOUBLE_TYPE = 6; byte STRING_TYPE = 8; byte COMPOUND_TYPE = 10;
}""")
c("net.minecraft.nbt.NbtCompound", """
public class NbtCompound implements NbtElement {
  public void putString(String k, String v){} public void putInt(String k, int v){} public void putFloat(String k, float v){} public void putBoolean(String k, boolean v){}
  public java.util.Set<String> getKeys(){return null;} public byte getType(String k){return 0;}
  public String getString(String k){return null;} public int getInt(String k){return 0;} public float getFloat(String k){return 0;}
  public double getDouble(String k){return 0;} public byte getByte(String k){return 0;}
}""")
c("net.minecraft.network.PacketByteBuf", """
public class PacketByteBuf {
  public net.minecraft.nbt.NbtCompound readNbt(){return null;} public PacketByteBuf writeNbt(net.minecraft.nbt.NbtCompound c){return this;}
  public boolean readBoolean(){return false;} public double readDouble(){return 0;} public float readFloat(){return 0;} public byte readByte(){return 0;} public int readInt(){return 0;}
  public PacketByteBuf writeBoolean(boolean b){return this;} public PacketByteBuf writeDouble(double d){return this;} public PacketByteBuf writeFloat(float f){return this;}
  public PacketByteBuf writeByte(int b){return this;} public PacketByteBuf writeInt(int i){return this;}
}""")
c("net.minecraft.registry.RegistryKey", "public class RegistryKey<T> { public net.minecraft.util.Identifier getValue(){return null;} }")
c("net.minecraft.registry.tag.TagKey", "public class TagKey<T> {}")
c("net.minecraft.registry.tag.FluidTags", "public class FluidTags { public static final TagKey<net.minecraft.fluid.Fluid> WATER = null, LAVA = null; }")
c("net.minecraft.fluid.Fluid", "public abstract class Fluid {}")
c("net.minecraft.fluid.FluidState", "public class FluidState { public boolean isEmpty(){return true;} public boolean isIn(net.minecraft.registry.tag.TagKey<Fluid> t){return false;} }")

# ---------------- items / blocks / sounds / particles
c("net.minecraft.item.ItemConvertible", "public interface ItemConvertible {}")
c("net.minecraft.item.Item", "public class Item implements ItemConvertible {}")
c("net.minecraft.item.Items", "public class Items { public static final Item BUCKET = null, WATER_BUCKET = null, LAVA_BUCKET = null; }")
c("net.minecraft.item.ItemStack", """
public class ItemStack {
  public ItemStack(ItemConvertible i){}
  public boolean isOf(Item i){return false;} public boolean isEmpty(){return false;} public int getCount(){return 1;} public void decrement(int n){}
  public net.minecraft.nbt.NbtCompound getSubNbt(String k){return null;} public void setSubNbt(String k, net.minecraft.nbt.NbtElement e){} public void removeSubNbt(String k){}
}""")
c("net.minecraft.block.Block", "public class Block {}")
c("net.minecraft.block.BlockState", """
public class BlockState {
  public net.minecraft.block.Block getBlock(){return null;} public boolean isAir(){return false;}
  public net.minecraft.util.shape.VoxelShape getCollisionShape(net.minecraft.world.BlockView w, net.minecraft.util.math.BlockPos p){return null;}
  public net.minecraft.fluid.FluidState getFluidState(){return null;}
}""")
c("net.minecraft.block.FluidDrainable", "public interface FluidDrainable { net.minecraft.item.ItemStack tryDrainFluid(net.minecraft.world.WorldAccess w, net.minecraft.util.math.BlockPos p, BlockState s); }")
c("net.minecraft.sound.SoundEvent", "public class SoundEvent {}")
c("net.minecraft.sound.SoundCategory", "public enum SoundCategory { BLOCKS, PLAYERS }")
c("net.minecraft.sound.SoundEvents", """
public class SoundEvents {
  public static final SoundEvent ITEM_BUCKET_EMPTY = null, ITEM_BUCKET_EMPTY_LAVA = null, ITEM_BUCKET_FILL = null, ITEM_BUCKET_FILL_LAVA = null,
    ENTITY_PLAYER_SPLASH = null, ENTITY_PLAYER_SPLASH_HIGH_SPEED = null, BLOCK_LAVA_POP = null;
}""")
c("net.minecraft.particle.ParticleEffect", "public interface ParticleEffect {}")
c("net.minecraft.particle.DefaultParticleType", "public class DefaultParticleType implements ParticleEffect {}")
c("net.minecraft.particle.ParticleTypes", "public class ParticleTypes { public static final DefaultParticleType SPLASH = null, LAVA = null, LARGE_SMOKE = null, BUBBLE = null; }")

# ---------------- world
c("net.minecraft.world.BlockView", """
public interface BlockView {
  net.minecraft.block.BlockState getBlockState(net.minecraft.util.math.BlockPos p);
  net.minecraft.fluid.FluidState getFluidState(net.minecraft.util.math.BlockPos p);
}""")
c("net.minecraft.world.LightType", "public enum LightType { SKY, BLOCK }")
c("net.minecraft.world.WorldAccess", "public interface WorldAccess extends BlockView {}")
c("net.minecraft.world.dimension.DimensionType", "public record DimensionType(boolean hasSkyLight) {}")
c("net.minecraft.world.RaycastContext", """
public class RaycastContext {
  public enum ShapeType { COLLIDER, OUTLINE, VISUAL, FALLDAMAGE_RESETTING }
  public enum FluidHandling { NONE, SOURCE_ONLY, ANY, WATER }
  public RaycastContext(net.minecraft.util.math.Vec3d a, net.minecraft.util.math.Vec3d b, ShapeType s, FluidHandling f, net.minecraft.entity.Entity e){}
}""")
c("net.minecraft.world.World", """
public abstract class World implements WorldAccess {
  public final net.minecraft.util.math.random.Random random = null;
  public boolean isClient(){return false;}
  public net.minecraft.block.BlockState getBlockState(net.minecraft.util.math.BlockPos p){return null;}
  public net.minecraft.fluid.FluidState getFluidState(net.minecraft.util.math.BlockPos p){return null;}
  public net.minecraft.registry.RegistryKey<World> getRegistryKey(){return null;}
  public int getBottomY(){return 0;} public int getTopY(){return 0;}
  public boolean isChunkLoaded(int x, int z){return false;}
  public net.minecraft.util.hit.BlockHitResult raycast(RaycastContext c){return null;}
  public boolean canPlayerModifyAt(net.minecraft.entity.player.PlayerEntity p, net.minecraft.util.math.BlockPos pos){return true;}
  public void playSound(net.minecraft.entity.player.PlayerEntity except, net.minecraft.util.math.BlockPos pos, net.minecraft.sound.SoundEvent s, net.minecraft.sound.SoundCategory c, float v, float p){}
  public void playSound(double x, double y, double z, net.minecraft.sound.SoundEvent s, net.minecraft.sound.SoundCategory c, float v, float p, boolean useDistance){}
  public void addParticle(net.minecraft.particle.ParticleEffect e, double x, double y, double z, double vx, double vy, double vz){}
  public long getTime(){return 0;}
  public float getSkyAngle(float td){return 0;}
  public float getRainGradient(float td){return 0;} public float getThunderGradient(float td){return 0;}
  public int getAmbientDarkness(){return 0;}
  public net.minecraft.world.dimension.DimensionType getDimension(){return null;}
  public int getLightLevel(LightType t, net.minecraft.util.math.BlockPos p){return 0;}
}""")
c("net.minecraft.client.world.ClientWorld", """
public class ClientWorld extends net.minecraft.world.World {
  public net.minecraft.util.math.Vec3d getSkyColor(net.minecraft.util.math.Vec3d cam, float td){return null;}
}""")
c("net.minecraft.server.world.ServerWorld", "public class ServerWorld extends net.minecraft.world.World {}")
c("net.minecraft.world.SaveProperties", "public interface SaveProperties { String getLevelName(); }")
c("net.minecraft.server.MinecraftServer", "public abstract class MinecraftServer { public void execute(Runnable r){} public net.minecraft.world.SaveProperties getSaveProperties(){return null;} }")
c("net.minecraft.client.network.ServerInfo", "public class ServerInfo { public String address; }")

# ---------------- entities
c("net.minecraft.entity.Entity", """
public abstract class Entity {
  public float fallDistance;
  public double getX(){return 0;} public double getY(){return 0;} public double getZ(){return 0;}
  public double getEyeY(){return 0;}
  public net.minecraft.util.math.Vec3d getPos(){return null;} public net.minecraft.util.math.Vec3d getEyePos(){return null;}
  public net.minecraft.util.math.Vec3d getVelocity(){return null;} public void setVelocity(double x, double y, double z){}
  public net.minecraft.util.math.Vec3d getRotationVec(float td){return null;}
  public net.minecraft.util.hit.HitResult raycast(double max, float td, boolean fluids){return null;}
  public float getYaw(){return 0;} public float getPitch(){return 0;}
  public float getWidth(){return 0;} public float getHeight(){return 0;}
  public net.minecraft.util.math.Box getBoundingBox(){return null;}
  public double squaredDistanceTo(double x, double y, double z){return 0;}
  public boolean isFireImmune(){return false;} public void setOnFireFor(int s){} public boolean isOnFire(){return false;} public void extinguish(){}
  public boolean isSpectator(){return false;} public boolean isSprinting(){return false;}
  public net.minecraft.world.World getWorld(){return null;}
}""")
c("net.minecraft.entity.LivingEntity", """
public abstract class LivingEntity extends net.minecraft.entity.Entity {
  public net.minecraft.item.ItemStack getStackInHand(net.minecraft.util.Hand h){return null;}
  public void setStackInHand(net.minecraft.util.Hand h, net.minecraft.item.ItemStack s){}
  public net.minecraft.item.ItemStack getMainHandStack(){return null;}
  public void swingHand(net.minecraft.util.Hand h){}
}""")
c("net.minecraft.entity.player.PlayerAbilities", "public class PlayerAbilities { public boolean creativeMode; public boolean flying; }")
c("net.minecraft.entity.player.PlayerInventory", "public class PlayerInventory { public boolean insertStack(net.minecraft.item.ItemStack s){return true;} }")
c("net.minecraft.entity.ItemEntity", "public class ItemEntity {}")
c("net.minecraft.entity.player.PlayerEntity", """
public abstract class PlayerEntity extends net.minecraft.entity.LivingEntity {
  public PlayerAbilities getAbilities(){return null;} public PlayerInventory getInventory(){return null;}
  public net.minecraft.entity.ItemEntity dropItem(net.minecraft.item.ItemStack s, boolean retainOwnership){return null;}
  public void sendMessage(net.minecraft.text.Text t, boolean overlay){}
}""")
c("net.minecraft.server.network.ServerPlayerEntity", "public class ServerPlayerEntity extends net.minecraft.entity.player.PlayerEntity { public net.minecraft.server.world.ServerWorld getServerWorld(){return null;} }")
c("net.minecraft.client.input.Input", "public class Input { public float movementSideways, movementForward; }")
c("net.minecraft.client.network.ClientPlayerEntity", "public class ClientPlayerEntity extends net.minecraft.entity.player.PlayerEntity { public net.minecraft.client.input.Input input; }")
c("net.minecraft.client.network.ClientPlayNetworkHandler", "public class ClientPlayNetworkHandler {}")
c("net.minecraft.server.network.ServerPlayNetworkHandler", "public class ServerPlayNetworkHandler {}")

# ---------------- client
c("net.minecraft.client.option.KeyBinding", """
public class KeyBinding {
  public KeyBinding(String id, net.minecraft.client.util.InputUtil.Type t, int code, String cat){}
  public boolean wasPressed(){return false;} public boolean isPressed(){return false;}
  public net.minecraft.text.Text getBoundKeyLocalizedText(){return null;}
}""")
c("net.minecraft.client.util.InputUtil", "public class InputUtil { public enum Type { KEYSYM, SCANCODE, MOUSE } }")
c("net.minecraft.client.option.GameOptions", "public class GameOptions { public net.minecraft.client.option.KeyBinding jumpKey, sneakKey; public boolean hudHidden; }")
c("net.minecraft.client.render.Camera", "public class Camera { public net.minecraft.util.math.Vec3d getPos(){return null;} public float getYaw(){return 0;} public float getPitch(){return 0;} }")
c("net.minecraft.client.gl.ShaderProgram", "public class ShaderProgram {}")
c("net.minecraft.client.render.GameRenderer", "public class GameRenderer { public static net.minecraft.client.gl.ShaderProgram getPositionColorProgram(){return null;} public net.minecraft.client.render.Camera getCamera(){return null;} }")
c("net.minecraft.client.render.VertexFormat", "public class VertexFormat { public enum DrawMode { QUADS, TRIANGLES } }")
c("net.minecraft.client.render.VertexFormats", "public class VertexFormats { public static final VertexFormat POSITION_COLOR = null; }")
c("net.minecraft.client.render.VertexConsumer", """
public interface VertexConsumer {
  VertexConsumer vertex(double x, double y, double z);
  VertexConsumer color(int r, int g, int b, int a);
  void next();
}""")
c("net.minecraft.client.render.BufferBuilder", """
public class BufferBuilder implements VertexConsumer {
  public BufferBuilder(int cap){}
  public void begin(VertexFormat.DrawMode m, VertexFormat f){}
  public VertexConsumer vertex(double x, double y, double z){return this;}
  public VertexConsumer color(int r, int g, int b, int a){return this;}
  public void next(){}
  public BuiltBuffer end(){return null;}
  public static class BuiltBuffer {}
}""")
c("net.minecraft.client.gl.VertexBuffer", """
public class VertexBuffer implements AutoCloseable {
  public enum Usage { STATIC, DYNAMIC }
  public VertexBuffer(Usage u){}
  public void bind(){} public static void unbind(){}
  public void upload(net.minecraft.client.render.BufferBuilder.BuiltBuffer b){}
  public void draw(org.joml.Matrix4f view, org.joml.Matrix4f proj, ShaderProgram p){}
  public void close(){}
}""")
c("net.minecraft.client.util.math.MatrixStack", """
public class MatrixStack {
  public void push(){} public void pop(){} public void translate(double x, double y, double z){}
  public Entry peek(){return null;}
  public static final class Entry { public org.joml.Matrix4f getPositionMatrix(){return null;} }
}""")
c("net.minecraft.client.font.TextRenderer", "public class TextRenderer {}")
c("net.minecraft.client.gui.DrawContext", """
public class DrawContext {
  public void fill(int x1, int y1, int x2, int y2, int color){}
  public void drawCenteredTextWithShadow(net.minecraft.client.font.TextRenderer r, net.minecraft.text.Text t, int x, int y, int c){}
  public int drawTextWithShadow(net.minecraft.client.font.TextRenderer r, String t, int x, int y, int c){return 0;}
  public int getScaledWindowWidth(){return 0;} public int getScaledWindowHeight(){return 0;}
}""")
c("net.minecraft.client.gui.Drawable", "public interface Drawable {}")
c("net.minecraft.client.gui.Element", "public interface Element {}")
c("net.minecraft.client.gui.widget.ClickableWidget", """
public abstract class ClickableWidget implements net.minecraft.client.gui.Drawable, net.minecraft.client.gui.Element {
  public boolean active = true;
  public ClickableWidget(int x, int y, int w, int h, net.minecraft.text.Text t){}
  public void setMessage(net.minecraft.text.Text t){}
}""")
c("net.minecraft.client.gui.widget.ButtonWidget", """
public class ButtonWidget extends ClickableWidget {
  protected ButtonWidget(){super(0,0,0,0,null);}
  public interface PressAction { void onPress(ButtonWidget b); }
  public static Builder builder(net.minecraft.text.Text t, PressAction a){return null;}
  public static class Builder { public Builder dimensions(int x, int y, int w, int h){return this;} public ButtonWidget build(){return null;} }
}""")
c("net.minecraft.client.gui.widget.SliderWidget", """
public abstract class SliderWidget extends ClickableWidget {
  protected double value;
  public SliderWidget(int x, int y, int w, int h, net.minecraft.text.Text t, double v){super(x,y,w,h,t);}
  protected abstract void updateMessage();
  protected abstract void applyValue();
}""")
c("net.minecraft.client.gui.widget.TextFieldWidget", """
public class TextFieldWidget extends ClickableWidget {
  public TextFieldWidget(net.minecraft.client.font.TextRenderer r, int x, int y, int w, int h, net.minecraft.text.Text t){super(x,y,w,h,t);}
  public void setMaxLength(int n){} public void setText(String s){} public String getText(){return null;}
  public void setChangedListener(java.util.function.Consumer<String> c){}
}""")
c("net.minecraft.client.gui.screen.Screen", """
public abstract class Screen {
  protected final net.minecraft.text.Text title;
  public int width, height;
  protected net.minecraft.client.MinecraftClient client;
  protected net.minecraft.client.font.TextRenderer textRenderer;
  protected Screen(net.minecraft.text.Text t){title=t;}
  protected void init(){}
  protected void clearAndInit(){}
  protected <T extends net.minecraft.client.gui.Element & net.minecraft.client.gui.Drawable> T addDrawableChild(T w){return w;}
  public void render(net.minecraft.client.gui.DrawContext c, int mx, int my, float d){}
  public void renderBackground(net.minecraft.client.gui.DrawContext c){}
  public void close(){}
  public boolean shouldPause(){return true;}
}""")
c("net.minecraft.client.MinecraftClient", """
public class MinecraftClient {
  public static MinecraftClient getInstance(){return null;}
  public net.minecraft.client.world.ClientWorld world; public net.minecraft.client.network.ClientPlayerEntity player;
  public net.minecraft.client.gui.screen.Screen currentScreen; public net.minecraft.client.option.GameOptions options;
  public net.minecraft.client.render.GameRenderer gameRenderer;
  public void execute(Runnable r){} public boolean isOnThread(){return true;}
  public void setScreen(net.minecraft.client.gui.screen.Screen s){}
  public boolean isPaused(){return false;} public boolean isIntegratedServerRunning(){return false;}
  public net.minecraft.server.integrated.IntegratedServer getServer(){return null;}
  public net.minecraft.client.network.ServerInfo getCurrentServerEntry(){return null;}
}""")
c("net.minecraft.server.integrated.IntegratedServer", "public class IntegratedServer extends net.minecraft.server.MinecraftServer {}")
c("net.minecraft.client.item.TooltipContext", "public interface TooltipContext {}")

# ---------------- fabric
c("net.fabricmc.api.ModInitializer", "public interface ModInitializer { void onInitialize(); }")
c("net.fabricmc.api.ClientModInitializer", "public interface ClientModInitializer { void onInitializeClient(); }")
c("net.fabricmc.fabric.api.event.Event", "public abstract class Event<T> { public void register(T l){} }")
c("net.fabricmc.loader.api.FabricLoader", "public interface FabricLoader { static FabricLoader getInstance(){return null;} java.nio.file.Path getConfigDir(); java.nio.file.Path getGameDir(); }")
c("net.fabricmc.fabric.api.event.player.UseItemCallback", """
public interface UseItemCallback {
  net.fabricmc.fabric.api.event.Event<UseItemCallback> EVENT = null;
  net.minecraft.util.TypedActionResult<net.minecraft.item.ItemStack> interact(net.minecraft.entity.player.PlayerEntity p, net.minecraft.world.World w, net.minecraft.util.Hand h);
}""")
c("net.fabricmc.fabric.api.networking.v1.PacketSender", "public interface PacketSender {}")
c("net.fabricmc.fabric.api.networking.v1.PacketByteBufs", "public class PacketByteBufs { public static net.minecraft.network.PacketByteBuf create(){return null;} }")
c("net.fabricmc.fabric.api.networking.v1.PlayerLookup", "public class PlayerLookup { public static java.util.Collection<net.minecraft.server.network.ServerPlayerEntity> around(net.minecraft.server.world.ServerWorld w, net.minecraft.util.math.Vec3d p, double r){return null;} }")
c("net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking", """
public class ServerPlayNetworking {
  public interface PlayChannelHandler { void receive(net.minecraft.server.MinecraftServer s, net.minecraft.server.network.ServerPlayerEntity p, net.minecraft.server.network.ServerPlayNetworkHandler h, net.minecraft.network.PacketByteBuf b, PacketSender r); }
  public static boolean registerGlobalReceiver(net.minecraft.util.Identifier id, PlayChannelHandler h){return true;}
  public static void send(net.minecraft.server.network.ServerPlayerEntity p, net.minecraft.util.Identifier id, net.minecraft.network.PacketByteBuf b){}
}""")
c("net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking", """
public class ClientPlayNetworking {
  public interface PlayChannelHandler { void receive(net.minecraft.client.MinecraftClient c, net.minecraft.client.network.ClientPlayNetworkHandler h, net.minecraft.network.PacketByteBuf b, net.fabricmc.fabric.api.networking.v1.PacketSender s); }
  public static boolean registerGlobalReceiver(net.minecraft.util.Identifier id, PlayChannelHandler h){return true;}
  public static boolean canSend(net.minecraft.util.Identifier id){return true;}
  public static void send(net.minecraft.util.Identifier id, net.minecraft.network.PacketByteBuf b){}
}""")
c("net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents", """
public class ClientPlayConnectionEvents {
  public interface Join { void onPlayReady(net.minecraft.client.network.ClientPlayNetworkHandler h, net.fabricmc.fabric.api.networking.v1.PacketSender s, net.minecraft.client.MinecraftClient c); }
  public interface Disconnect { void onPlayDisconnect(net.minecraft.client.network.ClientPlayNetworkHandler h, net.minecraft.client.MinecraftClient c); }
  public static final net.fabricmc.fabric.api.event.Event<Join> JOIN = null;
  public static final net.fabricmc.fabric.api.event.Event<Disconnect> DISCONNECT = null;
}""")
c("net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents", """
public class ClientTickEvents {
  public interface EndTick { void onEndTick(net.minecraft.client.MinecraftClient c); }
  public static final net.fabricmc.fabric.api.event.Event<EndTick> END_CLIENT_TICK = null;
}""")
c("net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext", """
public interface WorldRenderContext {
  net.minecraft.client.util.math.MatrixStack matrixStack(); float tickDelta(); net.minecraft.client.render.Camera camera();
  org.joml.Matrix4f projectionMatrix(); net.minecraft.client.world.ClientWorld world();
}""")
c("net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents", """
public class WorldRenderEvents {
  public interface AfterTranslucent { void afterTranslucent(WorldRenderContext c); }
  public static final net.fabricmc.fabric.api.event.Event<AfterTranslucent> AFTER_TRANSLUCENT = null;
}""")
c("net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback", """
public interface HudRenderCallback {
  net.fabricmc.fabric.api.event.Event<HudRenderCallback> EVENT = null;
  void onHudRender(net.minecraft.client.gui.DrawContext c, float tickDelta);
}""")
c("net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback", """
public interface ItemTooltipCallback {
  net.fabricmc.fabric.api.event.Event<ItemTooltipCallback> EVENT = null;
  void getTooltip(net.minecraft.item.ItemStack s, net.minecraft.client.item.TooltipContext c, java.util.List<net.minecraft.text.Text> lines);
}""")
c("net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper", "public class KeyBindingHelper { public static net.minecraft.client.option.KeyBinding registerKeyBinding(net.minecraft.client.option.KeyBinding k){return k;} }")
c("net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource", "public interface FabricClientCommandSource { void sendFeedback(net.minecraft.text.Text t); }")
c("net.fabricmc.fabric.api.client.command.v2.ClientCommandManager", """
public class ClientCommandManager {
  public static com.mojang.brigadier.builder.LiteralArgumentBuilder<FabricClientCommandSource> literal(String n){return null;}
  public static <T> com.mojang.brigadier.builder.RequiredArgumentBuilder<FabricClientCommandSource, T> argument(String n, com.mojang.brigadier.arguments.ArgumentType<T> t){return null;}
}""")
c("net.minecraft.command.CommandRegistryAccess", "public class CommandRegistryAccess {}")
c("net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback", """
public interface ClientCommandRegistrationCallback {
  net.fabricmc.fabric.api.event.Event<ClientCommandRegistrationCallback> EVENT = null;
  void register(com.mojang.brigadier.CommandDispatcher<FabricClientCommandSource> d, net.minecraft.command.CommandRegistryAccess a);
}""")

for fq, body in S.items():
    pkg, name = fq.rsplit(".", 1)
    d = os.path.join(OUT, *pkg.split("."))
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, name + ".java"), "w") as f:
        f.write(f"package {pkg};\n\n{body}\n")
print(len(S), "stub classes")

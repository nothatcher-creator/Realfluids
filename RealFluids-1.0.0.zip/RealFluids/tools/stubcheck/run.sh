#!/bin/sh
# Offline compile check for phones/Termux (no Gradle, no Minecraft download needed):
#   sh tools/stubcheck/run.sh                 -> compiles the whole mod against API stubs
#   sh tools/stubcheck/run.sh <yarn> <fabric> -> also checks every stub name against real Yarn
#                                               mappings and Fabric API sources (git clones)
# It catches Java mistakes in the mod; the real build still happens in GitHub Actions.
set -e
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
TMP=${TMPDIR:-/tmp}/realfluids-stubcheck
rm -rf "$TMP" && mkdir -p "$TMP/out"
python3 "$ROOT/tools/stubcheck/stubs.py" "$TMP/stubs"
find "$TMP/stubs" -name '*.java' > "$TMP/stubs.txt"
find "$ROOT/src/main/java" -name '*.java' > "$TMP/mod.txt"
javac -proc:none -d "$TMP/out" @"$TMP/stubs.txt" @"$TMP/mod.txt"
echo "mod compiles against stubs"
if [ -n "$1" ]; then python3 "$ROOT/tools/stubcheck/verify.py" "$TMP/stubs" "$1/mappings" "$2"; fi

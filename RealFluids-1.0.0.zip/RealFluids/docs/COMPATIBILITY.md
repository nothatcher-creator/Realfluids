# Compatibility and limits

## Works with
- **Sodium / Embeddium / Lithium:** yes. Rendering uses Fabric's world-render events and vanilla's position/colour shader.
- **Android launchers (Pojav, Zalith, Fold Craft, etc.):** yes.
  - There are no custom shaders and no compute.
  - Bind a touch button to Z.
  - Start on `quality: low`.
- **Fabulous graphics:** works. Fluid draws after the translucent pass.

## Partly
- **Iris shader packs:** the fluid still draws, but packs replace vanilla shaders, so its lighting may look flatter or brighter than terrain. Turn the pack off if it looks wrong.

## Known limits
- **Client-side simulation.** The server syncs the pours and scoops, not every particle. Two players can see slightly different splashes, but the amount and place of fluid stays the same.
- **Region boxes.** Each pour simulates inside a box (24 × 20 blocks by default) with walls at its edges, and at most 4 boxes per dimension. Raise `regionWidth`, `regionHeight` and `maxRegions` on a strong PC.
- **Mobs and items.** Only the local player feels the fluid. Mobs, items and boats don't.
- **Breathing.** Real fluid doesn't drown you, and it doesn't put out or light fires on blocks.
- **Pistons and redstone.** Nothing special happens; blocks they move are picked up like any terrain change, within about half a second.
- **Cauldrons.** Using a real-fluid bucket on a cauldron behaves like vanilla and the bucket loses its settings.

# In-game test checklist

Run these after each build. The engine itself (`SimTests`) is covered by CI. This checklist covers the Minecraft side, which cannot be automated without a game client.

## Basics (singleplayer, creative)
- [ ] **Editor opens.** Hold a water bucket and press Z. The editor opens with 4 tabs. Holding anything else shows "Hold a bucket…" in the action bar.
- [ ] **Saving the bucket.** Pick **Honey** and press Save. The tooltip reads "Real fluid: Honey" and the action bar confirms.
- [ ] **Pouring.** Right-click the ground. A honey mound appears, slumps slowly and stays heaped. No vanilla water block is placed.
- [ ] **Water flow.** Pour Water into a 3×3 hole. It splashes, then settles flat at the right level. No water leaks through the blocks.
- [ ] **Partial blocks.** Pour onto stairs, slabs and fence lines. The water runs down the stairs and doesn't pass through slabs.
- [ ] **Layering.** Pour Oil onto settled Water. The oil ends up on top.
- [ ] **Scooping.** Right-click the fluid with an empty bucket. The fluid level drops, and you get a filled bucket named after the fluid.
- [ ] **Survival pour.** In survival, pouring leaves an empty bucket that still says "Real fluid" and refills from vanilla water with the same settings.

## Player physics
- [ ] **Water.** Wade into water. You slow down and sink slowly. Holding jump swims up, sneaking dives, and walking pushes waves.
- [ ] **Splash.** Jump in from 10 blocks up. You hear a splash, see droplets and a wave, and take no fall damage.
- [ ] **Mercury.** You float high on Mercury.
- [ ] **Honey.** Honey nearly stops you, and you can barely climb out.
- [ ] **Lava preset.** It glows at night and sets you on fire. Stepping out, then into water, puts the fire out.
- [ ] **Underwater view.** With your head under the surface, the screen is tinted with the fluid colour and the surface is visible from below.

## Pour modes
- [ ] **Stream.** It flows from the bucket for its duration.
- [ ] **Fountain.** It shoots up and rains down.
- [ ] **Amount.** Set Amount to 64 with a big Sphere. The pour hits the particle limit but the game doesn't crash. `/realfluids stats` shows the particle count.

## Lifecycle
- [ ] **Save and restore.** Leave the world and rejoin. The fluid is back where it was and doesn't fall through the ground while chunks load.
- [ ] **Clear.** `/realfluids clear` removes it, and `/realfluids quality low` switches to bigger cells for new pours.
- [ ] **Dimensions.** Fluid poured in the Nether stays in the Nether.

## Multiplayer (dedicated server + 2 clients)
- [ ] **Shared pours.** Player A pours, and player B sees the same pour.
- [ ] **Shared scoops.** Player A scoops, and the fluid also goes down for player B.
- [ ] **Reach check.** Pouring farther than 9 blocks away is rejected by the server.
- [ ] **Server without the mod.** The editor says the mod must be installed on the server, and nothing crashes.

## Performance (watch F3 FPS)
- [ ] **FPS.** Medium quality with a 30-block dam break keeps the frame rate smooth. If the CPU can't keep up, the water moves slower instead.
- [ ] **Phone.** Low quality on a phone stays playable.

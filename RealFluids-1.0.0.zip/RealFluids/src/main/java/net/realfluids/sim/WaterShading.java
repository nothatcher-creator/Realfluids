package net.realfluids.sim;

/**
 * Per-vertex water shading done on the CPU: Fresnel reflection of the sky, sun glints, soft diffuse,
 * foam, and clarity-driven transparency. Computing this per vertex lets the mod draw with Minecraft's
 * plain position/colour shader, which works on every GPU and Android launcher (no custom GLSL).
 * The offline preview tool uses the very same function.
 */
public final class WaterShading {
    private WaterShading() { }

    /**
     * @param nx..nz   unit surface normal
     * @param vx..vz   unit vector from the surface point towards the camera
     * @param sx..sz   unit vector towards the sun (or moon)
     * @param sunPower 0 at night / under cover, 1 in full daylight
     * @param base     fluid colour (RGB)
     * @param sky      sky colour to reflect (RGB)
     * @param light    0..1 combined block/sky light at the vertex
     * @return ARGB colour
     */
    public static int shade(float nx, float ny, float nz, float vx, float vy, float vz, float sx, float sy, float sz,
                            float sunPower, int base, int sky, float light, float clarity, float foam, boolean glow) {
        float br = ((base >> 16) & 0xFF) / 255f, bg = ((base >> 8) & 0xFF) / 255f, bb = (base & 0xFF) / 255f;
        if (glow) {
            // molten look: brighter where the surface faces the viewer, darker crust at grazing angles
            float facing = Math.max(0f, nx * vx + ny * vy + nz * vz);
            float k = 0.75f + 0.45f * facing;
            float hot = Math.max(0f, 1f - foam);
            return argb(1f, br * k + 0.15f * hot, bg * k * 0.9f + 0.05f * hot, bb * k * 0.8f);
        }
        float cos = Math.max(0f, nx * vx + ny * vy + nz * vz);
        float f1 = 1f - cos, f2 = f1 * f1;
        float fresnel = 0.02f + 0.98f * f2 * f2 * f1;
        float ndl = nx * sx + ny * sy + nz * sz;
        float diffuse = 0.42f + 0.58f * Math.max(0f, ndl) * sunPower;
        float lum = 0.12f + 0.88f * light;
        // body colour (light scattered inside the fluid)
        float r = br * diffuse * lum, g = bg * diffuse * lum, b = bb * diffuse * lum;
        // reflected sky
        float kr = Math.min(0.9f, fresnel) * (0.35f + 0.65f * (1f - clarity * 0.6f));
        float sr = ((sky >> 16) & 0xFF) / 255f * lum, sg = ((sky >> 8) & 0xFF) / 255f * lum, sb = (sky & 0xFF) / 255f * lum;
        r += (sr - r) * kr; g += (sg - g) * kr; b += (sb - b) * kr;
        // sun glint: reflect(-v, n) . sun
        float dot = vx * nx + vy * ny + vz * nz;
        float rx = 2f * dot * nx - vx, ry = 2f * dot * ny - vy, rz = 2f * dot * nz - vz;
        float rs = Math.max(0f, rx * sx + ry * sy + rz * sz);
        float spec = (float) Math.pow(rs, 160.0) * 2.2f * sunPower * light + (float) Math.pow(rs, 18.0) * 0.12f * sunPower * light;
        r += spec; g += spec; b += spec * 0.95f;
        float alpha = 0.32f + 0.62f * clarity;
        alpha = alpha + (1f - alpha) * Math.min(1f, fresnel * 1.4f) + spec * 0.5f;
        // whitewater
        if (foam > 0.01f) {
            float fw = Math.min(1f, foam * 1.15f);
            float white = 0.95f * (0.45f + 0.55f * diffuse) * lum;
            r += (white - r) * fw; g += (white - g) * fw; b += (white - b) * fw;
            alpha += (0.96f - alpha) * fw;
        }
        return argb(Math.min(1f, alpha), r, g, b);
    }

    public static int argb(float a, float r, float g, float b) {
        int ia = clamp255(a), ir = clamp255(r), ig = clamp255(g), ib = clamp255(b);
        return (ia << 24) | (ir << 16) | (ig << 8) | ib;
    }

    private static int clamp255(float v) {
        int i = (int) (v * 255f + 0.5f);
        return i < 0 ? 0 : (i > 255 ? 255 : i);
    }
}

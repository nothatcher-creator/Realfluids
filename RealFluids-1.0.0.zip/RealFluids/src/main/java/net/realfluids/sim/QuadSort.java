package net.realfluids.sim;

import java.util.Arrays;

/** Linear-time back-to-front ordering for translucent quads (counting sort on quantised distance). */
public final class QuadSort {
    public static final int BUCKETS = 2048;

    private QuadSort() { }

    /**
     * Writes into {@code order[0..n)} the quad indices from farthest to nearest.
     * @param distSq squared camera distance of each quad's centre
     * @param counts scratch array of length {@link #BUCKETS} + 1
     */
    public static void backToFront(float[] distSq, int n, int[] order, int[] counts) {
        if (n <= 0) return;
        float max = 1e-6f;
        for (int i = 0; i < n; i++) if (distSq[i] > max) max = distSq[i];
        // bucket on distance (sqrt), which spreads nearby quads - where order errors show - over more buckets
        float scale = (BUCKETS - 1) / (float) Math.sqrt(max);
        Arrays.fill(counts, 0, BUCKETS + 1, 0);
        for (int i = 0; i < n; i++) counts[bucket(distSq[i], scale) + 1]++;
        for (int b = 1; b <= BUCKETS; b++) counts[b] += counts[b - 1];
        for (int i = 0; i < n; i++) order[counts[bucket(distSq[i], scale)]++] = i;
    }

    private static int bucket(float d2, float scale) {
        int k = (int) (Math.sqrt(Math.max(0f, d2)) * scale);
        if (k > BUCKETS - 1) k = BUCKETS - 1;
        return (BUCKETS - 1) - k; // 0 = farthest
    }
}

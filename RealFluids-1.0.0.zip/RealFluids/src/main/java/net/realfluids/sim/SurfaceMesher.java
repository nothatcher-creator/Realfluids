package net.realfluids.sim;

import java.util.Arrays;

/**
 * Turns particles into a smooth, closed water surface.
 *
 * 1. Splat particles onto a density field (smooth kernel, ~1 cell radius), along with colour and foam.
 * 2. Blur once, extend the field into walls so water meets blocks without a gap.
 * 3. Extract the iso-surface with Surface Nets (dual contouring without the QEF): smooth, quad-based,
 *    no lookup tables, consistent winding (counter-clockwise seen from outside = Minecraft front faces).
 *
 * Isolated particles (spray, droplets) don't produce surface and are returned as {@link Mesh#spray} points.
 * Output coordinates are in BLOCKS relative to the domain's min corner.
 */
public final class SurfaceMesher {
    public static final float ISO = 0.5f;
    private static final float KERNEL_RADIUS = 1.0f;          // cells
    private static final float KERNEL_INTEGRAL = 0.63829f;    // 4*pi*16/315: integral of (1-r^2)^3 over the unit ball

    private int sx, sy, sz;
    private float[] dens, densTmp, cr, cg, cb, ca, cw, fo;
    private int[] dual;

    public static final class Mesh {
        public int quads;
        public float[] pos = new float[0];   // quads*4*3
        public float[] nrm = new float[0];   // quads*4*3
        public int[] rgb = new int[0];       // quads*4, ARGB where A = clarity (0 clear .. 255 opaque)
        public float[] foam = new float[0];  // quads*4
        public int sprayCount;
        public float[] spray = new float[0]; // xyz per droplet
        public int[] sprayRgb = new int[0];
        public float[] sprayFoam = new float[0];
        /** 0 = airborne droplet (billboard), 1 = resting film (flat puddle splat on the ground). */
        public byte[] sprayKind = new byte[0];
        public boolean glow;
        public float h;
        public int ox, oy, oz;

        void ensure(int q) {
            if (pos.length < q * 12) {
                int cap = Math.max(q, pos.length / 12 * 2 + 64);
                pos = Arrays.copyOf(pos, cap * 12); nrm = Arrays.copyOf(nrm, cap * 12);
                rgb = Arrays.copyOf(rgb, cap * 4); foam = Arrays.copyOf(foam, cap * 4);
            }
        }

        void ensureSpray(int n) {
            if (sprayRgb.length < n) {
                int cap = Math.max(n, sprayRgb.length * 2 + 64);
                spray = Arrays.copyOf(spray, cap * 3); sprayRgb = Arrays.copyOf(sprayRgb, cap); sprayFoam = Arrays.copyOf(sprayFoam, cap);
                sprayKind = Arrays.copyOf(sprayKind, cap);
            }
        }
    }

    /** Builds a mesh into {@code out} (reused to avoid garbage). */
    public Mesh build(FluidDomain d, int smoothingPasses, int maxQuads, int maxSpray, Mesh out) {
        if (out == null) out = new Mesh();
        out.quads = 0; out.sprayCount = 0; out.h = d.h; out.ox = d.ox; out.oy = d.oy; out.oz = d.oz;
        // samples sit at cell centres, padded by one ring of empty samples on every side
        int nsx = d.nx + 2, nsy = d.ny + 2, nsz = d.nz + 2;
        int n = nsx * nsy * nsz;
        if (dens == null || dens.length != n || sx != nsx || sy != nsy || sz != nsz) {
            sx = nsx; sy = nsy; sz = nsz;
            dens = new float[n]; densTmp = new float[n]; cr = new float[n]; cg = new float[n]; cb = new float[n]; ca = new float[n]; cw = new float[n]; fo = new float[n];
            dual = new int[(sx - 1) * (sy - 1) * (sz - 1)];
        } else {
            Arrays.fill(dens, 0f); Arrays.fill(cr, 0f); Arrays.fill(cg, 0f); Arrays.fill(cb, 0f); Arrays.fill(ca, 0f); Arrays.fill(cw, 0f); Arrays.fill(fo, 0f);
        }
        int count = d.particleCount();
        if (count == 0) return out;
        float[] px = d.px(), py = d.py(), pz = d.pz(), pf = d.foam();
        int[] col = d.colors();
        byte[] fl = d.flags();
        int glowVotes = 0;
        final float r = KERNEL_RADIUS, r2 = r * r;
        int bx0 = sx, bx1 = 0, by0 = sy, by1 = 0, bz0 = sz, bz1 = 0;
        for (int p = 0; p < count; p++) {
            // sample (I,J,K) is at cell-unit position (I-0.5, J-0.5, K-0.5)
            float x = px[p] + 0.5f, y = py[p] + 0.5f, z = pz[p] + 0.5f;
            int i0 = (int) Math.ceil(x - r), i1 = (int) Math.floor(x + r);
            int j0 = (int) Math.ceil(y - r), j1 = (int) Math.floor(y + r);
            int k0 = (int) Math.ceil(z - r), k1 = (int) Math.floor(z + r);
            int c = col[p];
            float rr = (c >> 16) & 0xFF, gg = (c >> 8) & 0xFF, bb = c & 0xFF, aa = (c >>> 24) & 0xFF, ff = pf[p];
            if ((fl[p] & 2) != 0) glowVotes++;
            for (int k = Math.max(0, k0); k <= Math.min(sz - 1, k1); k++) {
                float dz = k - z;
                for (int j = Math.max(0, j0); j <= Math.min(sy - 1, j1); j++) {
                    float dy = j - y;
                    for (int i = Math.max(0, i0); i <= Math.min(sx - 1, i1); i++) {
                        float dx = i - x;
                        float q = (dx * dx + dy * dy + dz * dz) / r2;
                        if (q >= 1f) continue;
                        float t = 1f - q, wgt = t * t * t;
                        int idx = i + sx * (j + sy * k);
                        dens[idx] += wgt;
                        cr[idx] += wgt * rr; cg[idx] += wgt * gg; cb[idx] += wgt * bb; ca[idx] += wgt * aa; fo[idx] += wgt * ff; cw[idx] += wgt;
                    }
                }
            }
            int si = (int) x, sj = (int) y, sk = (int) z;
            if (si < bx0) bx0 = si; if (si > bx1) bx1 = si;
            if (sj < by0) by0 = sj; if (sj > by1) by1 = sj;
            if (sk < bz0) bz0 = sk; if (sk > bz1) bz1 = sk;
        }
        out.glow = glowVotes * 2 > count;
        float norm = 1f / (d.ppc * KERNEL_INTEGRAL);
        for (int i = 0; i < n; i++) dens[i] *= norm;
        // the outer ring must stay empty so the surface closes at the domain's (invisible) walls
        for (int k = 0; k < sz; k++) for (int j = 0; j < sy; j++) { dens[sx * (j + sy * k)] = 0f; dens[sx - 1 + sx * (j + sy * k)] = 0f; }
        for (int k = 0; k < sz; k++) for (int i = 0; i < sx; i++) { dens[i + sx * sy * k] = 0f; dens[i + sx * ((sy - 1) + sy * k)] = 0f; }
        for (int j = 0; j < sy; j++) for (int i = 0; i < sx; i++) { dens[i + sx * j] = 0f; dens[i + sx * (j + sy * (sz - 1))] = 0f; }
        // region of interest (+2 samples for blur/gradients)
        bx0 = Math.max(1, bx0 - 2); by0 = Math.max(1, by0 - 2); bz0 = Math.max(1, bz0 - 2);
        bx1 = Math.min(sx - 2, bx1 + 2); by1 = Math.min(sy - 2, by1 + 2); bz1 = Math.min(sz - 2, bz1 + 2);

        // spray: particles in thin regions render as droplets instead of surface
        for (int p = 0; p < count && out.sprayCount < maxSpray; p++) {
            int idx = Math.round(px[p] + 0.5f) + sx * (Math.round(py[p] + 0.5f) + sy * Math.round(pz[p] + 0.5f));
            if (idx < 0 || idx >= n || dens[idx] >= 0.3f) continue;
            out.ensureSpray(out.sprayCount + 1);
            int s = out.sprayCount++;
            out.spray[s * 3] = px[p] * d.h; out.spray[s * 3 + 1] = py[p] * d.h; out.spray[s * 3 + 2] = pz[p] * d.h;
            out.sprayRgb[s] = col[p];
            out.sprayFoam[s] = pf[p];
            float sp2 = d.vx()[p] * d.vx()[p] + d.vy()[p] * d.vy()[p] + d.vz()[p] * d.vz()[p];
            int ci = (int) px[p], cj = (int) Math.floor(py[p] - 0.6f), ck = (int) pz[p];
            boolean supported = d.worldSolid(ci, cj, ck) || d.occupancyAt(ci, cj, ck) > 0.5f;
            out.sprayKind[s] = (byte) (supported && sp2 < 1.5f ? 1 : 0);
        }

        for (int pass = 0; pass < smoothingPasses; pass++) {
            blurAxis(dens, densTmp, 1, bx0, bx1, by0, by1, bz0, bz1);
            blurAxis(densTmp, dens, sx, bx0, bx1, by0, by1, bz0, bz1);
            blurAxis(dens, densTmp, sx * sy, bx0, bx1, by0, by1, bz0, bz1);
            System.arraycopy(densTmp, 0, dens, 0, n);
        }

        // walls: copy the strongest neighbouring fluid value into solid samples so the surface reaches the block
        for (int k = bz0; k <= bz1; k++) for (int j = by0; j <= by1; j++) for (int i = bx0; i <= bx1; i++) {
            if (!d.worldSolid(i - 1, j - 1, k - 1)) continue;
            int idx = i + sx * (j + sy * k);
            float m = dens[idx];
            m = Math.max(m, dens[idx - 1]); m = Math.max(m, dens[idx + 1]);
            m = Math.max(m, dens[idx - sx]); m = Math.max(m, dens[idx + sx]);
            m = Math.max(m, dens[idx - sx * sy]); m = Math.max(m, dens[idx + sx * sy]);
            densTmp[idx] = m;
        }
        for (int k = bz0; k <= bz1; k++) for (int j = by0; j <= by1; j++) for (int i = bx0; i <= bx1; i++) {
            if (d.worldSolid(i - 1, j - 1, k - 1)) {
                int idx = i + sx * (j + sy * k);
                dens[idx] = densTmp[idx];
            }
        }

        // ---- surface nets: one vertex per dual cell that straddles the iso level
        int dx = sx - 1, dy = sy - 1;
        int ci0 = Math.max(0, bx0 - 1), cj0 = Math.max(0, by0 - 1), ck0 = Math.max(0, bz0 - 1);
        int ci1 = Math.min(sx - 2, bx1), cj1 = Math.min(sy - 2, by1), ck1 = Math.min(sz - 2, bz1);
        for (int k = ck0; k <= ck1; k++) for (int j = cj0; j <= cj1; j++) Arrays.fill(dual, ci0 + dx * (j + dy * k), ci1 + 1 + dx * (j + dy * k), -1);

        float[] vtx = vertexBuf(0);
        int verts = 0;
        float[] corner = new float[8];
        for (int k = ck0; k <= ck1; k++) for (int j = cj0; j <= cj1; j++) for (int i = ci0; i <= ci1; i++) {
            int mask = 0;
            for (int c = 0; c < 8; c++) {
                float val = dens[(i + (c & 1)) + sx * ((j + ((c >> 1) & 1)) + sy * (k + ((c >> 2) & 1)))];
                corner[c] = val;
                if (val > ISO) mask |= 1 << c;
            }
            if (mask == 0 || mask == 0xFF) continue;
            float ax = 0, ay = 0, az = 0; int ne = 0;
            for (int e = 0; e < 12; e++) {
                int a = EDGES[e * 2], b = EDGES[e * 2 + 1];
                boolean ia = ((mask >> a) & 1) != 0, ib = ((mask >> b) & 1) != 0;
                if (ia == ib) continue;
                float t = (ISO - corner[a]) / (corner[b] - corner[a]);
                ax += (a & 1) + t * ((b & 1) - (a & 1));
                ay += ((a >> 1) & 1) + t * (((b >> 1) & 1) - ((a >> 1) & 1));
                az += ((a >> 2) & 1) + t * (((b >> 2) & 1) - ((a >> 2) & 1));
                ne++;
            }
            vtx = vertexBuf((verts + 1) * 3);
            vtx[verts * 3] = i + ax / ne; vtx[verts * 3 + 1] = j + ay / ne; vtx[verts * 3 + 2] = k + az / ne;
            dual[i + dx * (j + dy * k)] = verts++;
        }

        // ---- quads across every sample edge with a sign change
        for (int k = Math.max(1, ck0); k <= ck1 + 1 && k < sz - 1; k++)
            for (int j = Math.max(1, cj0); j <= cj1 + 1 && j < sy - 1; j++)
                for (int i = Math.max(1, ci0); i <= ci1 + 1 && i < sx - 1; i++) {
                    if (out.quads >= maxQuads) return finish(out);
                    int idx = i + sx * (j + sy * k);
                    boolean in = dens[idx] > ISO;
                    // x edge (i,j,k)-(i+1,j,k): dual cells (i, j-1..j, k-1..k)
                    if (i + 1 < sx && in != (dens[idx + 1] > ISO)) {
                        quad(out, vtx, d, in,
                            dual[i + dx * ((j - 1) + dy * (k - 1))], dual[i + dx * (j + dy * (k - 1))],
                            dual[i + dx * (j + dy * k)], dual[i + dx * ((j - 1) + dy * k)]);
                    }
                    // y edge: dual cells (i-1..i, j, k-1..k); +y = z x x
                    if (j + 1 < sy && in != (dens[idx + sx] > ISO)) {
                        quad(out, vtx, d, in,
                            dual[(i - 1) + dx * (j + dy * (k - 1))], dual[(i - 1) + dx * (j + dy * k)],
                            dual[i + dx * (j + dy * k)], dual[i + dx * (j + dy * (k - 1))]);
                    }
                    // z edge: dual cells (i-1..i, j-1..j, k); +z = x x y
                    if (k + 1 < sz && in != (dens[idx + sx * sy] > ISO)) {
                        quad(out, vtx, d, in,
                            dual[(i - 1) + dx * ((j - 1) + dy * k)], dual[i + dx * ((j - 1) + dy * k)],
                            dual[i + dx * (j + dy * k)], dual[(i - 1) + dx * (j + dy * k)]);
                    }
                }
        return finish(out);
    }

    private Mesh finish(Mesh out) { return out; }

    private float[] vbuf = new float[3 * 1024];
    private float[] vertexBuf(int need) {
        if (vbuf.length < need) vbuf = Arrays.copyOf(vbuf, Math.max(need, vbuf.length * 2));
        return vbuf;
    }

    /**
     * Emits one quad. a,b,c,e are in the order that gives a +axis normal; when the inside of the fluid is on
     * the low side (normal must point +axis) we keep it, otherwise reverse.
     */
    private void quad(Mesh out, float[] vtx, FluidDomain d, boolean insideLow, int a, int b, int c, int e) {
        if (a < 0 || b < 0 || c < 0 || e < 0) return;
        out.ensure(out.quads + 1);
        int[] order = insideLow ? new int[] { a, b, c, e } : new int[] { a, e, c, b };
        int q = out.quads++;
        for (int t = 0; t < 4; t++) {
            int vI = order[t];
            float x = vtx[vI * 3], y = vtx[vI * 3 + 1], z = vtx[vI * 3 + 2];
            int o = (q * 4 + t) * 3;
            // sample space -> cell units: sample I is at cell coordinate I - 0.5
            out.pos[o] = (x - 0.5f) * d.h; out.pos[o + 1] = (y - 0.5f) * d.h; out.pos[o + 2] = (z - 0.5f) * d.h;
            gradient(x, y, z, out.nrm, o);
            int idx = Math.round(x) + sx * (Math.round(y) + sy * Math.round(z));
            float wgt = cw[idx];
            if (wgt <= 1e-6f) { // pick any neighbour that has colour
                for (int s = 0; s < 8 && wgt <= 1e-6f; s++) {
                    idx = ((int) x + (s & 1)) + sx * (((int) y + ((s >> 1) & 1)) + sy * ((int) z + ((s >> 2) & 1)));
                    wgt = cw[idx];
                }
            }
            if (wgt > 1e-6f) {
                int rr = (int) (cr[idx] / wgt), gg = (int) (cg[idx] / wgt), bb = (int) (cb[idx] / wgt), aa = (int) (ca[idx] / wgt);
                out.rgb[q * 4 + t] = (aa << 24) | (rr << 16) | (gg << 8) | bb; // alpha byte = clarity
                out.foam[q * 4 + t] = Math.min(1f, fo[idx] / wgt);
            } else {
                out.rgb[q * 4 + t] = 0x592F7FD8;
                out.foam[q * 4 + t] = 0f;
            }
        }
    }

    /** Outward normal = -grad(density), trilinear over central differences. */
    private void gradient(float x, float y, float z, float[] out, int o) {
        int i = Math.max(1, Math.min(sx - 3, (int) x)), j = Math.max(1, Math.min(sy - 3, (int) y)), k = Math.max(1, Math.min(sz - 3, (int) z));
        float tx = x - i, ty = y - j, tz = z - k;
        float gx = 0, gy = 0, gz = 0;
        for (int c = 0; c < 8; c++) {
            int ii = i + (c & 1), jj = j + ((c >> 1) & 1), kk = k + ((c >> 2) & 1);
            float wgt = ((c & 1) != 0 ? tx : 1 - tx) * (((c >> 1) & 1) != 0 ? ty : 1 - ty) * (((c >> 2) & 1) != 0 ? tz : 1 - tz);
            int idx = ii + sx * (jj + sy * kk);
            gx += wgt * (dens[idx + 1] - dens[idx - 1]);
            gy += wgt * (dens[idx + sx] - dens[idx - sx]);
            gz += wgt * (dens[idx + sx * sy] - dens[idx - sx * sy]);
        }
        float len = (float) Math.sqrt(gx * gx + gy * gy + gz * gz);
        if (len < 1e-6f) { out[o] = 0; out[o + 1] = 1; out[o + 2] = 0; return; }
        out[o] = -gx / len; out[o + 1] = -gy / len; out[o + 2] = -gz / len;
    }

    private void blurAxis(float[] src, float[] dst, int stride, int x0, int x1, int y0, int y1, int z0, int z1) {
        System.arraycopy(src, 0, dst, 0, src.length);
        for (int k = z0; k <= z1; k++) for (int j = y0; j <= y1; j++) for (int i = x0; i <= x1; i++) {
            int idx = i + sx * (j + sy * k);
            dst[idx] = 0.25f * src[idx - stride] + 0.5f * src[idx] + 0.25f * src[idx + stride];
        }
    }

    /** Corner pairs of the 12 cube edges (corner bit0 = x, bit1 = y, bit2 = z). */
    private static final int[] EDGES = {
        0, 1, 2, 3, 4, 5, 6, 7,   // along x
        0, 2, 1, 3, 4, 6, 5, 7,   // along y
        0, 4, 1, 5, 2, 6, 3, 7    // along z
    };
}

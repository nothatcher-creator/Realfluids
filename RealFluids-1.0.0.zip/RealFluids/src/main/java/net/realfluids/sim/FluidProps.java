package net.realfluids.sim;

import java.util.Locale;

/**
 * Everything the bucket editor can change. Pure Java (no Minecraft classes) so the solver
 * and its tests run anywhere. Serialized to/from a flat key-value form by {@link #toMap}/{@link #fromMap}
 * which the mod layer stores in the bucket's NBT.
 */
public final class FluidProps {
    public enum Shape { CUBE, SPHERE, COLUMN, SHEET }
    public enum Mode { INSTANT, STREAM, FOUNTAIN }

    // ---- look
    public String name = "Water";
    public int color = 0x2F7FD8;        // RGB tint of deep fluid
    public float clarity = 0.35f;       // 0 = glass clear, 1 = opaque
    public float foam = 0.6f;           // how readily white water forms
    public boolean glow = false;        // render at full brightness (lava look)

    // ---- physics
    public float viscosity = 0.0f;      // 0 = water ... 1 = tar (log-mapped, see kinematicViscosity)
    public float density = 1000f;       // kg/m^3. Heavier fluids sink below lighter ones; affects buoyancy
    public float gravity = 1.0f;        // gravity multiplier
    public float splash = 0.92f;        // FLIP/PIC blend: higher = livelier splashes, lower = calmer/damped
    public float surfaceTension = 0.2f; // cohesion: rounds droplets and holds puddles together
    public boolean hot = false;         // sets players on fire, makes steam where it touches water

    // ---- pouring
    public float volume = 4f;           // cubic blocks per pour
    public Shape shape = Shape.CUBE;
    public Mode mode = Mode.INSTANT;
    public float speed = 6f;            // blocks/s for STREAM / FOUNTAIN
    public float duration = 3f;         // seconds a STREAM / FOUNTAIN runs

    public FluidProps copy() {
        FluidProps p = new FluidProps();
        p.name = name; p.color = color; p.clarity = clarity; p.foam = foam; p.glow = glow;
        p.viscosity = viscosity; p.density = density; p.gravity = gravity; p.splash = splash;
        p.surfaceTension = surfaceTension; p.hot = hot;
        p.volume = volume; p.shape = shape; p.mode = mode; p.speed = speed; p.duration = duration;
        return p;
    }

    /** Clamp every field into its legal range (data may come from an edited item or the network). */
    public FluidProps sanitize() {
        if (name == null || name.isBlank()) name = "Custom";
        if (name.length() > 32) name = name.substring(0, 32);
        color &= 0xFFFFFF;
        clarity = clamp(clarity, 0f, 1f);
        foam = clamp(foam, 0f, 1f);
        viscosity = clamp(viscosity, 0f, 1f);
        density = clamp(density, 50f, 14000f);
        gravity = clamp(gravity, 0f, 3f);
        splash = clamp(splash, 0f, 0.99f);
        surfaceTension = clamp(surfaceTension, 0f, 1f);
        volume = clamp(volume, 0.25f, 512f);
        speed = clamp(speed, 0f, 30f);
        duration = clamp(duration, 0.5f, 60f);
        if (shape == null) shape = Shape.CUBE;
        if (mode == null) mode = Mode.INSTANT;
        return this;
    }

    /**
     * Kinematic viscosity in m^2/s (= blocks^2/s). Slider 0 is water (~1e-6, effectively inviscid at
     * block scale); 0.5 is honey-like; 1 is tar/lava-like. Log mapping makes the slider feel even.
     */
    public float kinematicViscosity() {
        if (viscosity <= 0.001f) return 0f;
        // artist scale (block-sized blobs need far more than real-world values to look thick):
        // 0.3 ~ 0.016 m^2/s (oil), 0.6 ~ 0.25 (syrup), 0.85 ~ 2.5 (honey), 1.0 = 10 m^2/s (lava/tar)
        return (float) (VISC_MIN * Math.pow(10.0, viscosity * VISC_DECADES));
    }

    public static final double VISC_MIN = 1e-3, VISC_DECADES = 4.0;

    /** Inverse of {@link #kinematicViscosity()}. */
    public static float sliderFromKinematic(double nu) {
        if (nu <= 0) return 0f;
        return clamp((float) (Math.log10(nu / VISC_MIN) / VISC_DECADES), 0f, 1f);
    }

    public static float clamp(float v, float lo, float hi) {
        if (Float.isNaN(v)) return lo;
        return v < lo ? lo : (v > hi ? hi : v);
    }

    // ---------------------------------------------------------------- presets

    public static final String[] PRESETS = { "Water", "Ocean", "Swamp", "Honey", "Slime", "Oil", "Milk", "Mercury", "Lava" };

    public static FluidProps preset(String id) {
        FluidProps p = new FluidProps();
        switch (id.toLowerCase(Locale.ROOT)) {
            case "ocean" -> { p.name = "Ocean"; p.color = 0x1C5E8C; p.clarity = 0.55f; p.foam = 0.9f; p.density = 1025f; }
            case "swamp" -> { p.name = "Swamp"; p.color = 0x4E5D2A; p.clarity = 0.85f; p.foam = 0.25f; p.viscosity = 0.12f; p.density = 1040f; }
            case "honey" -> { p.name = "Honey"; p.color = 0xD99A1E; p.clarity = 0.55f; p.foam = 0f; p.viscosity = 0.85f; p.density = 1420f; p.splash = 0.3f; p.surfaceTension = 0.5f; }
            case "slime" -> { p.name = "Slime"; p.color = 0x6CC24A; p.clarity = 0.6f; p.foam = 0f; p.viscosity = 0.8f; p.density = 1100f; p.splash = 0.5f; p.surfaceTension = 0.9f; }
            case "oil" -> { p.name = "Oil"; p.color = 0x1A1408; p.clarity = 0.97f; p.foam = 0.05f; p.viscosity = 0.3f; p.density = 870f; p.surfaceTension = 0.3f; }
            case "milk" -> { p.name = "Milk"; p.color = 0xF3F0E6; p.clarity = 0.97f; p.foam = 0.5f; p.viscosity = 0.04f; p.density = 1035f; }
            case "mercury" -> { p.name = "Mercury"; p.color = 0xBFC4C8; p.clarity = 1f; p.foam = 0f; p.viscosity = 0.02f; p.density = 13500f; p.surfaceTension = 1f; p.splash = 0.95f; }
            case "lava" -> { p.name = "Lava"; p.color = 0xFF5A0A; p.clarity = 1f; p.foam = 0f; p.viscosity = 0.93f; p.density = 3100f; p.glow = true; p.hot = true; p.splash = 0.3f; p.surfaceTension = 0.4f; }
            default -> { /* water defaults */ }
        }
        return p;
    }

    // ---------------------------------------------------------------- flat serialization

    /**
     * Name of the preset this mix most resembles (colour, density, thickness, heat), or "Mixed fluid"
     * when nothing is close. Used to label buckets filled from simulated fluid.
     */
    public static String closestPresetName(FluidProps p) {
        String best = "Mixed fluid";
        double bestD = 0.18;
        for (String id : PRESETS) {
            FluidProps q = preset(id);
            double dr = (((p.color >> 16) & 0xFF) - ((q.color >> 16) & 0xFF)) / 255.0;
            double dg = (((p.color >> 8) & 0xFF) - ((q.color >> 8) & 0xFF)) / 255.0;
            double db = ((p.color & 0xFF) - (q.color & 0xFF)) / 255.0;
            double dd = Math.log((p.density + 1.0) / (q.density + 1.0)) / 3.0;
            double dv = p.viscosity - q.viscosity;
            double d = Math.sqrt((dr * dr + dg * dg + db * db) / 3.0 + dd * dd + dv * dv) + (p.hot != q.hot ? 1.0 : 0.0);
            if (d < bestD) { bestD = d; best = q.name; }
        }
        return best;
    }

    public java.util.Map<String, Object> toMap() {
        java.util.LinkedHashMap<String, Object> m = new java.util.LinkedHashMap<>();
        m.put("name", name); m.put("color", color); m.put("clarity", clarity); m.put("foam", foam); m.put("glow", glow);
        m.put("viscosity", viscosity); m.put("density", density); m.put("gravity", gravity); m.put("splash", splash);
        m.put("surfaceTension", surfaceTension); m.put("hot", hot);
        m.put("volume", volume); m.put("shape", shape.name()); m.put("mode", mode.name()); m.put("speed", speed); m.put("duration", duration);
        return m;
    }

    public static FluidProps fromMap(java.util.Map<String, ?> m) {
        FluidProps p = new FluidProps();
        if (m == null) return p;
        p.name = str(m, "name", p.name);
        p.color = (int) num(m, "color", p.color);
        p.clarity = (float) num(m, "clarity", p.clarity);
        p.foam = (float) num(m, "foam", p.foam);
        p.glow = bool(m, "glow", p.glow);
        p.viscosity = (float) num(m, "viscosity", p.viscosity);
        p.density = (float) num(m, "density", p.density);
        p.gravity = (float) num(m, "gravity", p.gravity);
        p.splash = (float) num(m, "splash", p.splash);
        p.surfaceTension = (float) num(m, "surfaceTension", p.surfaceTension);
        p.hot = bool(m, "hot", p.hot);
        p.volume = (float) num(m, "volume", p.volume);
        p.speed = (float) num(m, "speed", p.speed);
        p.duration = (float) num(m, "duration", p.duration);
        try { p.shape = Shape.valueOf(str(m, "shape", p.shape.name())); } catch (IllegalArgumentException ignored) { }
        try { p.mode = Mode.valueOf(str(m, "mode", p.mode.name())); } catch (IllegalArgumentException ignored) { }
        return p.sanitize();
    }

    private static String str(java.util.Map<String, ?> m, String k, String d) { Object v = m.get(k); return v instanceof String s ? s : d; }
    private static double num(java.util.Map<String, ?> m, String k, double d) { Object v = m.get(k); return v instanceof Number n ? n.doubleValue() : d; }
    private static boolean bool(java.util.Map<String, ?> m, String k, boolean d) {
        Object v = m.get(k);
        if (v instanceof Boolean b) return b;
        if (v instanceof Number n) return n.intValue() != 0;
        return d;
    }

    @Override public String toString() {
        return String.format(Locale.ROOT, "%s(visc=%.2f dens=%.0f grav=%.1f vol=%.1f %s/%s)", name, viscosity, density, gravity, volume, shape, mode);
    }
}

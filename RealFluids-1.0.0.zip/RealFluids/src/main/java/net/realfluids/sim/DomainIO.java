package net.realfluids.sim;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** Binary save format for simulated fluid (one file per world). Versioned and bounds-checked. */
public final class DomainIO {
    public static final int MAGIC = 0x52464C44; // "RFLD"
    public static final int VERSION = 1;

    public record Saved(String dimension, FluidDomain domain) { }

    private DomainIO() { }

    public static void write(DataOutputStream out, List<Saved> regions) throws IOException {
        out.writeInt(MAGIC);
        out.writeInt(VERSION);
        out.writeInt(regions.size());
        float[] props = new float[6];
        for (Saved s : regions) {
            FluidDomain d = s.domain();
            out.writeUTF(s.dimension());
            out.writeInt(d.ox); out.writeInt(d.oy); out.writeInt(d.oz);
            out.writeInt(d.nx); out.writeInt(d.ny); out.writeInt(d.nz);
            out.writeFloat(d.h); out.writeInt(d.ppc);
            int n = d.particleCount();
            out.writeInt(n);
            for (int p = 0; p < n; p++) {
                out.writeFloat(d.px[p]); out.writeFloat(d.py[p]); out.writeFloat(d.pz[p]);
                out.writeFloat(d.vx[p]); out.writeFloat(d.vy[p]); out.writeFloat(d.vz[p]);
                out.writeInt(d.pColor[p]); out.writeByte(d.pFlags[p]); out.writeFloat(d.pFoam[p]);
                d.particleProps(p, props);
                for (float f : props) out.writeFloat(f);
            }
        }
    }

    /**
     * Reads saved regions. Cell size / particles-per-cell come from the file so old saves keep working
     * after the quality setting changes; {@code maxParticles} caps how much is restored.
     */
    public static List<Saved> read(DataInputStream in, int maxParticles) throws IOException {
        if (in.readInt() != MAGIC) throw new IOException("not a Real Fluids save");
        int version = in.readInt();
        if (version < 1 || version > VERSION) throw new IOException("unsupported save version " + version);
        int regions = in.readInt();
        if (regions < 0 || regions > 64) throw new IOException("corrupt region count " + regions);
        List<Saved> out = new ArrayList<>();
        float[] props = new float[6];
        for (int r = 0; r < regions; r++) {
            String dim = in.readUTF();
            int ox = in.readInt(), oy = in.readInt(), oz = in.readInt();
            int nx = in.readInt(), ny = in.readInt(), nz = in.readInt();
            float h = in.readFloat();
            int ppc = in.readInt();
            if (nx < 4 || ny < 4 || nz < 4 || nx > 512 || ny > 512 || nz > 512 || !(h >= 0.1f && h <= 2f) || ppc < 1 || ppc > 27) {
                throw new IOException("corrupt region header");
            }
            int n = in.readInt();
            if (n < 0 || n > 2_000_000) throw new IOException("corrupt particle count " + n);
            FluidDomain d = new FluidDomain(ox, oy, oz, nx, ny, nz, h, ppc, Math.max(maxParticles, 1000), System.nanoTime() ^ r);
            for (int p = 0; p < n; p++) {
                float x = in.readFloat(), y = in.readFloat(), z = in.readFloat();
                float vx = in.readFloat(), vy = in.readFloat(), vz = in.readFloat();
                int color = in.readInt(); byte flags = in.readByte(); float foam = in.readFloat();
                for (int i = 0; i < 6; i++) props[i] = in.readFloat();
                if (!Float.isFinite(x + y + z + vx + vy + vz)) continue;
                d.restoreParticle(x, y, z, vx, vy, vz, color, flags, foam, props);
            }
            out.add(new Saved(dim, d));
        }
        return out;
    }
}

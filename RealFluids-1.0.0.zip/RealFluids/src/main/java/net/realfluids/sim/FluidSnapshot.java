package net.realfluids.sim;

/**
 * Read-only copy of the fluid state the game thread needs (player buoyancy, currents, raycasts,
 * underwater tint). Only the bounding box of the fluid is copied, so it stays cheap on phones.
 * Filled by the simulation thread, read by the game thread under {@code synchronized (snapshot)}.
 */
public final class FluidSnapshot {
    public int ox, oy, oz;      // world block origin of the domain
    public float h;             // cell size (blocks)
    public int i0, j0, k0;      // bbox min cell (inclusive)
    public int sx, sy, sz;      // bbox size in cells (0 when empty)
    public float[] occ = new float[0];   // 0..1 per cell
    public float[] vel = new float[0];   // blocks/s, 3 per cell
    public float[] dens = new float[0];  // kg/m^3 per cell (0 where empty)
    public float[] visc = new float[0];  // viscosity slider 0..1 per cell
    public int[] rgb = new int[0];       // average colour
    public byte[] hot = new byte[0];     // 1 if mostly hot fluid
    public long version;

    void ensure(int n) {
        if (occ.length < n) {
            occ = new float[n]; vel = new float[n * 3]; dens = new float[n]; visc = new float[n]; rgb = new int[n]; hot = new byte[n];
        }
    }

    /** Cell index in this snapshot for a world position, or -1 when outside the copied box. */
    public int indexAt(double wx, double wy, double wz) {
        if (sx == 0) return -1;
        int i = (int) Math.floor((wx - ox) / h) - i0, j = (int) Math.floor((wy - oy) / h) - j0, k = (int) Math.floor((wz - oz) / h) - k0;
        if (i < 0 || j < 0 || k < 0 || i >= sx || j >= sy || k >= sz) return -1;
        return i + sx * (j + sy * k);
    }

    public float occupancyAt(double wx, double wy, double wz) {
        int idx = indexAt(wx, wy, wz);
        return idx < 0 ? 0f : occ[idx];
    }
}

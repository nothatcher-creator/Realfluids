package net.realfluids.sim;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.SplittableRandom;

/**
 * A box of space simulated with FLIP/PIC on a staggered (MAC) grid - the same family of method
 * used by Houdini FLIP and Blender's Mantaflow, scaled to run on a phone.
 *
 * Units: positions in CELL units inside the box (0..nx etc.), velocities in cells/second.
 * One cell is {@code h} blocks (1 block = 1 metre). The box's min corner sits at world block (ox,oy,oz).
 *
 * Not thread-safe: a domain is owned by one simulation thread. Talk to it from other threads
 * through {@link FluidWorld}.
 */
public final class FluidDomain {
    public static final byte AIR = 0, FLUID = 1, SOLID = 2, SINK = 3;
    public static final float GRAVITY = 9.81f; // m/s^2 = blocks/s^2

    public final int ox, oy, oz;
    public final int nx, ny, nz;
    public final float h;
    public final int ppc; // particles seeded per cell
    final int nCells;

    // MAC grid
    final float[] u, v, w, uOld, vOld, wOld, uWt, vWt, wWt, uTmp, vTmp, wTmp;
    final byte[] uValid, vValid, wValid;
    final byte[] uFrozen, wFrozen; // horizontal faces held still by yield stress this substep
    final byte[] type;      // AIR / FLUID / SOLID / SINK for this step
    final byte[] world;     // SOLID / SINK / AIR from the game world (snapshot)
    final float[] cVisc, cDens, cGrav, cCount, cTension, cYield, cR, cG, cB, cHot;
    // bounding box of fluid cells (+margin) for this step; most loops only visit this region
    int bi0, bi1, bj0, bj1, bk0, bk1;
    final float[] occupancy; // particles in cell / ppc (clamped)

    // pressure solve (compact over fluid cells)
    private int[] fluidCells = new int[0];
    private int nFluid;
    private final int[] cellToFluid;
    private float[] diag = new float[0], precon = new float[0], pr = new float[0], rr = new float[0], zz = new float[0], ss = new float[0], qq = new float[0];
    private int[] npx = new int[0], npy = new int[0], npz = new int[0], nmx = new int[0], nmy = new int[0], nmz = new int[0];
    public int lastPcgIterations;
    public float lastPcgResidual;

    // particles (structure of arrays)
    int count;
    float[] px, py, pz, vx, vy, vz, pVisc, pDens, pGrav, pFlip, pFoam, pFoamGen, pTension, pYield, pIdle;
    int[] pColor;
    byte[] pFlags; // bit0 = hot, bit1 = glow
    public final int maxParticles;

    final List<Emitter> emitters = new ArrayList<>();
    private final List<float[]> impulses = new ArrayList<>(); // x,y,z,r,vx,vy,vz,strength (cell units)
    private final SplittableRandom rng;

    // bookkeeping
    public long steps;
    public int absorbed;
    private float settledTime;
    private boolean sleeping;
    public float lastMaxSpeed, lastMeanSpeed;
    public float lastStepMillis;

    /** Seconds a lone, resting particle (a thin wet film) survives before soaking away. 0 = never. */
    public float evaporateSeconds = 30f;

    /**
     * Thick fluids (honey, slime, lava) have a yield stress: below it they don't flow at all, so they hold a
     * mound instead of creeping out into a film (a Bingham-plastic approximation). Returns the yield as a
     * "friction" deceleration in cells/s^2 at h = 0.5; the resting slope angle is about atan(yield / g) with g = 19.6 cells/s^2.
     */
    static float yieldFor(float viscositySlider) {
        float s = Math.max(0f, viscositySlider - 0.15f) / 0.85f;
        return 16f * s * s;
    }

    public static final class Emitter {
        public float x, y, z, dx, dy, dz, speed, radius, rate, remaining, carry;
        public FluidProps props;
    }

    public FluidDomain(int ox, int oy, int oz, int nx, int ny, int nz, float h, int ppc, int maxParticles, long seed) {
        if (nx < 4 || ny < 4 || nz < 4) throw new IllegalArgumentException("domain too small");
        this.ox = ox; this.oy = oy; this.oz = oz;
        this.nx = nx; this.ny = ny; this.nz = nz;
        this.h = h;
        this.ppc = Math.max(1, Math.min(27, ppc));
        this.maxParticles = maxParticles;
        this.nCells = nx * ny * nz;
        int nu = (nx + 1) * ny * nz, nv = nx * (ny + 1) * nz, nw = nx * ny * (nz + 1);
        u = new float[nu]; uOld = new float[nu]; uWt = new float[nu]; uTmp = new float[nu]; uValid = new byte[nu];
        v = new float[nv]; vOld = new float[nv]; vWt = new float[nv]; vTmp = new float[nv]; vValid = new byte[nv];
        w = new float[nw]; wOld = new float[nw]; wWt = new float[nw]; wTmp = new float[nw]; wValid = new byte[nw];
        uFrozen = new byte[nu]; wFrozen = new byte[nw];
        type = new byte[nCells];
        world = new byte[nCells];
        cVisc = new float[nCells]; cDens = new float[nCells]; cGrav = new float[nCells]; cCount = new float[nCells]; cTension = new float[nCells]; cYield = new float[nCells];
        cR = new float[nCells]; cG = new float[nCells]; cB = new float[nCells]; cHot = new float[nCells];
        occupancy = new float[nCells];
        cellToFluid = new int[nCells];
        int cap = 1024;
        px = new float[cap]; py = new float[cap]; pz = new float[cap];
        vx = new float[cap]; vy = new float[cap]; vz = new float[cap];
        pVisc = new float[cap]; pDens = new float[cap]; pGrav = new float[cap]; pFlip = new float[cap];
        pFoam = new float[cap]; pFoamGen = new float[cap]; pTension = new float[cap]; pYield = new float[cap]; pIdle = new float[cap];
        pColor = new int[cap]; pFlags = new byte[cap];
        rng = new SplittableRandom(seed);
    }

    // ------------------------------------------------------------------ indexing

    final int c(int i, int j, int k) { return i + nx * (j + ny * k); }
    final int ui(int i, int j, int k) { return i + (nx + 1) * (j + ny * k); }
    final int vi(int i, int j, int k) { return i + nx * (j + (ny + 1) * k); }
    final int wi(int i, int j, int k) { return i + nx * (j + ny * k); }

    /** Cell type with everything outside the box treated as a wall. */
    final byte typeAt(int i, int j, int k) {
        if (i < 0 || j < 0 || k < 0 || i >= nx || j >= ny || k >= nz) return SOLID;
        return type[c(i, j, k)];
    }

    public final boolean worldSolid(int i, int j, int k) {
        if (i < 0 || j < 0 || k < 0 || i >= nx || j >= ny || k >= nz) return true;
        return world[c(i, j, k)] == SOLID;
    }

    public int particleCount() { return count; }
    public boolean isSleeping() { return sleeping; }
    public void wake() { sleeping = false; settledTime = 0f; }
    public boolean isEmpty() { return count == 0 && emitters.isEmpty(); }
    public int emitterCount() { return emitters.size(); }

    /** Replace the world mask (SOLID/SINK/AIR per cell). Wakes the domain if anything changed. */
    public void setWorld(byte[] mask) {
        if (mask.length != nCells) throw new IllegalArgumentException("mask size");
        if (!Arrays.equals(mask, world)) {
            System.arraycopy(mask, 0, world, 0, nCells);
            wake();
        }
    }

    public boolean containsWorldPoint(double x, double y, double z, double marginBlocks) {
        return x >= ox + marginBlocks && y >= oy + marginBlocks && z >= oz + marginBlocks
            && x <= ox + nx * h - marginBlocks && y <= oy + ny * h - marginBlocks && z <= oz + nz * h - marginBlocks;
    }

    // ------------------------------------------------------------------ particles

    private void ensureCapacity(int need) {
        if (need <= px.length) return;
        int cap = Math.min(Math.max(need, px.length * 2), Math.max(need, maxParticles));
        px = Arrays.copyOf(px, cap); py = Arrays.copyOf(py, cap); pz = Arrays.copyOf(pz, cap);
        vx = Arrays.copyOf(vx, cap); vy = Arrays.copyOf(vy, cap); vz = Arrays.copyOf(vz, cap);
        pVisc = Arrays.copyOf(pVisc, cap); pDens = Arrays.copyOf(pDens, cap); pGrav = Arrays.copyOf(pGrav, cap);
        pFlip = Arrays.copyOf(pFlip, cap); pFoam = Arrays.copyOf(pFoam, cap); pFoamGen = Arrays.copyOf(pFoamGen, cap);
        pTension = Arrays.copyOf(pTension, cap); pYield = Arrays.copyOf(pYield, cap); pIdle = Arrays.copyOf(pIdle, cap); pColor = Arrays.copyOf(pColor, cap); pFlags = Arrays.copyOf(pFlags, cap);
    }

    /** Adds one particle (cell-unit position and velocity). Returns false when full or blocked. */
    public boolean addParticle(float x, float y, float z, float vxi, float vyi, float vzi, FluidProps p) {
        if (count >= maxParticles) return false;
        if (x < 0.01f || y < 0.01f || z < 0.01f || x > nx - 0.01f || y > ny - 0.01f || z > nz - 0.01f) return false;
        if (worldSolid((int) x, (int) y, (int) z)) return false;
        ensureCapacity(count + 1);
        int n = count++;
        px[n] = x; py[n] = y; pz[n] = z;
        vx[n] = vxi; vy[n] = vyi; vz[n] = vzi;
        pVisc[n] = p.kinematicViscosity();
        pDens[n] = p.density;
        pGrav[n] = p.gravity;
        pFlip[n] = p.splash;
        pFoam[n] = 0f;
        pFoamGen[n] = p.foam;
        pTension[n] = p.surfaceTension;
        pYield[n] = yieldFor(p.viscosity);
        pIdle[n] = 0f;
        // top byte carries the clarity so the renderer can make each fluid as see-through as its bucket says
        pColor[n] = (p.color & 0xFFFFFF) | (Math.round(FluidProps.clamp(p.clarity, 0f, 1f) * 255f) << 24);
        pFlags[n] = (byte) ((p.hot ? 1 : 0) | (p.glow ? 2 : 0));
        return true;
    }

    private void removeParticle(int n) {
        int last = --count;
        if (n == last) return;
        px[n] = px[last]; py[n] = py[last]; pz[n] = pz[last];
        vx[n] = vx[last]; vy[n] = vy[last]; vz[n] = vz[last];
        pVisc[n] = pVisc[last]; pDens[n] = pDens[last]; pGrav[n] = pGrav[last]; pFlip[n] = pFlip[last];
        pFoam[n] = pFoam[last]; pFoamGen[n] = pFoamGen[last]; pTension[n] = pTension[last];
        pYield[n] = pYield[last]; pIdle[n] = pIdle[last];
        pColor[n] = pColor[last]; pFlags[n] = pFlags[last];
    }

    /**
     * Pours fluid. Position/direction are world coordinates (blocks). For INSTANT the shape is filled
     * at once around the point; STREAM and FOUNTAIN create an emitter.
     * @return number of particles created immediately
     */
    public int spawn(double wx, double wy, double wz, float dirX, float dirY, float dirZ, FluidProps props) {
        wake();
        float cx = (float) ((wx - ox) / h), cy = (float) ((wy - oy) / h), cz = (float) ((wz - oz) / h);
        if (props.mode != FluidProps.Mode.INSTANT) {
            Emitter e = new Emitter();
            e.x = cx; e.y = cy; e.z = cz;
            float len = (float) Math.sqrt(dirX * dirX + dirY * dirY + dirZ * dirZ);
            if (props.mode == FluidProps.Mode.FOUNTAIN || len < 1e-4f) { e.dx = 0; e.dy = 1; e.dz = 0; }
            else { e.dx = dirX / len; e.dy = dirY / len; e.dz = dirZ / len; }
            e.speed = props.speed / h;
            e.radius = Math.max(0.6f, 0.25f / h);
            float totalParticles = props.volume / (h * h * h) * ppc;
            e.rate = totalParticles / props.duration;
            e.remaining = props.duration;
            e.props = props.copy();
            emitters.add(e);
            return 0;
        }
        int cells = Math.max(1, Math.round(props.volume / (h * h * h)));
        List<int[]> chosen = shapeCells(cx, cy, cz, cells, props.shape);
        int made = 0;
        int side = (int) Math.round(Math.cbrt(ppc));
        boolean cubic = side * side * side == ppc;
        for (int[] cell : chosen) {
            if (worldSolid(cell[0], cell[1], cell[2])) continue;
            for (int s = 0; s < ppc; s++) {
                float jx, jy, jz;
                if (cubic) { // jittered stratified sampling: no clumps, no gaps
                    int a = s % side, b = (s / side) % side, d = s / (side * side);
                    jx = (a + (float) rng.nextDouble()) / side; jy = (b + (float) rng.nextDouble()) / side; jz = (d + (float) rng.nextDouble()) / side;
                } else {
                    jx = (float) rng.nextDouble(); jy = (float) rng.nextDouble(); jz = (float) rng.nextDouble();
                }
                if (addParticle(cell[0] + jx, cell[1] + jy, cell[2] + jz, 0f, 0f, 0f, props)) made++;
            }
        }
        return made;
    }

    /** Exactly {@code cells} cells (inside the box) forming the requested shape around (cx, cy-bottom, cz). */
    private List<int[]> shapeCells(float cx, float cy, float cz, int cells, FluidProps.Shape shape) {
        List<int[]> cand = new ArrayList<>();
        List<Float> key = new ArrayList<>();
        int foot = Math.max(1, Math.round(1f / h));
        switch (shape) {
            case COLUMN -> {
                int height = (cells + foot * foot - 1) / (foot * foot);
                for (int j = 0; j < height; j++) for (int k = 0; k < foot; k++) for (int i = 0; i < foot; i++) {
                    cand.add(new int[] { (int) Math.floor(cx - foot / 2f + i), (int) Math.floor(cy) + j, (int) Math.floor(cz - foot / 2f + k) });
                    key.add((float) j);
                }
            }
            case SHEET -> {
                int side = (int) Math.ceil(Math.sqrt(cells)) + 1;
                for (int k = -side; k <= side; k++) for (int i = -side; i <= side; i++) {
                    cand.add(new int[] { (int) Math.floor(cx) + i, (int) Math.floor(cy), (int) Math.floor(cz) + k });
                    key.add((float) Math.max(Math.abs(i + 0.5f), Math.abs(k + 0.5f)) + 0.001f * (i * i + k * k));
                }
            }
            case SPHERE -> {
                int r = (int) Math.ceil(Math.cbrt(3.0 * cells / (4.0 * Math.PI))) + 1;
                float ccy = cy + r; // sphere sits on the target point
                for (int k = -r; k <= r; k++) for (int j = -r; j <= r; j++) for (int i = -r; i <= r; i++) {
                    cand.add(new int[] { (int) Math.floor(cx) + i, (int) Math.floor(ccy) + j, (int) Math.floor(cz) + k });
                    key.add((float) (i + 0.5f) * (i + 0.5f) + (j + 0.5f) * (j + 0.5f) + (k + 0.5f) * (k + 0.5f));
                }
            }
            default -> {
                int side = (int) Math.ceil(Math.cbrt(cells));
                for (int j = 0; j < side + 1; j++) for (int k = 0; k < side; k++) for (int i = 0; i < side; i++) {
                    cand.add(new int[] { (int) Math.floor(cx - side / 2f) + i, (int) Math.floor(cy) + j, (int) Math.floor(cz - side / 2f) + k });
                    key.add((float) j * 1000f + Math.abs(i - side / 2f + 0.5f) + Math.abs(k - side / 2f + 0.5f)); // fill bottom-up, centre-out
                }
            }
        }
        Integer[] order = new Integer[cand.size()];
        for (int i = 0; i < order.length; i++) order[i] = i;
        java.util.Arrays.sort(order, (a, b) -> Float.compare(key.get(a), key.get(b)));
        List<int[]> out = new ArrayList<>(cells);
        for (Integer idx : order) {
            int[] cc = cand.get(idx);
            if (cc[0] < 0 || cc[1] < 0 || cc[2] < 0 || cc[0] >= nx || cc[1] >= ny || cc[2] >= nz) continue;
            if (worldSolid(cc[0], cc[1], cc[2])) continue;
            out.add(cc);
            if (out.size() >= cells) break;
        }
        return out;
    }

    /** Removes up to {@code maxRemove} particles within radius (world blocks). Returns the average props of what was removed. */
    public RemovalResult remove(double wx, double wy, double wz, double radiusBlocks, int maxRemove) {
        float cx = (float) ((wx - ox) / h), cy = (float) ((wy - oy) / h), cz = (float) ((wz - oz) / h);
        float r = (float) (radiusBlocks / h), r2 = r * r;
        RemovalResult res = new RemovalResult();
        for (int n = count - 1; n >= 0 && res.removed < maxRemove; n--) {
            float dx = px[n] - cx, dy = py[n] - cy, dz = pz[n] - cz;
            if (dx * dx + dy * dy + dz * dz <= r2) {
                res.accumulate(this, n);
                removeParticle(n);
            }
        }
        if (res.removed > 0) wake();
        return res;
    }

    public static final class RemovalResult {
        public int removed;
        double r, g, b, a, visc, dens, grav, flip, foam, tension;
        int hot, glow;

        void accumulate(FluidDomain d, int n) {
            removed++;
            int c = d.pColor[n];
            r += (c >> 16) & 0xFF; g += (c >> 8) & 0xFF; b += c & 0xFF; a += (c >>> 24) & 0xFF;
            visc += d.pVisc[n]; dens += d.pDens[n]; grav += d.pGrav[n]; flip += d.pFlip[n]; foam += d.pFoamGen[n]; tension += d.pTension[n];
            hot += (d.pFlags[n] & 1); glow += (d.pFlags[n] & 2) >> 1;
        }

        /** Volume in cubic blocks this removal represents. */
        public float volume(FluidDomain d) { return removed / (float) d.ppc * d.h * d.h * d.h; }

        /** Props approximating the removed mix (for filling a bucket). */
        public FluidProps toProps(FluidProps base) {
            FluidProps p = base == null ? new FluidProps() : base.copy();
            if (removed == 0) return p;
            double n = removed;
            p.color = ((int) (r / n) << 16) | ((int) (g / n) << 8) | (int) (b / n);
            p.clarity = (float) (a / n / 255.0);
            double nu = visc / n;
            p.viscosity = FluidProps.sliderFromKinematic(nu);
            p.density = (float) (dens / n);
            p.gravity = (float) (grav / n);
            p.splash = (float) (flip / n);
            p.foam = (float) (foam / n);
            p.surfaceTension = (float) (tension / n);
            p.hot = hot * 2 > removed;
            p.glow = glow * 2 > removed;
            return p.sanitize();
        }
    }

    /** Push the fluid around a moving body (player, item, mob). World units. */
    public void addImpulse(double wx, double wy, double wz, double radiusBlocks, double vxb, double vyb, double vzb, float strength) {
        impulses.add(new float[] { (float) ((wx - ox) / h), (float) ((wy - oy) / h), (float) ((wz - oz) / h), (float) (radiusBlocks / h),
            (float) (vxb / h), (float) (vyb / h), (float) (vzb / h), strength });
        if (Math.abs(vxb) + Math.abs(vyb) + Math.abs(vzb) > 0.3) wake();
    }

    public void clear() {
        count = 0;
        emitters.clear();
        impulses.clear();
    }

    // ------------------------------------------------------------------ stepping

    /** Advance by dt seconds (adaptive substeps limited by CFL). */
    public void step(float dt, int maxSubsteps) {
        long t0 = System.nanoTime();
        if (count == 0 && emitters.isEmpty()) { impulses.clear(); lastStepMillis = 0; return; }
        if (sleeping && emitters.isEmpty() && impulses.isEmpty()) { lastStepMillis = 0; return; }
        float maxV = Math.max(maxParticleSpeed(), 1e-3f);
        for (Emitter e : emitters) maxV = Math.max(maxV, e.speed);
        int sub = (int) Math.ceil(maxV * dt / 1.5f);
        sub = Math.max(1, Math.min(maxSubsteps, sub));
        float sdt = dt / sub;
        for (int s = 0; s < sub; s++) substep(sdt);
        impulses.clear();
        steps++;
        lastMaxSpeed = maxParticleSpeed();
        lastMeanSpeed = meanParticleSpeed();
        // sleep when settled (saves battery on phones). FLIP keeps a little sub-cell jitter forever,
        // so the test is on the average speed with a loose cap on the fastest particle.
        if (emitters.isEmpty() && lastMeanSpeed < 0.03f && lastMaxSpeed < 0.6f) {
            settledTime += dt;
            if (settledTime > 3f) sleeping = true;
        } else {
            settledTime = 0f;
        }
        lastStepMillis = (System.nanoTime() - t0) / 1e6f;
    }

    private float maxParticleSpeed() {
        float m = 0f;
        for (int n = 0; n < count; n++) {
            float s = vx[n] * vx[n] + vy[n] * vy[n] + vz[n] * vz[n];
            if (s > m) m = s;
        }
        return (float) Math.sqrt(m);
    }

    private float meanParticleSpeed() {
        if (count == 0) return 0f;
        double sum = 0;
        for (int n = 0; n < count; n++) sum += Math.sqrt(vx[n] * vx[n] + vy[n] * vy[n] + vz[n] * vz[n]);
        return (float) (sum / count);
    }

    void substep(float dt) {
        emit(dt);
        if (count == 0) return;
        classify();
        particlesToGrid();
        System.arraycopy(u, 0, uOld, 0, u.length);
        System.arraycopy(v, 0, vOld, 0, v.length);
        System.arraycopy(w, 0, wOld, 0, w.length);
        applyForces(dt);
        applyImpulses();
        enforceBoundaries();
        applyViscosity(dt);
        enforceBoundaries();
        Arrays.fill(uFrozen, (byte) 0);
        Arrays.fill(wFrozen, (byte) 0);
        project();
        // Thick fluids: look at the flow the pressure wants; where it is gentler than the yield stress the
        // goo stays put (faces frozen), elsewhere it flows with friction. Then project again with those constraints.
        if (applyYield(dt)) project();
        extrapolate(u, uValid, 0); extrapolate(v, vValid, 1); extrapolate(w, wValid, 2);
        enforceBoundaries();
        gridToParticles(dt);
        advect(dt);
    }

    private void emit(float dt) {
        for (int e = emitters.size() - 1; e >= 0; e--) {
            Emitter em = emitters.get(e);
            float want = em.rate * Math.min(dt, em.remaining) + em.carry;
            int n = (int) want;
            em.carry = want - n;
            // basis perpendicular to the emitter direction
            float ax = Math.abs(em.dy) < 0.9f ? 0 : 1, ay = Math.abs(em.dy) < 0.9f ? 1 : 0, az = 0;
            float bx = em.dy * az - em.dz * ay, by = em.dz * ax - em.dx * az, bz = em.dx * ay - em.dy * ax;
            float bl = (float) Math.sqrt(bx * bx + by * by + bz * bz); bx /= bl; by /= bl; bz /= bl;
            float cxv = em.dy * bz - em.dz * by, cyv = em.dz * bx - em.dx * bz, czv = em.dx * by - em.dy * bx;
            for (int i = 0; i < n; i++) {
                double ang = rng.nextDouble() * Math.PI * 2, rad = Math.sqrt(rng.nextDouble()) * em.radius;
                float ox1 = (float) (Math.cos(ang) * rad), oy1 = (float) (Math.sin(ang) * rad);
                float along = (float) rng.nextDouble() * em.speed * dt; // spread along the jet so it is continuous
                float x = em.x + bx * ox1 + cxv * oy1 + em.dx * along;
                float y = em.y + by * ox1 + cyv * oy1 + em.dy * along;
                float z = em.z + bz * ox1 + czv * oy1 + em.dz * along;
                addParticle(x, y, z, em.dx * em.speed, em.dy * em.speed, em.dz * em.speed, em.props);
            }
            em.remaining -= dt;
            if (em.remaining <= 0f) emitters.remove(e);
        }
    }

    private void classify() {
        System.arraycopy(world, 0, type, 0, nCells);
        Arrays.fill(cVisc, 0f); Arrays.fill(cDens, 0f); Arrays.fill(cGrav, 0f); Arrays.fill(cCount, 0f); Arrays.fill(cTension, 0f); Arrays.fill(cYield, 0f);
        Arrays.fill(cR, 0f); Arrays.fill(cG, 0f); Arrays.fill(cB, 0f); Arrays.fill(cHot, 0f);
        int mi0 = nx, mi1 = -1, mj0 = ny, mj1 = -1, mk0 = nz, mk1 = -1;
        for (int n = count - 1; n >= 0; n--) {
            int i = clampi((int) px[n], 0, nx - 1), j = clampi((int) py[n], 0, ny - 1), k = clampi((int) pz[n], 0, nz - 1);
            int ci = c(i, j, k);
            byte t = world[ci];
            if (t == SINK) { removeParticle(n); absorbed++; continue; }
            if (t == SOLID) {
                // a block appeared on top of fluid: lift the particle out, or drop it
                int jj = j;
                while (jj < ny && world[c(i, jj, k)] == SOLID && jj - j < 6) jj++;
                if (jj >= ny || world[c(i, jj, k)] == SOLID) { removeParticle(n); continue; }
                py[n] = jj + 0.5f;
                vy[n] = Math.max(vy[n], 0f);
                ci = c(i, jj, k);
                if (world[ci] == SINK) { removeParticle(n); absorbed++; continue; }
            }
            type[ci] = FLUID;
            cVisc[ci] += pVisc[n]; cDens[ci] += pDens[n]; cGrav[ci] += pGrav[n]; cTension[ci] += pTension[n]; cYield[ci] += pYield[n]; cCount[ci] += 1f;
            int col = pColor[n];
            cR[ci] += (col >> 16) & 0xFF; cG[ci] += (col >> 8) & 0xFF; cB[ci] += col & 0xFF; cHot[ci] += pFlags[n] & 1;
            int jj = ci / nx % ny;
            if (i < mi0) mi0 = i; if (i > mi1) mi1 = i;
            if (jj < mj0) mj0 = jj; if (jj > mj1) mj1 = jj;
            if (k < mk0) mk0 = k; if (k > mk1) mk1 = k;
        }
        final int m = 3;
        bi0 = Math.max(0, mi0 - m); bi1 = Math.min(nx - 1, mi1 + m);
        bj0 = Math.max(0, mj0 - m); bj1 = Math.min(ny - 1, mj1 + m);
        bk0 = Math.max(0, mk0 - m); bk1 = Math.min(nz - 1, mk1 + m);
        float inv = 1f / ppc;
        for (int ci = 0; ci < nCells; ci++) {
            float cnt = cCount[ci];
            if (cnt > 0) { cVisc[ci] /= cnt; cDens[ci] /= cnt; cGrav[ci] /= cnt; cTension[ci] /= cnt; cYield[ci] /= cnt; }
            occupancy[ci] = Math.min(1f, cnt * inv);
        }
    }

    // ------------------------------------------------------------------ transfer

    private void particlesToGrid() {
        Arrays.fill(u, 0f); Arrays.fill(uWt, 0f);
        Arrays.fill(v, 0f); Arrays.fill(vWt, 0f);
        Arrays.fill(w, 0f); Arrays.fill(wWt, 0f);
        for (int n = 0; n < count; n++) {
            splat(u, uWt, px[n], py[n] - 0.5f, pz[n] - 0.5f, vx[n], nx + 1, ny, nz, 0);
            splat(v, vWt, px[n] - 0.5f, py[n], pz[n] - 0.5f, vy[n], nx, ny + 1, nz, 1);
            splat(w, wWt, px[n] - 0.5f, py[n] - 0.5f, pz[n], vz[n], nx, ny, nz + 1, 2);
        }
        normalize(u, uWt, uValid);
        normalize(v, vWt, vValid);
        normalize(w, wWt, wValid);
    }

    private void splat(float[] g, float[] wt, float x, float y, float z, float val, int sx, int sy, int sz, int comp) {
        int i0 = (int) Math.floor(x), j0 = (int) Math.floor(y), k0 = (int) Math.floor(z);
        float tx = x - i0, ty = y - j0, tz = z - k0;
        for (int dk = 0; dk <= 1; dk++) {
            int k = k0 + dk; if (k < 0 || k >= sz) continue;
            float wz = dk == 0 ? 1 - tz : tz;
            for (int dj = 0; dj <= 1; dj++) {
                int j = j0 + dj; if (j < 0 || j >= sy) continue;
                float wy = dj == 0 ? 1 - ty : ty;
                for (int di = 0; di <= 1; di++) {
                    int i = i0 + di; if (i < 0 || i >= sx) continue;
                    float wgt = (di == 0 ? 1 - tx : tx) * wy * wz;
                    int idx = i + sx * (j + sy * k);
                    g[idx] += wgt * val;
                    wt[idx] += wgt;
                }
            }
        }
    }

    private static void normalize(float[] g, float[] wt, byte[] valid) {
        for (int i = 0; i < g.length; i++) {
            if (wt[i] > 1e-6f) { g[i] /= wt[i]; valid[i] = 1; }
            else { g[i] = 0f; valid[i] = 0; }
        }
    }

    final float sampleU(float[] g, float x, float y, float z) { return interp(g, x, y - 0.5f, z - 0.5f, nx + 1, ny, nz); }
    final float sampleV(float[] g, float x, float y, float z) { return interp(g, x - 0.5f, y, z - 0.5f, nx, ny + 1, nz); }
    final float sampleW(float[] g, float x, float y, float z) { return interp(g, x - 0.5f, y - 0.5f, z, nx, ny, nz + 1); }

    private static float interp(float[] g, float x, float y, float z, int sx, int sy, int sz) {
        x = clampf(x, 0f, sx - 1.0001f); y = clampf(y, 0f, sy - 1.0001f); z = clampf(z, 0f, sz - 1.0001f);
        int i = (int) x, j = (int) y, k = (int) z;
        float tx = x - i, ty = y - j, tz = z - k;
        int b = i + sx * (j + sy * k);
        int sxy = sx * sy;
        float c00 = g[b] * (1 - tx) + g[b + 1] * tx;
        float c10 = g[b + sx] * (1 - tx) + g[b + sx + 1] * tx;
        float c01 = g[b + sxy] * (1 - tx) + g[b + sxy + 1] * tx;
        float c11 = g[b + sxy + sx] * (1 - tx) + g[b + sxy + sx + 1] * tx;
        return (c00 * (1 - ty) + c10 * ty) * (1 - tz) + (c01 * (1 - ty) + c11 * ty) * tz;
    }

    // ------------------------------------------------------------------ forces

    private void applyForces(float dt) {
        final float g = GRAVITY / h;
        // mean density for buoyancy between different fluids (Boussinesq)
        double sum = 0;
        for (int n = 0; n < count; n++) sum += pDens[n];
        float rhoRef = count > 0 ? (float) (sum / count) : 1000f;
        for (int k = bk0; k <= bk1; k++) for (int j = Math.max(1, bj0); j <= bj1; j++) for (int i = bi0; i <= bi1; i++) {
            int a = c(i, j - 1, k), b = c(i, j, k);
            byte ta = type[a], tb = type[b];
            if (ta == SOLID || tb == SOLID) continue;
            boolean fa = ta == FLUID, fb = tb == FLUID;
            if (!fa && !fb) continue;
            float gs, rho;
            if (fa && fb) { gs = 0.5f * (cGrav[a] + cGrav[b]); rho = 0.5f * (cDens[a] + cDens[b]); }
            else if (fa) { gs = cGrav[a]; rho = cDens[a]; }
            else { gs = cGrav[b]; rho = cDens[b]; }
            float buoy = (rho - rhoRef) / rhoRef; // >0 heavier than average: sinks
            v[vi(i, j, k)] -= g * gs * (1f + clampf(buoy, -0.9f, 4f)) * dt;
        }
        // cohesion: pull surface fluid toward fuller cells (rounds droplets, keeps puddles together)
        for (int k = bk0; k <= bk1; k++) for (int j = bj0; j <= bj1; j++) for (int i = Math.max(1, bi0); i <= bi1; i++) cohesionFace(u, ui(i, j, k), c(i - 1, j, k), c(i, j, k), dt);
        for (int k = bk0; k <= bk1; k++) for (int j = Math.max(1, bj0); j <= bj1; j++) for (int i = bi0; i <= bi1; i++) cohesionFace(v, vi(i, j, k), c(i, j - 1, k), c(i, j, k), dt);
        for (int k = Math.max(1, bk0); k <= bk1; k++) for (int j = bj0; j <= bj1; j++) for (int i = bi0; i <= bi1; i++) cohesionFace(w, wi(i, j, k), c(i, j, k - 1), c(i, j, k), dt);
    }

    /**
     * Bingham-style yield on horizontal motion of supported goo. Slow faces are frozen: they become rigid
     * constraints in the pressure solve, so a mound can't slump sideways (and therefore can't sink either).
     * Faster faces lose a friction-like amount of speed.
     */
    private boolean applyYield(float dt) {
        final float scale = 0.5f / h; // yieldFor() is tuned for h = 0.5
        boolean any = false;
        for (int ci = 0; ci < nCells && !any; ci++) any = cYield[ci] > 0f;
        if (!any) return false;
        for (int k = bk0; k <= bk1; k++) for (int j = bj0; j <= bj1; j++) for (int i = bi0; i <= bi1 + 1; i++) yieldFace(u, uFrozen, ui(i, j, k), i - 1, j, k, i, j, k, scale, dt);
        for (int k = bk0; k <= bk1 + 1; k++) for (int j = bj0; j <= bj1; j++) for (int i = bi0; i <= bi1; i++) yieldFace(w, wFrozen, wi(i, j, k), i, j, k - 1, i, j, k, scale, dt);
        return true;
    }

    private void yieldFace(float[] g, byte[] frozen, int f, int ai, int aj, int ak, int bi, int bj, int bk, float scale, float dt) {
        byte ta = typeAt(ai, aj, ak), tb = typeAt(bi, bj, bk);
        if (ta == SOLID || tb == SOLID || (ta != FLUID && tb != FLUID)) return;
        float y = 0f; int n = 0;
        if (ta == FLUID) { y += cYield[c(ai, aj, ak)]; n++; }
        if (tb == FLUID) { y += cYield[c(bi, bj, bk)]; n++; }
        y /= n;
        if (y <= 0f) return;
        boolean supported = isSupport(typeAt(ai, aj - 1, ak)) || isSupport(typeAt(bi, bj - 1, bk));
        if (!supported) return; // falling goo is not slowed
        y *= scale;
        float vel = g[f];
        if (Math.abs(vel) < y * dt) { g[f] = 0f; frozen[f] = 1; }
        else g[f] = shrink(vel, y * dt);
    }

    private static boolean isSupport(byte t) { return t == SOLID || t == FLUID; }

    private static float shrink(float v, float by) { return v > by ? v - by : (v < -by ? v + by : 0f); }

    private float cellTension(int ci) { return cTension[ci]; }

    private void cohesionFace(float[] g, int f, int a, int b, float dt) {
        byte ta = type[a], tb = type[b];
        if (ta == SOLID || tb == SOLID) return;
        if (ta != FLUID && tb != FLUID) return;
        float oa = occupancy[a], ob = occupancy[b];
        if (oa > 0.95f && ob > 0.95f) return; // interior: pressure handles it
        float st = Math.max(cellTension(a), cellTension(b));
        if (st <= 0f) return;
        g[f] += st * 40f * (ob - oa) * dt;
    }

    private void applyImpulses() {
        for (float[] im : impulses) {
            float cx = im[0], cy = im[1], cz = im[2], r = Math.max(0.5f, im[3]), s = clampf(im[7], 0f, 1f);
            int i0 = (int) Math.floor(cx - r - 1), i1 = (int) Math.ceil(cx + r + 1);
            int j0 = (int) Math.floor(cy - r - 1), j1 = (int) Math.ceil(cy + r + 1);
            int k0 = (int) Math.floor(cz - r - 1), k1 = (int) Math.ceil(cz + r + 1);
            for (int k = Math.max(0, k0); k <= Math.min(nz - 1, k1); k++)
                for (int j = Math.max(0, j0); j <= Math.min(ny - 1, j1); j++)
                    for (int i = Math.max(0, i0); i <= Math.min(nx - 1, i1); i++) {
                        if (type[c(i, j, k)] != FLUID) continue;
                        float dx = i + 0.5f - cx, dy = j + 0.5f - cy, dz = k + 0.5f - cz;
                        float d2 = dx * dx + dy * dy + dz * dz;
                        if (d2 > r * r) continue;
                        float wgt = s * (1f - (float) Math.sqrt(d2) / r);
                        int fu = ui(i, j, k), fv = vi(i, j, k), fw = wi(i, j, k);
                        u[fu] += (im[4] - u[fu]) * wgt; u[fu + 1] += (im[4] - u[fu + 1]) * wgt;
                        v[fv] += (im[5] - v[fv]) * wgt; v[fv + nx] += (im[5] - v[fv + nx]) * wgt;
                        w[fw] += (im[6] - w[fw]) * wgt; w[fw + nx * ny] += (im[6] - w[fw + nx * ny]) * wgt;
                    }
        }
    }

    private void enforceBoundaries() {
        int i0 = bi0, i1 = bi1 + 1, j0 = bj0, j1 = bj1 + 1, k0 = bk0, k1 = bk1 + 1;
        for (int k = k0; k < k1; k++) for (int j = j0; j < j1; j++) for (int i = i0; i <= i1; i++)
            if (typeAt(i - 1, j, k) == SOLID || typeAt(i, j, k) == SOLID) u[ui(i, j, k)] = 0f;
        for (int k = k0; k < k1; k++) for (int j = j0; j <= j1; j++) for (int i = i0; i < i1; i++)
            if (typeAt(i, j - 1, k) == SOLID || typeAt(i, j, k) == SOLID) v[vi(i, j, k)] = 0f;
        for (int k = k0; k <= k1; k++) for (int j = j0; j < j1; j++) for (int i = i0; i < i1; i++)
            if (typeAt(i, j, k - 1) == SOLID || typeAt(i, j, k) == SOLID) w[wi(i, j, k)] = 0f;
    }

    // ------------------------------------------------------------------ viscosity (implicit Jacobi, no-slip at walls)

    private void applyViscosity(float dt) {
        float maxNu = 0f;
        for (int ci = 0; ci < nCells; ci++) if (type[ci] == FLUID && cVisc[ci] > maxNu) maxNu = cVisc[ci];
        float aMax = maxNu * dt / (h * h);
        if (aMax < 1e-4f) return;
        int iters = aMax < 0.05f ? 4 : (aMax < 0.5f ? 10 : 20);
        diffuse(u, uRhs(), uTmp, nx + 1, ny, nz, 0, dt, iters);
        diffuse(v, vRhs(), vTmp, nx, ny + 1, nz, 1, dt, iters);
        diffuse(w, wRhs(), wTmp, nx, ny, nz + 1, 2, dt, iters);
    }

    /** Viscosity of the cells on either side of a face (0 if neither is fluid). */
    private float faceVisc(int comp, int i, int j, int k) {
        int ai = i, aj = j, ak = k;
        if (comp == 0) ai--; else if (comp == 1) aj--; else ak--;
        byte ta = typeAt(ai, aj, ak), tb = typeAt(i, j, k);
        if (ta == SOLID || tb == SOLID) return -1f;
        float s = 0f; int n = 0;
        if (ta == FLUID) { s += cVisc[c(ai, aj, ak)]; n++; }
        if (tb == FLUID) { s += cVisc[c(i, j, k)]; n++; }
        return n == 0 ? -1f : s / n;
    }

    private void diffuse(float[] g, float[] rhs, float[] tmp, int sx, int sy, int sz, int comp, float dt, int iters) {
        System.arraycopy(g, 0, rhs, 0, g.length); // post-force field is the right-hand side
        float invH2 = dt / (h * h);
        for (int it = 0; it < iters; it++) {
            System.arraycopy(g, 0, tmp, 0, g.length);
            int i1 = Math.min(sx - 1, bi1 + 1), j1 = Math.min(sy - 1, bj1 + 1), k1 = Math.min(sz - 1, bk1 + 1);
            for (int k = bk0; k <= k1; k++) for (int j = bj0; j <= j1; j++) for (int i = bi0; i <= i1; i++) {
                float nu = faceVisc(comp, i, j, k);
                if (nu <= 0f) continue;
                float a = nu * invH2;
                int idx = i + sx * (j + sy * k);
                float sum = 0f; int cnt = 0;
                // neighbours of the same component; walls count as 0 (no-slip), air is skipped (free surface)
                if (i > 0) { int q = idx - 1; if (faceVisc(comp, i - 1, j, k) != -1f || isWallFace(comp, i - 1, j, k)) { sum += tmp[q]; cnt++; } } else cnt++;
                if (i < sx - 1) { int q = idx + 1; if (faceVisc(comp, i + 1, j, k) != -1f || isWallFace(comp, i + 1, j, k)) { sum += tmp[q]; cnt++; } } else cnt++;
                if (j > 0) { int q = idx - sx; if (faceVisc(comp, i, j - 1, k) != -1f || isWallFace(comp, i, j - 1, k)) { sum += tmp[q]; cnt++; } } else cnt++;
                if (j < sy - 1) { int q = idx + sx; if (faceVisc(comp, i, j + 1, k) != -1f || isWallFace(comp, i, j + 1, k)) { sum += tmp[q]; cnt++; } } else cnt++;
                if (k > 0) { int q = idx - sx * sy; if (faceVisc(comp, i, j, k - 1) != -1f || isWallFace(comp, i, j, k - 1)) { sum += tmp[q]; cnt++; } } else cnt++;
                if (k < sz - 1) { int q = idx + sx * sy; if (faceVisc(comp, i, j, k + 1) != -1f || isWallFace(comp, i, j, k + 1)) { sum += tmp[q]; cnt++; } } else cnt++;
                g[idx] = (rhs[idx] + a * sum) / (1f + a * cnt);
            }
        }
    }

    private boolean isWallFace(int comp, int i, int j, int k) {
        int ai = i, aj = j, ak = k;
        if (comp == 0) ai--; else if (comp == 1) aj--; else ak--;
        return typeAt(ai, aj, ak) == SOLID || typeAt(i, j, k) == SOLID;
    }

    private float[] uRhsBuf, vRhsBuf, wRhsBuf;
    private float[] uRhs() { if (uRhsBuf == null) uRhsBuf = new float[u.length]; return uRhsBuf; }
    private float[] vRhs() { if (vRhsBuf == null) vRhsBuf = new float[v.length]; return vRhsBuf; }
    private float[] wRhs() { if (wRhsBuf == null) wRhsBuf = new float[w.length]; return wRhsBuf; }

    // ------------------------------------------------------------------ pressure (MIC(0)-preconditioned CG)

    void project() {
        nFluid = 0;
        if (fluidCells.length < nCells) fluidCells = new int[nCells];
        for (int ci = 0; ci < nCells; ci++) {
            if (type[ci] == FLUID) { cellToFluid[ci] = nFluid; fluidCells[nFluid++] = ci; }
            else cellToFluid[ci] = -1;
        }
        if (nFluid == 0) return;
        if (diag.length < nFluid) {
            int cap = Math.max(nFluid, diag.length * 2);
            diag = new float[cap]; precon = new float[cap]; pr = new float[cap]; rr = new float[cap];
            zz = new float[cap]; ss = new float[cap]; qq = new float[cap];
            npx = new int[cap]; npy = new int[cap]; npz = new int[cap]; nmx = new int[cap]; nmy = new int[cap]; nmz = new int[cap];
        }
        float maxB = 0f;
        for (int f = 0; f < nFluid; f++) {
            int ci = fluidCells[f];
            int i = ci % nx, j = (ci / nx) % ny, k = ci / (nx * ny);
            float d = 0f;
            byte t;
            boolean fpx = uFrozen[ui(i + 1, j, k)] != 0, fmx = uFrozen[ui(i, j, k)] != 0;
            boolean fpz = wFrozen[wi(i, j, k + 1)] != 0, fmz = wFrozen[wi(i, j, k)] != 0;
            t = fpx ? SOLID : typeAt(i + 1, j, k); if (t != SOLID) d++; npx[f] = t == FLUID ? cellToFluid[c(i + 1, j, k)] : -1;
            t = fmx ? SOLID : typeAt(i - 1, j, k); if (t != SOLID) d++; nmx[f] = t == FLUID ? cellToFluid[c(i - 1, j, k)] : -1;
            t = typeAt(i, j + 1, k); if (t != SOLID) d++; npy[f] = t == FLUID ? cellToFluid[c(i, j + 1, k)] : -1;
            t = typeAt(i, j - 1, k); if (t != SOLID) d++; nmy[f] = t == FLUID ? cellToFluid[c(i, j - 1, k)] : -1;
            t = fpz ? SOLID : typeAt(i, j, k + 1); if (t != SOLID) d++; npz[f] = t == FLUID ? cellToFluid[c(i, j, k + 1)] : -1;
            t = fmz ? SOLID : typeAt(i, j, k - 1); if (t != SOLID) d++; nmz[f] = t == FLUID ? cellToFluid[c(i, j, k - 1)] : -1;
            diag[f] = d;
            float div = (u[ui(i + 1, j, k)] - u[ui(i, j, k)]) + (v[vi(i, j + 1, k)] - v[vi(i, j, k)]) + (w[wi(i, j, k + 1)] - w[wi(i, j, k)]);
            // slight volume correction: over-full cells push outward, keeping the pool from slowly compressing
            float over = cCount[ci] / ppc - 1.3f;
            if (over > 0f) div -= Math.min(over, 2f) * 0.6f;
            rr[f] = -div;
            pr[f] = 0f;
            if (Math.abs(rr[f]) > maxB) maxB = Math.abs(rr[f]);
        }
        buildPreconditioner();
        float tol = 1e-4f * Math.max(1f, maxB);
        if (maxB > tol) solvePcg(tol, 300);
        // subtract pressure gradient
        for (int k = bk0; k <= bk1; k++) for (int j = bj0; j <= bj1; j++) for (int i = bi0; i <= bi1 + 1; i++) {
            byte ta = typeAt(i - 1, j, k), tb = typeAt(i, j, k);
            if (ta == SOLID || tb == SOLID || (ta != FLUID && tb != FLUID)) continue;
            if (uFrozen[ui(i, j, k)] != 0) { uValid[ui(i, j, k)] = 1; continue; }
            u[ui(i, j, k)] -= pAt(i, j, k) - pAt(i - 1, j, k);
            uValid[ui(i, j, k)] = 1;
        }
        for (int k = bk0; k <= bk1; k++) for (int j = bj0; j <= bj1 + 1; j++) for (int i = bi0; i <= bi1; i++) {
            byte ta = typeAt(i, j - 1, k), tb = typeAt(i, j, k);
            if (ta == SOLID || tb == SOLID || (ta != FLUID && tb != FLUID)) continue;
            v[vi(i, j, k)] -= pAt(i, j, k) - pAt(i, j - 1, k);
            vValid[vi(i, j, k)] = 1;
        }
        for (int k = bk0; k <= bk1 + 1; k++) for (int j = bj0; j <= bj1; j++) for (int i = bi0; i <= bi1; i++) {
            byte ta = typeAt(i, j, k - 1), tb = typeAt(i, j, k);
            if (ta == SOLID || tb == SOLID || (ta != FLUID && tb != FLUID)) continue;
            if (wFrozen[wi(i, j, k)] != 0) { wValid[wi(i, j, k)] = 1; continue; }
            w[wi(i, j, k)] -= pAt(i, j, k) - pAt(i, j, k - 1);
            wValid[wi(i, j, k)] = 1;
        }
    }

    private float pAt(int i, int j, int k) {
        if (i < 0 || j < 0 || k < 0 || i >= nx || j >= ny || k >= nz) return 0f;
        int f = cellToFluid[c(i, j, k)];
        return f < 0 ? 0f : pr[f];
    }

    private void buildPreconditioner() {
        final float tau = 0.97f, sigma = 0.25f;
        for (int f = 0; f < nFluid; f++) {
            float e = diag[f];
            int m;
            // A_plus(m) = -1 when the neighbour in + direction is fluid. For m = minus neighbour of f, A_plus_dir(m) = -1.
            if ((m = nmx[f]) >= 0) {
                float a = -1f * precon[m];
                e -= a * a;
                e -= tau * (-1f) * ((npy[m] >= 0 ? -1f : 0f) + (npz[m] >= 0 ? -1f : 0f)) * precon[m] * precon[m];
            }
            if ((m = nmy[f]) >= 0) {
                float a = -1f * precon[m];
                e -= a * a;
                e -= tau * (-1f) * ((npx[m] >= 0 ? -1f : 0f) + (npz[m] >= 0 ? -1f : 0f)) * precon[m] * precon[m];
            }
            if ((m = nmz[f]) >= 0) {
                float a = -1f * precon[m];
                e -= a * a;
                e -= tau * (-1f) * ((npx[m] >= 0 ? -1f : 0f) + (npy[m] >= 0 ? -1f : 0f)) * precon[m] * precon[m];
            }
            if (e < sigma * diag[f]) e = diag[f];
            precon[f] = e > 1e-12f ? (float) (1.0 / Math.sqrt(e)) : 0f;
        }
    }

    private void applyPreconditioner(float[] r, float[] z) {
        // forward: solve L q = r (q stored in qq)
        for (int f = 0; f < nFluid; f++) {
            float t = r[f];
            int m;
            if ((m = nmx[f]) >= 0) t -= -1f * precon[m] * qq[m];
            if ((m = nmy[f]) >= 0) t -= -1f * precon[m] * qq[m];
            if ((m = nmz[f]) >= 0) t -= -1f * precon[m] * qq[m];
            qq[f] = t * precon[f];
        }
        // backward: solve L^T z = q
        for (int f = nFluid - 1; f >= 0; f--) {
            float t = qq[f];
            int p;
            if ((p = npx[f]) >= 0) t -= -1f * precon[f] * z[p];
            if ((p = npy[f]) >= 0) t -= -1f * precon[f] * z[p];
            if ((p = npz[f]) >= 0) t -= -1f * precon[f] * z[p];
            z[f] = t * precon[f];
        }
    }

    private void applyA(float[] x, float[] out) {
        for (int f = 0; f < nFluid; f++) {
            float s = diag[f] * x[f];
            int q;
            if ((q = npx[f]) >= 0) s -= x[q];
            if ((q = nmx[f]) >= 0) s -= x[q];
            if ((q = npy[f]) >= 0) s -= x[q];
            if ((q = nmy[f]) >= 0) s -= x[q];
            if ((q = npz[f]) >= 0) s -= x[q];
            if ((q = nmz[f]) >= 0) s -= x[q];
            out[f] = s;
        }
    }

    private void solvePcg(float tol, int maxIter) {
        applyPreconditioner(rr, zz);
        System.arraycopy(zz, 0, ss, 0, nFluid);
        double sigma = dot(zz, rr);
        int it = 0;
        float res = maxAbs(rr);
        while (it < maxIter && res > tol) {
            applyA(ss, zz);
            double denom = dot(zz, ss);
            if (Math.abs(denom) < 1e-20) break;
            float alpha = (float) (sigma / denom);
            for (int f = 0; f < nFluid; f++) { pr[f] += alpha * ss[f]; rr[f] -= alpha * zz[f]; }
            res = maxAbs(rr);
            it++;
            if (res <= tol) break;
            applyPreconditioner(rr, zz);
            double sigmaNew = dot(zz, rr);
            float beta = (float) (sigmaNew / sigma);
            for (int f = 0; f < nFluid; f++) ss[f] = zz[f] + beta * ss[f];
            sigma = sigmaNew;
        }
        lastPcgIterations = it;
        lastPcgResidual = res;
    }

    private double dot(float[] a, float[] b) { double s = 0; for (int f = 0; f < nFluid; f++) s += (double) a[f] * b[f]; return s; }
    private float maxAbs(float[] a) { float m = 0; for (int f = 0; f < nFluid; f++) { float x = Math.abs(a[f]); if (x > m) m = x; } return m; }

    /** Max |divergence| over fluid cells (test hook). */
    public float maxDivergence() {
        float m = 0;
        for (int k = 0; k < nz; k++) for (int j = 0; j < ny; j++) for (int i = 0; i < nx; i++) {
            if (type[c(i, j, k)] != FLUID) continue;
            float div = (u[ui(i + 1, j, k)] - u[ui(i, j, k)]) + (v[vi(i, j + 1, k)] - v[vi(i, j, k)]) + (w[wi(i, j, k + 1)] - w[wi(i, j, k)]);
            m = Math.max(m, Math.abs(div));
        }
        return m;
    }

    // ------------------------------------------------------------------ extrapolation into air

    private void extrapolate(float[] g, byte[] valid, int comp) {
        int sx = comp == 0 ? nx + 1 : nx, sy = comp == 1 ? ny + 1 : ny, sz = comp == 2 ? nz + 1 : nz;
        byte[] next = comp == 0 ? uTmpValid() : (comp == 1 ? vTmpValid() : wTmpValid());
        for (int layer = 0; layer < 2; layer++) {
            System.arraycopy(valid, 0, next, 0, valid.length);
            int i1 = Math.min(sx - 1, bi1 + 1), j1 = Math.min(sy - 1, bj1 + 1), k1 = Math.min(sz - 1, bk1 + 1);
            for (int k = bk0; k <= k1; k++) for (int j = bj0; j <= j1; j++) for (int i = bi0; i <= i1; i++) {
                int idx = i + sx * (j + sy * k);
                if (valid[idx] != 0) continue;
                float s = 0; int n = 0;
                if (i > 0 && valid[idx - 1] != 0) { s += g[idx - 1]; n++; }
                if (i < sx - 1 && valid[idx + 1] != 0) { s += g[idx + 1]; n++; }
                if (j > 0 && valid[idx - sx] != 0) { s += g[idx - sx]; n++; }
                if (j < sy - 1 && valid[idx + sx] != 0) { s += g[idx + sx]; n++; }
                if (k > 0 && valid[idx - sx * sy] != 0) { s += g[idx - sx * sy]; n++; }
                if (k < sz - 1 && valid[idx + sx * sy] != 0) { s += g[idx + sx * sy]; n++; }
                if (n > 0) { g[idx] = s / n; next[idx] = 1; }
            }
            System.arraycopy(next, 0, valid, 0, valid.length);
        }
    }

    private byte[] uTv, vTv, wTv;
    private byte[] uTmpValid() { if (uTv == null) uTv = new byte[u.length]; return uTv; }
    private byte[] vTmpValid() { if (vTv == null) vTv = new byte[v.length]; return vTv; }
    private byte[] wTmpValid() { if (wTv == null) wTv = new byte[w.length]; return wTv; }

    // ------------------------------------------------------------------ back to particles + move

    private void gridToParticles(float dt) {
        float decay = (float) Math.exp(-1.2 * dt);
        for (int n = 0; n < count; n++) {
            float x = px[n], y = py[n], z = pz[n];
            float picX = sampleU(u, x, y, z), picY = sampleV(v, x, y, z), picZ = sampleW(w, x, y, z);
            float dX = picX - sampleU(uOld, x, y, z), dY = picY - sampleV(vOld, x, y, z), dZ = picZ - sampleW(wOld, x, y, z);
            float flipX = vx[n] + dX, flipY = vy[n] + dY, flipZ = vz[n] + dZ;
            float a = pFlip[n];
            // whitewater: turbulence = how much the particle disagrees with its neighbourhood + raw speed
            float tx = flipX - picX, ty = flipY - picY, tz = flipZ - picZ;
            float turb = (float) Math.sqrt(tx * tx + ty * ty + tz * tz) * h;  // blocks/s
            float speed = (float) Math.sqrt(picX * picX + picY * picY + picZ * picZ) * h;
            float gen = pFoamGen[n] * (Math.max(0f, turb - 0.6f) * 0.7f + Math.max(0f, speed - 4.0f) * 0.08f);
            pFoam[n] = Math.min(1f, pFoam[n] * decay + gen * dt * 4f);
            vx[n] = picX + (flipX - picX) * a;
            vy[n] = picY + (flipY - picY) * a;
            vz[n] = picZ + (flipZ - picZ) * a;
            if (evaporateSeconds > 0f) {
                int ci = c(clampi((int) x, 0, nx - 1), clampi((int) y, 0, ny - 1), clampi((int) z, 0, nz - 1));
                boolean lonely = cCount[ci] <= 2f && speed < 0.25f;
                pIdle[n] = lonely ? pIdle[n] + dt : 0f;
            }
        }
        if (evaporateSeconds > 0f) {
            for (int n = count - 1; n >= 0; n--) if (pIdle[n] > evaporateSeconds) removeParticle(n);
        }
    }

    private static final float DRIFT_TAU = 0.2f; // seconds; larger = faster separation of different fluids

    private void advect(float dt) {
        float lo = 0.001f;
        final float gCells = GRAVITY / h;
        for (int n = count - 1; n >= 0; n--) {
            float x = px[n], y = py[n], z = pz[n];
            // RK2 (midpoint) through the divergence-free grid field
            float k1x = sampleU(u, x, y, z), k1y = sampleV(v, x, y, z), k1z = sampleW(w, x, y, z);
            float mx = x + 0.5f * dt * k1x, my = y + 0.5f * dt * k1y, mz = z + 0.5f * dt * k1z;
            float k2x = sampleU(u, mx, my, mz), k2y = sampleV(v, mx, my, mz), k2z = sampleW(w, mx, my, mz);
            float nxp = x + dt * k2x, nyp = y + dt * k2y, nzp = z + dt * k2z;
            // drift-flux slip: a particle denser than its cell's mix settles through it (oil rises, mercury sinks)
            int dc = c(clampi((int) x, 0, nx - 1), clampi((int) y, 0, ny - 1), clampi((int) z, 0, nz - 1));
            float rhoC = cDens[dc];
            if (rhoC > 1f) nyp -= clampf((pDens[n] - rhoC) / rhoC, -0.5f, 0.5f) * gCells * pGrav[n] * DRIFT_TAU * dt;
            // axis-by-axis collision: slide along walls instead of sticking
            if (nxp < lo || nxp > nx - lo || worldSolid((int) Math.floor(nxp), (int) y, (int) z)) { nxp = x; vx[n] = 0f; }
            if (nyp < lo || nyp > ny - lo || worldSolid((int) nxp, (int) Math.floor(nyp), (int) z)) { nyp = y; vy[n] = 0f; }
            if (nzp < lo || nzp > nz - lo || worldSolid((int) nxp, (int) nyp, (int) Math.floor(nzp))) { nzp = z; vz[n] = 0f; }
            if (!Float.isFinite(nxp + nyp + nzp)) { removeParticle(n); continue; }
            px[n] = clampf(nxp, lo, nx - lo); py[n] = clampf(nyp, lo, ny - lo); pz[n] = clampf(nzp, lo, nz - lo);
        }
    }

    // ------------------------------------------------------------------ queries

    /** Copies the fluid's bounding box into a snapshot for the game thread. Call from the simulation thread. */
    public void fillSnapshot(FluidSnapshot s) {
        s.ox = ox; s.oy = oy; s.oz = oz; s.h = h;
        s.version++;
        if (count == 0 || bi1 < bi0) { s.sx = s.sy = s.sz = 0; return; }
        s.i0 = bi0; s.j0 = bj0; s.k0 = bk0;
        s.sx = bi1 - bi0 + 1; s.sy = bj1 - bj0 + 1; s.sz = bk1 - bk0 + 1;
        s.ensure(s.sx * s.sy * s.sz);
        int idx = 0;
        for (int k = bk0; k <= bk1; k++) for (int j = bj0; j <= bj1; j++) for (int i = bi0; i <= bi1; i++, idx++) {
            int ci = c(i, j, k);
            float cnt = cCount[ci];
            s.occ[idx] = occupancy[ci];
            s.vel[idx * 3] = 0.5f * (u[ui(i, j, k)] + u[ui(i + 1, j, k)]) * h;
            s.vel[idx * 3 + 1] = 0.5f * (v[vi(i, j, k)] + v[vi(i, j + 1, k)]) * h;
            s.vel[idx * 3 + 2] = 0.5f * (w[wi(i, j, k)] + w[wi(i, j, k + 1)]) * h;
            if (cnt > 0) {
                s.dens[idx] = cDens[ci];
                s.visc[idx] = FluidProps.sliderFromKinematic(cVisc[ci]);
                s.rgb[idx] = ((int) (cR[ci] / cnt) << 16) | ((int) (cG[ci] / cnt) << 8) | (int) (cB[ci] / cnt);
                s.hot[idx] = (byte) (cHot[ci] * 2 > cnt ? 1 : 0);
            } else {
                s.dens[idx] = 0f; s.visc[idx] = 0f; s.rgb[idx] = 0; s.hot[idx] = 0;
            }
        }
    }

    /** Fraction (0..1) of a cell filled with fluid, from the last step. */
    public float occupancyAt(int i, int j, int k) {
        if (i < 0 || j < 0 || k < 0 || i >= nx || j >= ny || k >= nz) return 0f;
        return occupancy[c(i, j, k)];
    }

    /** Grid velocity (blocks/s) at a cell-unit position. */
    public void velocityAt(float x, float y, float z, float[] out) {
        out[0] = sampleU(u, x, y, z) * h;
        out[1] = sampleV(v, x, y, z) * h;
        out[2] = sampleW(w, x, y, z) * h;
    }

    public double totalVolumeBlocks() { return count / (double) ppc * h * h * h; }

    // accessors used by the mesher / saver
    public float[] px() { return px; }
    public float[] py() { return py; }
    public float[] pz() { return pz; }
    public float[] vx() { return vx; }
    public float[] vy() { return vy; }
    public float[] vz() { return vz; }
    public float[] foam() { return pFoam; }
    public int[] colors() { return pColor; }
    public byte[] flags() { return pFlags; }
    public byte[] worldMask() { return world; }
    public byte cellType(int i, int j, int k) { return typeAt(i, j, k); }

    /** Per-particle props snapshot for saving (visc, dens, grav, flip, foamGen, tension). */
    public void particleProps(int n, float[] out6) {
        out6[0] = pVisc[n]; out6[1] = pDens[n]; out6[2] = pGrav[n]; out6[3] = pFlip[n]; out6[4] = pFoamGen[n]; out6[5] = pTension[n];
    }

    /** Restore a saved particle exactly. */
    public boolean restoreParticle(float x, float y, float z, float vxi, float vyi, float vzi, int color, byte flags, float foam, float[] props6) {
        if (count >= maxParticles) return false;
        ensureCapacity(count + 1);
        int n = count++;
        px[n] = clampf(x, 0.001f, nx - 0.001f); py[n] = clampf(y, 0.001f, ny - 0.001f); pz[n] = clampf(z, 0.001f, nz - 0.001f);
        vx[n] = vxi; vy[n] = vyi; vz[n] = vzi;
        pColor[n] = color; pFlags[n] = flags; pFoam[n] = clampf(foam, 0f, 1f);
        pVisc[n] = Math.max(0f, props6[0]); pDens[n] = clampf(props6[1], 50f, 14000f); pGrav[n] = clampf(props6[2], 0f, 3f);
        pFlip[n] = clampf(props6[3], 0f, 0.99f); pFoamGen[n] = clampf(props6[4], 0f, 1f); pTension[n] = clampf(props6[5], 0f, 1f);
        pYield[n] = yieldFor(FluidProps.sliderFromKinematic(pVisc[n]));
        pIdle[n] = 0f;
        wake();
        return true;
    }

    static int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
    static float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

}

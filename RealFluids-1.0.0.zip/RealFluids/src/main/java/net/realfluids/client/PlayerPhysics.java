package net.realfluids.client;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;
import net.realfluids.config.RealFluidsConfig;
import net.realfluids.net.Packets;
import net.realfluids.sim.FluidSnapshot;

/**
 * How the local player feels the simulated fluid: buoyancy from the fluid's density, drag from its
 * viscosity, being carried by currents, swimming, splashes, and pushing the fluid back (waves when
 * you wade through it). Runs at the end of each client tick; movement is client-authoritative in
 * Minecraft, so this is all that's needed for it to work in multiplayer too.
 */
final class PlayerPhysics {
    private PlayerPhysics() { }

    /** Body density in kg/m^3: slightly heavier than water, so you sink slowly unless you swim. */
    private static final float BODY_DENSITY = 1010f;
    private static final float MC_GRAVITY = 0.08f; // blocks/tick^2

    private static float lastSubmerged;
    private static int statusCooldown;
    private static byte lastFlags;
    private static int splashCooldown;

    /** Result of sampling the fluid around the player. */
    private static final class Sample {
        float submerged, headOcc;
        float density, visc;
        float ux, uy, uz; // blocks/s
        boolean hot;
        int rgb;
    }

    private static final Sample S = new Sample();

    static void reset() {
        lastSubmerged = 0f;
        statusCooldown = 0;
        lastFlags = 0;
        splashCooldown = 0;
    }

    static void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        if (player == null || world == null || player.isSpectator()) return;
        if (!RealFluidsConfig.get().playerPhysics) return;

        FluidWorld.Region region = FluidWorld.get().find(world, player.getX(), player.getY(), player.getZ(), 0.0);
        boolean have = region != null && sample(region, player, S);
        float f = have ? S.submerged : 0f;
        if (splashCooldown > 0) splashCooldown--;

        if (f < 0.04f) {
            if (lastSubmerged > 0.04f) sendStatus((byte) 0, true);
            lastSubmerged = f;
            return;
        }

        Vec3d v = player.getVelocity();
        double vx = v.x, vy = v.y, vz = v.z;
        boolean flying = player.getAbilities().flying;

        // ---- entering: splash sound, droplets and a real impulse into the simulation
        if (lastSubmerged < 0.1f && f >= 0.2f && vy < -0.25 && splashCooldown == 0) {
            float speed = (float) Math.min(1.5, -vy);
            if (S.hot) {
                world.playSound(player.getX(), player.getY(), player.getZ(), SoundEvents.BLOCK_LAVA_POP, SoundCategory.PLAYERS, 0.8f, 0.9f, false);
            } else {
                world.playSound(player.getX(), player.getY(), player.getZ(), speed > 0.7f ? SoundEvents.ENTITY_PLAYER_SPLASH_HIGH_SPEED : SoundEvents.ENTITY_PLAYER_SPLASH,
                    SoundCategory.PLAYERS, Math.min(1f, 0.3f + speed), 0.9f + world.random.nextFloat() * 0.25f, false);
            }
            int drops = 8 + (int) (speed * 30);
            for (int i = 0; i < drops; i++) {
                double ox = (world.random.nextDouble() - 0.5) * player.getWidth() * 1.6, oz = (world.random.nextDouble() - 0.5) * player.getWidth() * 1.6;
                world.addParticle(S.hot ? ParticleTypes.LAVA : ParticleTypes.SPLASH, player.getX() + ox, player.getY() + 0.3, player.getZ() + oz,
                    ox * 0.4, 0.2 + speed * 0.3, oz * 0.4);
            }
            FluidWorld.get().impulse(region, player.getX(), player.getY() + 0.4, player.getZ(), 1.0 + speed,
                new Vec3d(vx * 20, vy * 20, vz * 20), Math.min(1f, 0.5f + speed));
            splashCooldown = 10;
        }

        if (!flying) {
            float visc = S.visc;
            // ---- buoyancy (Archimedes): weight of displaced fluid, limited so mercury can't launch you
            float buoy = MC_GRAVITY * f * S.density / BODY_DENSITY;
            vy += Math.min(buoy, MC_GRAVITY * 2.5f);

            // ---- drag towards the fluid's own velocity (so currents carry you)
            float k = f * (0.14f + 0.72f * (float) Math.pow(visc, 1.5));
            k = Math.min(k, 0.85f);
            double fx = S.ux / 20.0, fy = S.uy / 20.0, fz = S.uz / 20.0;
            vx -= (vx - fx) * k;
            vy -= (vy - fy) * k;
            vz -= (vz - fz) * k;

            // ---- swimming: jump rises, sneak dives, movement keys paddle (much harder in thick fluid)
            float effort = (1f - 0.85f * visc) * Math.min(1f, f * 1.6f);
            if (client.options.jumpKey.isPressed()) vy += 0.045f * effort + (S.headOcc > 0.5f ? 0.0f : 0.02f * effort);
            if (client.options.sneakKey.isPressed()) vy -= 0.03f * effort;
            float fwd = player.input.movementForward, side = player.input.movementSideways;
            if (fwd != 0f || side != 0f) {
                double yaw = Math.toRadians(player.getYaw());
                double sin = Math.sin(yaw), cos = Math.cos(yaw);
                double ax = side * cos - fwd * sin, az = fwd * cos + side * sin;
                double len = Math.max(1.0, Math.sqrt(ax * ax + az * az));
                float paddle = 0.014f * effort * (player.isSprinting() ? 1.5f : 1f);
                vx += ax / len * paddle;
                vz += az / len * paddle;
                // looking up/down while swimming steers vertically, like vanilla swimming
                if (S.headOcc > 0.5f && fwd > 0f) vy += -Math.sin(Math.toRadians(player.getPitch())) * paddle * 0.9;
            }
            player.setVelocity(vx, vy, vz);
            player.fallDistance = 0f;
        }

        // ---- the body pushes the fluid: wakes, bow waves, ripples while wading
        double speed2 = vx * vx + vy * vy + vz * vz;
        if (speed2 > 0.0025) {
            FluidWorld.get().impulse(region, player.getX(), player.getY() + player.getHeight() * Math.min(0.5f, f) , player.getZ(),
                0.55 + player.getWidth() * 0.5, new Vec3d(vx * 20, vy * 20, vz * 20), 0.25f * Math.min(1f, f * 2f));
        }

        // ---- ambience
        if (S.hot) {
            if (world.random.nextInt(6) == 0) world.addParticle(ParticleTypes.LARGE_SMOKE, player.getX(), player.getY() + 1.0, player.getZ(), 0, 0.05, 0);
        }
        // (vanilla bubble particles delete themselves outside vanilla water, so none are spawned here)

        byte flags = (byte) (1 | (S.hot ? 2 : 0));
        sendStatus(flags, false);
        lastSubmerged = f;
    }

    /** Fills {@code out} from the region's snapshot; false if the player isn't near any fluid. */
    private static boolean sample(FluidWorld.Region region, ClientPlayerEntity player, Sample out) {
        FluidSnapshot s = region.snapshot();
        if (s == null) return false;
        synchronized (s) {
            if (s.sx == 0) return false;
            double x = player.getX(), z = player.getZ(), y0 = player.getY();
            float height = player.getHeight(), half = player.getWidth() * 0.35f;
            final int levels = 6;
            float occSum = 0f, wSum = 0f, dens = 0f, visc = 0f, ux = 0f, uy = 0f, uz = 0f;
            int hot = 0, any = 0, rgb = 0;
            float bestOcc = 0f;
            for (int l = 0; l < levels; l++) {
                double y = y0 + height * (l + 0.5) / levels;
                for (int c = 0; c < 5; c++) {
                    double sx = x + (c == 1 ? half : c == 2 ? -half : 0), sz = z + (c == 3 ? half : c == 4 ? -half : 0);
                    int idx = s.indexAt(sx, y, sz);
                    float o = idx < 0 ? 0f : Math.min(1f, s.occ[idx]);
                    occSum += o;
                    if (o > 0.05f) {
                        dens += s.dens[idx] * o; visc += s.visc[idx] * o;
                        ux += s.vel[idx * 3] * o; uy += s.vel[idx * 3 + 1] * o; uz += s.vel[idx * 3 + 2] * o;
                        wSum += o;
                        hot += s.hot[idx];
                        any++;
                        if (o > bestOcc) { bestOcc = o; rgb = s.rgb[idx]; }
                    }
                }
            }
            out.submerged = occSum / (levels * 5);
            int head = s.indexAt(x, player.getEyeY(), z);
            out.headOcc = head < 0 ? 0f : s.occ[head];
            if (wSum <= 0f) { out.submerged = 0f; return false; }
            out.density = dens / wSum;
            out.visc = visc / wSum;
            out.ux = ux / wSum; out.uy = uy / wSum; out.uz = uz / wSum;
            out.hot = hot * 2 > any;
            out.rgb = rgb;
            return true;
        }
    }

    /** Tell the server when we're in fluid (no fall damage, extinguish / ignite). Rate limited. */
    private static void sendStatus(byte flags, boolean force) {
        if (statusCooldown > 0) statusCooldown--;
        if (!force && flags == lastFlags && statusCooldown > 0) return;
        lastFlags = flags;
        statusCooldown = 10;
        if (!ClientPlayNetworking.canSend(Packets.STATUS)) return;
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeByte(flags);
        ClientPlayNetworking.send(Packets.STATUS, buf);
    }
}

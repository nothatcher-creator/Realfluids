package net.realfluids.client;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.realfluids.config.RealFluidsConfig;
import net.realfluids.item.FluidBucketData;
import net.realfluids.net.Packets;
import net.realfluids.sim.FluidProps;
import net.realfluids.sim.FluidSnapshot;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

/**
 * Client entry point: the Z editor, pouring and scooping with buckets, the background simulation,
 * rendering, player physics, the underwater tint, tooltips and the /realfluids command.
 */
public final class RealFluidsClient implements ClientModInitializer {
    private static KeyBinding editKey;
    /** Game tick of the last pour or scoop: one bucket action per click, and never scoop what you just poured. */
    private static long lastActionTick = -100;
    private static final int ACTION_COOLDOWN_TICKS = 8;
    private static final double REACH = 5.0;

    @Override
    public void onInitializeClient() {
        RealFluidsConfig.get(); // load (or create) config/realfluids.json early so errors show at startup

        editKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.realfluids.edit", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Z, "key.categories.realfluids"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (editKey.wasPressed()) openEditor(client);
            FluidWorld.get().tick(client);
            PlayerPhysics.tick(client);
        });

        WorldRenderEvents.AFTER_TRANSLUCENT.register(FluidRenderer::render);
        HudRenderCallback.EVENT.register((ctx, tickDelta) -> drawSubmergedTint(ctx));

        // Registered after the common callback (which passes on the client), so this decides client-side use.
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (!world.isClient()) return TypedActionResult.pass(stack);
            MinecraftClient mc = MinecraftClient.getInstance();
            if (player != mc.player || !(world instanceof ClientWorld cw)) return TypedActionResult.pass(stack);
            if (FluidBucketData.isRealFluidFull(stack)) {
                if (onCooldown(cw)) return TypedActionResult.consume(stack);
                pour(mc, cw, mc.player, hand, stack);
                return TypedActionResult.consume(stack); // no vanilla placement, no use-item packet: POUR does it
            }
            if (stack.isOf(Items.BUCKET)) {
                if (onCooldown(cw)) return FluidWorld.get().regions().isEmpty() ? TypedActionResult.pass(stack) : TypedActionResult.consume(stack);
                if (tryScoop(mc, cw, mc.player, hand, stack)) return TypedActionResult.consume(stack);
            }
            return TypedActionResult.pass(stack); // vanilla bucket behaviour (vanilla water, lava, milk...)
        });

        ClientPlayNetworking.registerGlobalReceiver(Packets.SPAWN, (client, handler, buf, sender) -> {
            double x = buf.readDouble(), y = buf.readDouble(), z = buf.readDouble();
            float dx = buf.readFloat(), dy = buf.readFloat(), dz = buf.readFloat();
            NbtCompound tag = buf.readNbt();
            if (tag == null) return;
            FluidProps props = FluidBucketData.fromNbt(tag);
            client.execute(() -> {
                if (client.world != null) FluidWorld.get().spawn(client.world, x, y, z, dx, dy, dz, props);
            });
        });
        ClientPlayNetworking.registerGlobalReceiver(Packets.REMOVE, (client, handler, buf, sender) -> {
            double x = buf.readDouble(), y = buf.readDouble(), z = buf.readDouble();
            float radius = Math.min(4f, buf.readFloat());
            int particles = buf.readInt();
            client.execute(() -> {
                if (client.world == null) return;
                FluidWorld.Region r = FluidWorld.get().find(client.world, x, y, z, 0.0);
                if (r == null) return;
                float volume = particles / (float) r.sim.ppc * r.sim.h * r.sim.h * r.sim.h;
                FluidWorld.get().remove(client.world, x, y, z, radius, volume, null);
            });
        });

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> client.execute(() -> {
            PlayerPhysics.reset();
            FluidWorld.get().onJoin(client);
        }));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            Runnable r = () -> {
                FluidWorld.get().onDisconnect();
                FluidRenderer.releaseAll();
                PlayerPhysics.reset();
            };
            if (client.isOnThread()) r.run(); else client.execute(r);
        });

        ItemTooltipCallback.EVENT.register((stack, context, lines) -> {
            if (!FluidBucketData.isConfigurableBucket(stack)) return;
            if (stack.getSubNbt(FluidBucketData.KEY) != null) {
                FluidProps p = FluidBucketData.read(stack);
                lines.add(Text.literal("Real fluid: " + p.name).formatted(Formatting.AQUA));
                if (!stack.isOf(Items.BUCKET)) {
                    lines.add(Text.literal(String.format(Locale.ROOT, "%.2g blocks, %s", p.volume, p.mode.name().toLowerCase(Locale.ROOT))).formatted(Formatting.GRAY));
                }
                lines.add(Text.literal("Press " + editKey.getBoundKeyLocalizedText().getString() + " to edit").formatted(Formatting.DARK_GRAY));
            } else {
                lines.add(Text.literal("Press " + editKey.getBoundKeyLocalizedText().getString() + " to make it real fluid").formatted(Formatting.DARK_GRAY));
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> dispatcher.register(literal("realfluids")
            .then(literal("clear").executes(c -> { FluidWorld.get().clearAll(); feedback(c.getSource(), "Cleared all simulated fluid near you"); return 1; }))
            .then(literal("pause").executes(c -> { FluidWorld.get().setPaused(true); feedback(c.getSource(), "Fluid simulation paused"); return 1; }))
            .then(literal("resume").executes(c -> { FluidWorld.get().setPaused(false); feedback(c.getSource(), "Fluid simulation resumed"); return 1; }))
            .then(literal("stats").executes(c -> { stats(c.getSource()); return 1; }))
            .then(literal("quality")
                .executes(c -> { feedback(c.getSource(), "Quality: " + RealFluidsConfig.get().quality + " (low / medium / high)"); return 1; })
                .then(ClientCommandManager.argument("level", StringArgumentType.word())
                    .suggests((c, b) -> { for (String s : new String[] { "low", "medium", "high" }) b.suggest(s); return b.buildFuture(); })
                    .executes(c -> {
                        String level = StringArgumentType.getString(c, "level").toLowerCase(Locale.ROOT);
                        if (!level.equals("low") && !level.equals("medium") && !level.equals("high")) {
                            feedback(c.getSource(), "Use low, medium or high");
                            return 0;
                        }
                        RealFluidsConfig cfg = RealFluidsConfig.get();
                        cfg.quality = level;
                        cfg.applyQualityPreset();
                        cfg.save();
                        feedback(c.getSource(), "Quality set to " + level + ". New pours use it; /realfluids clear to rebuild existing fluid.");
                        return 1;
                    })))));
    }

    // ------------------------------------------------------------------ editor

    private static void openEditor(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.currentScreen != null) return;
        ItemStack held = player.getMainHandStack();
        if (!FluidBucketData.isConfigurableBucket(held)) {
            Hud.message("Hold a bucket (empty, water or lava) to edit its fluid");
            return;
        }
        client.setScreen(new FluidEditorScreen(held));
    }

    // ------------------------------------------------------------------ pour / scoop

    private static boolean onCooldown(ClientWorld world) {
        long now = world.getTime();
        return now >= lastActionTick && now - lastActionTick < ACTION_COOLDOWN_TICKS;
    }

    private static void pour(MinecraftClient mc, ClientWorld world, ClientPlayerEntity player, Hand hand, ItemStack stack) {
        lastActionTick = world.getTime();
        Vec3d look = player.getRotationVec(1f);
        Vec3d at;
        HitResult hit = player.raycast(REACH, 1f, false);
        if (hit instanceof BlockHitResult bhr && hit.getType() == HitResult.Type.BLOCK) {
            // a little off the face that was clicked, so the fluid starts in the air in front of it
            Vec3d n = Vec3d.of(bhr.getSide().getVector());
            at = bhr.getPos().add(n.multiply(0.45));
        } else {
            at = player.getEyePos().add(look.multiply(2.5));
        }
        // if the fluid would start inside the player, push it forward
        if (player.getBoundingBox().expand(0.2).contains(at)) at = player.getEyePos().add(look.multiply(1.6));
        player.swingHand(hand);
        if (ClientPlayNetworking.canSend(Packets.POUR)) {
            PacketByteBuf buf = PacketByteBufs.create();
            buf.writeDouble(at.x); buf.writeDouble(at.y); buf.writeDouble(at.z);
            buf.writeFloat((float) look.x); buf.writeFloat((float) look.y); buf.writeFloat((float) look.z);
            ClientPlayNetworking.send(Packets.POUR, buf); // the server answers with SPAWN to everyone, us included
        } else {
            // server without the mod: simulate locally so the bucket still does something
            FluidWorld.get().spawn(world, at.x, at.y, at.z, (float) look.x, (float) look.y, (float) look.z, FluidBucketData.read(stack));
        }
    }

    /** Finds simulated fluid along the view ray and scoops it. False when there is none (vanilla handles it). */
    private static boolean tryScoop(MinecraftClient mc, ClientWorld world, ClientPlayerEntity player, Hand hand, ItemStack stack) {
        if (FluidWorld.get().regions().isEmpty()) return false;
        Vec3d eye = player.getEyePos(), look = player.getRotationVec(1f);
        HitResult blockHit = player.raycast(REACH, 1f, true); // stop at blocks (and vanilla fluids)
        double maxDist = blockHit.getType() == HitResult.Type.MISS ? REACH : Math.min(REACH, blockHit.getPos().distanceTo(eye) + 0.25);
        Vec3d found = null;
        for (double t = 0.4; t <= maxDist; t += 0.12) {
            Vec3d p = eye.add(look.multiply(t));
            if (FluidWorld.get().occupancyAt(world, p.x, p.y, p.z) > 0.45f) { found = p; break; }
        }
        if (found == null) return false;
        lastActionTick = world.getTime();
        player.swingHand(hand);
        FluidProps recipe = FluidBucketData.isRealFluidEmpty(stack) ? FluidBucketData.read(stack) : null;
        float want = recipe != null ? recipe.volume : new FluidProps().volume;
        final Vec3d at = found;
        float radius = (float) Math.max(1.0, Math.cbrt(want) * 0.9);
        FluidWorld.get().remove(world, at.x, at.y, at.z, radius, want, res -> {
            if (res.props() == null || res.volume() < 0.05f) return;
            if (ClientPlayNetworking.canSend(Packets.SCOOP)) {
                PacketByteBuf buf = PacketByteBufs.create();
                buf.writeDouble(at.x); buf.writeDouble(at.y); buf.writeDouble(at.z);
                buf.writeFloat(res.volume());
                buf.writeNbt(FluidBucketData.toNbt(res.props()));
                ClientPlayNetworking.send(Packets.SCOOP, buf);
            } else {
                Hud.message("Scooped " + res.props().name + " (install Real Fluids on the server to keep it in the bucket)");
            }
        });
        return true;
    }

    // ------------------------------------------------------------------ HUD

    /** Tints the screen when the camera is inside simulated fluid. */
    private static void drawSubmergedTint(net.minecraft.client.gui.DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.gameRenderer == null) return;
        Vec3d cam = mc.gameRenderer.getCamera().getPos();
        FluidWorld.Region r = FluidWorld.get().find(mc.world, cam.x, cam.y, cam.z, 0.0);
        if (r == null) return;
        FluidSnapshot s = r.snapshot();
        if (s == null) return;
        int rgb;
        float occ;
        synchronized (s) {
            int idx = s.indexAt(cam.x, cam.y, cam.z);
            if (idx < 0) return;
            occ = s.occ[idx];
            rgb = s.rgb[idx] & 0xFFFFFF;
        }
        if (occ < 0.5f) return;
        int alpha = (int) (Math.min(1f, (occ - 0.5f) * 2f) * 150);
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        ctx.fill(0, 0, w, h, (alpha << 24) | rgb);
    }

    private static void feedback(FabricClientCommandSource src, String msg) {
        src.sendFeedback(Text.literal(msg));
    }

    private static void stats(FabricClientCommandSource src) {
        FluidWorld fw = FluidWorld.get();
        if (fw.regions().isEmpty()) { feedback(src, "No simulated fluid. Hold a bucket and press Z."); return; }
        int i = 0;
        for (FluidWorld.Region r : fw.regions()) {
            var m = r.mesh();
            feedback(src, String.format(Locale.ROOT, "#%d %s at %d %d %d: %,d particles, %s, %.1f ms/step, %,d quads",
                ++i, r.dimension, r.sim.ox, r.sim.oy, r.sim.oz, r.particles(), r.sleeping() ? "settled" : "moving", r.stepMillis(),
                m == null ? 0 : m.quads));
        }
        RealFluidsConfig cfg = RealFluidsConfig.get();
        feedback(src, "Quality " + cfg.quality + ", cell " + cfg.cellSize + " blocks" + (fw.isPaused() ? " (paused)" : ""));
    }
}

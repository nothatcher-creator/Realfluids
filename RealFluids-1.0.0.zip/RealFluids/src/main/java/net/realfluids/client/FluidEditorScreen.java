package net.realfluids.client;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;
import net.realfluids.item.FluidBucketData;
import net.realfluids.net.Packets;
import net.realfluids.sim.FluidProps;

import java.util.Locale;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;
import java.util.function.DoubleSupplier;

/**
 * The Z-key bucket editor. Four tabs (Presets / Look / Physics / Pour) keep every page short enough
 * for a phone held sideways; on wide screens the rows flow into two columns.
 */
public final class FluidEditorScreen extends Screen {
    private enum Tab {
        PRESETS("Presets"), LOOK("Look"), PHYSICS("Physics"), POUR("Pour");
        final String label;
        Tab(String label) { this.label = label; }
    }

    private static Tab lastTab = Tab.PRESETS;

    private final FluidProps props;
    private final boolean wasReal;
    private Tab tab = lastTab;
    private TextFieldWidget nameField;

    // layout (recomputed in init)
    private int left, colW, cols, rowH, widgetH, rowsTop, cursor;

    public FluidEditorScreen(ItemStack bucket) {
        super(Text.literal("Real Fluid Bucket"));
        this.props = FluidBucketData.read(bucket).copy().sanitize();
        this.wasReal = bucket.getSubNbt(FluidBucketData.KEY) != null;
    }

    // ------------------------------------------------------------------ layout

    @Override
    protected void init() {
        cols = width >= 470 ? 2 : 1;
        colW = cols == 2 ? Math.min(230, (width - 30) / 2) : Math.min(310, width - 16);
        int totalW = cols * colW + (cols - 1) * 10;
        left = (width - totalW) / 2;

        int top = 20;
        int tabW = (totalW - 3 * 3) / 4;
        for (Tab t : Tab.values()) {
            String label = (t == tab ? "▶ " : "") + t.label;
            ButtonWidget b = ButtonWidget.builder(Text.literal(label), btn -> { tab = t; lastTab = t; clearAndInit(); })
                .dimensions(left + t.ordinal() * (tabW + 3), top, tabW, 18).build();
            b.active = t != tab;
            addDrawableChild(b);
        }

        int bottomY = height - 24;
        rowsTop = top + 24;
        int rows = switch (tab) { case PRESETS -> 3; case LOOK -> 7; case PHYSICS -> 6; case POUR -> 5; };
        int perCol = (rows + cols - 1) / cols;
        int avail = bottomY - 6 - rowsTop - (tab == Tab.PRESETS ? 40 : 12);
        rowH = Math.max(18, Math.min(24, avail / Math.max(1, tab == Tab.PRESETS ? rows : perCol)));
        widgetH = Math.min(20, rowH - 2);
        cursor = 0;

        switch (tab) {
            case PRESETS -> buildPresets(totalW);
            case LOOK -> buildLook(perCol);
            case PHYSICS -> buildPhysics(perCol);
            case POUR -> buildPour(perCol);
        }

        int bw = (totalW - 6) / 3;
        addDrawableChild(ButtonWidget.builder(Text.literal("Save"), b -> save(true)).dimensions(left, bottomY, bw, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), b -> close()).dimensions(left + bw + 3, bottomY, bw, 20).build());
        ButtonWidget off = ButtonWidget.builder(Text.literal("Vanilla bucket"), b -> save(false)).dimensions(left + 2 * (bw + 3), bottomY, bw, 20).build();
        off.active = wasReal;
        addDrawableChild(off);
    }

    /** Next row slot for single-widget rows, flowing down then across columns. */
    private int[] slot(int perCol) {
        int col = cursor / perCol, row = cursor % perCol;
        cursor++;
        return new int[] { left + col * (colW + 10), rowsTop + row * rowH };
    }

    private void buildPresets(int totalW) {
        int per = 3, bw = (totalW - (per - 1) * 4) / per;
        for (int i = 0; i < FluidProps.PRESETS.length; i++) {
            String id = FluidProps.PRESETS[i];
            int x = left + (i % per) * (bw + 4), y = rowsTop + (i / per) * rowH;
            addDrawableChild(ButtonWidget.builder(Text.literal(id), b -> { applyPreset(id); clearAndInit(); })
                .dimensions(x, y, bw, widgetH).build());
        }
    }

    private void buildLook(int perCol) {
        int[] p = slot(perCol);
        nameField = new TextFieldWidget(textRenderer, p[0] + 1, p[1] + 1, colW - 2, widgetH - 2, Text.literal("Name"));
        nameField.setMaxLength(32);
        nameField.setText(props.name);
        nameField.setChangedListener(s -> props.name = s);
        addDrawableChild(nameField);
        addSlider(perCol, "Red", 0, 255, false, () -> (props.color >> 16) & 0xFF, v -> props.color = (props.color & 0x00FFFF) | ((int) Math.round(v) << 16), v -> String.valueOf((int) Math.round(v)));
        addSlider(perCol, "Green", 0, 255, false, () -> (props.color >> 8) & 0xFF, v -> props.color = (props.color & 0xFF00FF) | ((int) Math.round(v) << 8), v -> String.valueOf((int) Math.round(v)));
        addSlider(perCol, "Blue", 0, 255, false, () -> props.color & 0xFF, v -> props.color = (props.color & 0xFFFF00) | (int) Math.round(v), v -> String.valueOf((int) Math.round(v)));
        addSlider(perCol, "Cloudiness", 0, 1, false, () -> props.clarity, v -> props.clarity = (float) v, v -> describe(v, "glass clear", "clear", "murky", "opaque"));
        addSlider(perCol, "Foam", 0, 1, false, () -> props.foam, v -> props.foam = (float) v, FluidEditorScreen::percent);
        addToggle(perCol, "Glows", () -> props.glow, b -> props.glow = b);
    }

    private void buildPhysics(int perCol) {
        addSlider(perCol, "Thickness", 0, 1, false, () -> props.viscosity, v -> props.viscosity = (float) v,
            v -> describe(v, "water", "milk", "oil", "syrup", "honey", "tar"));
        addSlider(perCol, "Density", 50, 14000, true, () -> props.density, v -> props.density = (float) v,
            v -> String.format(Locale.ROOT, "%,.0f kg/m³", v));
        addSlider(perCol, "Gravity", 0, 3, false, () -> props.gravity, v -> props.gravity = (float) v, v -> String.format(Locale.ROOT, "%.2fx", v));
        addSlider(perCol, "Splashiness", 0, 0.99, false, () -> props.splash, v -> props.splash = (float) v, v -> describe(v / 0.99, "calm", "gentle", "lively", "wild"));
        addSlider(perCol, "Stickiness", 0, 1, false, () -> props.surfaceTension, v -> props.surfaceTension = (float) v, FluidEditorScreen::percent);
        addToggle(perCol, "Hot (burns)", () -> props.hot, b -> props.hot = b);
    }

    private void buildPour(int perCol) {
        addSlider(perCol, "Amount", 0.25, 128, true, () -> props.volume, v -> props.volume = (float) v,
            v -> v < 10 ? String.format(Locale.ROOT, "%.2f blocks", v) : String.format(Locale.ROOT, "%.0f blocks", v));
        int[] p = slot(perCol);
        addDrawableChild(ButtonWidget.builder(Text.literal("Shape: " + nice(props.shape.name())), b -> {
            FluidProps.Shape[] all = FluidProps.Shape.values();
            props.shape = all[(props.shape.ordinal() + 1) % all.length];
            b.setMessage(Text.literal("Shape: " + nice(props.shape.name())));
        }).dimensions(p[0], p[1], colW, widgetH).build());
        p = slot(perCol);
        addDrawableChild(ButtonWidget.builder(Text.literal("Pour: " + modeLabel()), b -> {
            FluidProps.Mode[] all = FluidProps.Mode.values();
            props.mode = all[(props.mode.ordinal() + 1) % all.length];
            clearAndInit(); // speed/duration only apply to streams and fountains
        }).dimensions(p[0], p[1], colW, widgetH).build());
        SliderWidget speed = addSlider(perCol, "Jet speed", 0, 30, false, () -> props.speed, v -> props.speed = (float) v,
            v -> String.format(Locale.ROOT, "%.1f blocks/s", v));
        SliderWidget dur = addSlider(perCol, "Duration", 0.5, 60, true, () -> props.duration, v -> props.duration = (float) v,
            v -> String.format(Locale.ROOT, "%.1f s", v));
        boolean jet = props.mode != FluidProps.Mode.INSTANT;
        speed.active = jet;
        dur.active = jet;
    }

    private String modeLabel() {
        return switch (props.mode) {
            case INSTANT -> "all at once";
            case STREAM -> "stream from bucket";
            case FOUNTAIN -> "fountain upward";
        };
    }

    private SliderWidget addSlider(int perCol, String label, double min, double max, boolean log,
                                   DoubleSupplier get, DoubleConsumer set, DoubleFunction<String> fmt) {
        int[] p = slot(perCol);
        Slider s = new Slider(p[0], p[1], colW, widgetH, label, min, max, log, get.getAsDouble(), set, fmt);
        addDrawableChild(s);
        return s;
    }

    private void addToggle(int perCol, String label, java.util.function.BooleanSupplier get, java.util.function.Consumer<Boolean> set) {
        int[] p = slot(perCol);
        addDrawableChild(ButtonWidget.builder(Text.literal(label + ": " + (get.getAsBoolean() ? "ON" : "OFF")), b -> {
            boolean now = !get.getAsBoolean();
            set.accept(now);
            b.setMessage(Text.literal(label + ": " + (now ? "ON" : "OFF")));
        }).dimensions(p[0], p[1], colW, widgetH).build());
    }

    // ------------------------------------------------------------------ actions

    private void applyPreset(String id) {
        FluidProps p = FluidProps.preset(id);
        // keep how the bucket pours, take everything about the fluid itself
        p.volume = props.volume; p.shape = props.shape; p.mode = props.mode; p.speed = props.speed; p.duration = props.duration;
        props.name = p.name; props.color = p.color; props.clarity = p.clarity; props.foam = p.foam; props.glow = p.glow;
        props.viscosity = p.viscosity; props.density = p.density; props.gravity = p.gravity; props.splash = p.splash;
        props.surfaceTension = p.surfaceTension; props.hot = p.hot;
    }

    private void save(boolean enabled) {
        if (client == null || client.player == null) return;
        ItemStack held = client.player.getMainHandStack();
        if (!FluidBucketData.isConfigurableBucket(held)) {
            Hud.message("Hold the bucket in your main hand");
            close();
            return;
        }
        props.sanitize();
        if (!ClientPlayNetworking.canSend(Packets.CONFIGURE)) {
            Hud.message("Real Fluids isn't installed on this server (it is automatic in singleplayer)");
            close();
            return;
        }
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeNbt(FluidBucketData.toNbt(props));
        buf.writeBoolean(enabled);
        ClientPlayNetworking.send(Packets.CONFIGURE, buf);
        // show it straight away; the server sends the authoritative stack right after
        if (enabled) FluidBucketData.write(held, props); else FluidBucketData.clear(held);
        Hud.message(enabled ? "Bucket now holds real " + props.name : "Back to a vanilla bucket");
        close();
    }

    // ------------------------------------------------------------------ drawing

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx);
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(props.name + " — " + title.getString()), width / 2, 6, 0xFFFFFF);

        // colour swatch with a clarity checkerboard behind it
        int sw = 26, sx = left + cols * colW + (cols - 1) * 10 - sw, sy = 4;
        for (int i = 0; i < 4; i++) ctx.fill(sx + i * (sw / 4), sy, sx + (i + 1) * (sw / 4), sy + 12, (i & 1) == 0 ? 0xFFDDDDDD : 0xFF555555);
        int a = (int) (90 + 165 * props.clarity);
        ctx.fill(sx, sy, sx + sw, sy + 12, (a << 24) | (props.color & 0xFFFFFF));

        int infoY = height - 24 - 12;
        switch (tab) {
            case PRESETS -> {
                int y = rowsTop + 3 * rowH + 4;
                ctx.drawTextWithShadow(textRenderer, String.format(Locale.ROOT, "%s: %s, %,.0f kg/m³%s%s", props.name,
                    describe(props.viscosity, "water-thin", "milky", "oily", "syrupy", "honey-thick", "tar-thick"), props.density,
                    props.hot ? ", hot" : "", props.glow ? ", glowing" : ""), left, y, 0xE0E0E0);
                ctx.drawTextWithShadow(textRenderer, "Pick a preset, then fine-tune it in the other tabs.", left, y + 12, 0xA0A0A0);
            }
            case PHYSICS -> ctx.drawTextWithShadow(textRenderer, "Lighter fluids float on heavier ones. Above 1,010 kg/m³ you float.", left, infoY, 0xA0A0A0);
            case POUR -> ctx.drawTextWithShadow(textRenderer, "Right-click to pour. Right-click fluid with an empty bucket to scoop.", left, infoY, 0xA0A0A0);
            case LOOK -> ctx.drawTextWithShadow(textRenderer, "Cloudiness 0 = see-through, 1 = solid colour.", left, infoY, 0xA0A0A0);
        }
    }

    @Override
    public boolean shouldPause() { return false; }

    // ------------------------------------------------------------------ helpers

    private static String percent(double v) { return Math.round(v * 100) + "%"; }

    private static String describe(double v, String... words) {
        int i = (int) Math.min(words.length - 1, Math.floor(Math.max(0, v) * words.length));
        return words[i];
    }

    private static String nice(String enumName) {
        return enumName.charAt(0) + enumName.substring(1).toLowerCase(Locale.ROOT);
    }

    /** Labelled slider over [min, max], optionally logarithmic. */
    private static final class Slider extends SliderWidget {
        private final String label;
        private final double min, max;
        private final boolean log;
        private final DoubleConsumer set;
        private final DoubleFunction<String> fmt;

        Slider(int x, int y, int w, int h, String label, double min, double max, boolean log, double current,
               DoubleConsumer set, DoubleFunction<String> fmt) {
            super(x, y, w, h, Text.empty(), 0.0);
            this.label = label; this.min = min; this.max = max; this.log = log; this.set = set; this.fmt = fmt;
            this.value = toSlider(current);
            updateMessage();
        }

        private double toSlider(double v) {
            v = Math.max(min, Math.min(max, v));
            if (log) return Math.log(v / min) / Math.log(max / min);
            return (v - min) / (max - min);
        }

        private double fromSlider() {
            if (log) return min * Math.pow(max / min, value);
            return min + (max - min) * value;
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal(label + ": " + fmt.apply(fromSlider())));
        }

        @Override
        protected void applyValue() {
            set.accept(fromSlider());
        }
    }
}

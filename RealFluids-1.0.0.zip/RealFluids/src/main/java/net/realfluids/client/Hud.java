package net.realfluids.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

final class Hud {
    private Hud() { }

    /** Action-bar message (above the hotbar). */
    static void message(String text) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.sendMessage(Text.literal(text), true);
    }
}

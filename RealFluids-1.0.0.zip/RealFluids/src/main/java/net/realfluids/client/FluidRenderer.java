package net.realfluids.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.gl.VertexBuffer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;
import net.realfluids.RealFluidsMod;
import net.realfluids.sim.QuadSort;
import net.realfluids.sim.SurfaceMesher;
import net.realfluids.sim.WaterShading;

import java.util.Arrays;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Draws every region's fluid surface after Minecraft's translucent pass.
 *
 * The surface is shaded per vertex on the CPU ({@link WaterShading}) and drawn with vanilla's
 * position/colour shader, so it works on any GPU, Android launcher, Sodium, and without shader packs.
 * Each region keeps its geometry in a GPU vertex buffer; it is only rebuilt when the simulation
 * publishes a new mesh, the camera moves or turns noticeably, or once a second for lighting.
 * Quads are depth-sorted back to front for correct transparency.
 */
public final class FluidRenderer {
    private FluidRenderer() { }

    private static final float REBUILD_MOVE_SQ = 0.35f * 0.35f;  // blocks
    private static final float REBUILD_TURN_DEG = 2.5f;
    private static final long LIGHT_REFRESH_NANOS = 1_000_000_000L;

    /** Per-region GPU buffer and scratch arrays (render thread only). */
    private static final class Cache {
        VertexBuffer vbo;
        boolean uploaded;
        long version = -1;
        double camX = Double.NaN, camY, camZ;
        float yaw, pitch;
        long lastBuild;
        int ox, oy, oz;

        // copy of the published mesh
        int quads, spray;
        float[] pos = new float[0], nrm = new float[0], foam = new float[0], sprayPos = new float[0], sprayFoam = new float[0];
        int[] rgb = new int[0], sprayRgb = new int[0];
        byte[] sprayKind = new byte[0];
        boolean glow;
        float h;

        // combined, shaded quads (surface + spray) ready to sort
        float[] qPos = new float[0];   // n * 12
        int[] qCol = new int[0];       // n * 4
        float[] qKey = new float[0];   // squared distance of each quad centre
        int[] order = new int[0], counts = new int[QuadSort.BUCKETS + 1];

        // light per block of the region (lazily filled, -1 = unknown)
        float[] light = new float[0];
        int lnx, lny, lnz;
        long lightStamp;
    }

    private static final Map<FluidWorld.Region, Cache> CACHES = new IdentityHashMap<>();
    private static BufferBuilder builder;
    private static boolean failed;

    /** WorldRenderEvents.AFTER_TRANSLUCENT. */
    public static void render(WorldRenderContext ctx) {
        if (failed) return;
        try {
            renderAll(ctx);
        } catch (Throwable t) {
            // never take the game down because of the overlay; log once and stop drawing
            failed = true;
            RealFluidsMod.LOG.error("Real Fluids renderer failed and has been disabled for this session", t);
            Hud.message("Real Fluids: rendering error (see log). Fluid still simulates.");
        }
    }

    /** Free GPU buffers (on disconnect). Render thread. */
    public static void releaseAll() {
        for (Cache c : CACHES.values()) if (c.vbo != null) c.vbo.close();
        CACHES.clear();
        failed = false;
    }

    private static void renderAll(WorldRenderContext ctx) {
        ClientWorld world = ctx.world();
        if (world == null) return;
        FluidWorld fw = FluidWorld.get();
        String dim = world.getRegistryKey().getValue().toString();

        // forget buffers of regions that no longer exist
        for (Iterator<Map.Entry<FluidWorld.Region, Cache>> it = CACHES.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<FluidWorld.Region, Cache> e = it.next();
            if (!fw.regions().contains(e.getKey())) {
                if (e.getValue().vbo != null) e.getValue().vbo.close();
                it.remove();
            }
        }
        if (fw.regions().isEmpty()) return;

        Camera camera = ctx.camera();
        Vec3d cam = camera.getPos();
        float tickDelta = ctx.tickDelta();
        Environment env = null;
        long now = System.nanoTime();

        for (FluidWorld.Region region : fw.regions()) {
            if (!region.dimension.equals(dim)) continue;
            SurfaceMesher.Mesh mesh = region.mesh();
            if (mesh == null) continue;
            Cache c = CACHES.computeIfAbsent(region, r -> new Cache());

            long version = region.meshVersion();
            boolean meshChanged = version != c.version;
            double dx = cam.x - c.camX, dy = cam.y - c.camY, dz = cam.z - c.camZ;
            boolean moved = Double.isNaN(c.camX) || dx * dx + dy * dy + dz * dz > REBUILD_MOVE_SQ;
            boolean turned = Math.abs(wrapDegrees(camera.getYaw() - c.yaw)) > REBUILD_TURN_DEG || Math.abs(camera.getPitch() - c.pitch) > REBUILD_TURN_DEG;
            boolean stale = now - c.lastBuild > LIGHT_REFRESH_NANOS;
            if (meshChanged || moved || turned || stale) {
                if (meshChanged) {
                    synchronized (mesh) { copyMesh(mesh, c); }
                    c.version = version;
                }
                if (env == null) env = Environment.sample(world, cam, tickDelta);
                rebuild(world, region, c, camera, env, now);
            }
            if (c.uploaded) draw(ctx, c, cam);
        }
    }

    // ------------------------------------------------------------------ mesh copy

    private static void copyMesh(SurfaceMesher.Mesh m, Cache c) {
        int q = m.quads, s = m.sprayCount;
        if (c.pos.length < q * 12) { c.pos = new float[q * 12]; c.nrm = new float[q * 12]; c.foam = new float[q * 4]; c.rgb = new int[q * 4]; }
        if (c.sprayRgb.length < s) { c.sprayPos = new float[s * 3]; c.sprayFoam = new float[s]; c.sprayRgb = new int[s]; c.sprayKind = new byte[s]; }
        System.arraycopy(m.pos, 0, c.pos, 0, q * 12);
        System.arraycopy(m.nrm, 0, c.nrm, 0, q * 12);
        System.arraycopy(m.foam, 0, c.foam, 0, q * 4);
        System.arraycopy(m.rgb, 0, c.rgb, 0, q * 4);
        System.arraycopy(m.spray, 0, c.sprayPos, 0, s * 3);
        System.arraycopy(m.sprayFoam, 0, c.sprayFoam, 0, s);
        System.arraycopy(m.sprayRgb, 0, c.sprayRgb, 0, s);
        System.arraycopy(m.sprayKind, 0, c.sprayKind, 0, s);
        c.quads = q; c.spray = s; c.glow = m.glow; c.h = m.h;
        c.ox = m.ox; c.oy = m.oy; c.oz = m.oz;
    }

    // ------------------------------------------------------------------ environment

    /** Sun, sky and ambient values shared by every region this frame. */
    private record Environment(float sx, float sy, float sz, float sunPower, int sky, float skyLight) {
        static Environment sample(ClientWorld world, Vec3d cam, float tickDelta) {
            // skyAngle 0 = noon, 0.25 = sunset (sun in the west, -X), 0.5 = midnight
            double a = world.getSkyAngle(tickDelta) * Math.PI * 2.0;
            float sx = (float) -Math.sin(a), sy = (float) Math.cos(a), sz = 0.18f;
            float power;
            if (sy < 0f) { sx = -sx; sy = -sy; power = 0.16f; } // moonlight
            else power = Math.min(1f, sy * 2.2f + 0.08f);
            float len = (float) Math.sqrt(sx * sx + sy * sy + sz * sz);
            sx /= len; sy /= len; sz /= len;
            float rain = world.getRainGradient(tickDelta), thunder = world.getThunderGradient(tickDelta);
            power *= 1f - 0.75f * rain;
            power *= 1f - 0.5f * thunder;
            Vec3d skyC = world.getSkyColor(cam, tickDelta);
            int sky = WaterShading.argb(1f, (float) skyC.x * 0.85f + 0.08f, (float) skyC.y * 0.85f + 0.1f, (float) skyC.z * 0.9f + 0.12f) & 0xFFFFFF;
            float skyLight = 1f - world.getAmbientDarkness() / 15f;
            if (!world.getDimension().hasSkyLight()) { power = 0f; skyLight = 0f; }
            return new Environment(sx, sy, sz, power, sky, skyLight);
        }
    }

    private static float lightAt(ClientWorld world, Cache c, Environment env, float bx, float by, float bz, long now) {
        int ix = (int) Math.floor(bx), iy = (int) Math.floor(by), iz = (int) Math.floor(bz);
        if (ix < 0 || iy < 0 || iz < 0 || ix >= c.lnx || iy >= c.lny || iz >= c.lnz) return 1f;
        int idx = ix + c.lnx * (iy + c.lny * iz);
        float v = c.light[idx];
        if (v < 0f) {
            BlockPos p = new BlockPos(c.ox + ix, c.oy + iy, c.oz + iz);
            int block = world.getLightLevel(LightType.BLOCK, p);
            int sky = world.getLightLevel(LightType.SKY, p);
            v = Math.max(block / 15f, sky / 15f * env.skyLight);
            c.light[idx] = v;
        }
        return v;
    }

    // ------------------------------------------------------------------ build

    private static void rebuild(ClientWorld world, FluidWorld.Region region, Cache c, Camera camera, Environment env, long now) {
        Vec3d cam = camera.getPos();
        c.camX = cam.x; c.camY = cam.y; c.camZ = cam.z;
        c.yaw = camera.getYaw(); c.pitch = camera.getPitch();
        c.lastBuild = now;

        // block-resolution light grid of the region, refreshed once a second
        int lnx = (int) Math.ceil(region.sim.nx * region.sim.h) + 1, lny = (int) Math.ceil(region.sim.ny * region.sim.h) + 1, lnz = (int) Math.ceil(region.sim.nz * region.sim.h) + 1;
        if (c.light.length != lnx * lny * lnz) { c.light = new float[lnx * lny * lnz]; c.lightStamp = 0; }
        c.lnx = lnx; c.lny = lny; c.lnz = lnz;
        if (now - c.lightStamp > LIGHT_REFRESH_NANOS) { Arrays.fill(c.light, -1f); c.lightStamp = now; }

        int maxQ = c.quads + c.spray;
        if (c.qCol.length < maxQ * 4) {
            int cap = maxQ + maxQ / 4 + 64;
            c.qPos = new float[cap * 12]; c.qCol = new int[cap * 4]; c.qKey = new float[cap]; c.order = new int[cap];
        }
        // camera in region-local blocks
        float cx = (float) (cam.x - c.ox), cy = (float) (cam.y - c.oy), cz = (float) (cam.z - c.oz);
        int n = 0;

        // ---- surface
        for (int q = 0; q < c.quads; q++) {
            int base = q * 12;
            float mx = 0, my = 0, mz = 0;
            for (int t = 0; t < 4; t++) {
                int o = base + t * 3;
                float x = c.pos[o], y = c.pos[o + 1], z = c.pos[o + 2];
                float nx = c.nrm[o], ny = c.nrm[o + 1], nz = c.nrm[o + 2];
                float vx = cx - x, vy = cy - y, vz = cz - z;
                float vl = (float) Math.sqrt(vx * vx + vy * vy + vz * vz);
                if (vl > 1e-5f) { vx /= vl; vy /= vl; vz /= vl; } else { vy = 1f; }
                if (nx * vx + ny * vy + nz * vz < 0f) { nx = -nx; ny = -ny; nz = -nz; } // seen from inside / below
                int col = c.rgb[q * 4 + t];
                float clarity = ((col >>> 24) & 0xFF) / 255f;
                float light = c.glow ? 1f : lightAt(world, c, env, x + nx * 0.3f, y + ny * 0.3f, z + nz * 0.3f, now);
                int argb = WaterShading.shade(nx, ny, nz, vx, vy, vz, env.sx, env.sy, env.sz, env.sunPower * light,
                    col & 0xFFFFFF, env.sky, light, clarity, c.foam[q * 4 + t], c.glow);
                c.qPos[n * 12 + t * 3] = x; c.qPos[n * 12 + t * 3 + 1] = y; c.qPos[n * 12 + t * 3 + 2] = z;
                c.qCol[n * 4 + t] = argb;
                mx += x; my += y; mz += z;
            }
            mx = mx * 0.25f - cx; my = my * 0.25f - cy; mz = mz * 0.25f - cz;
            c.qKey[n] = mx * mx + my * my + mz * mz;
            n++;
        }

        // ---- spray: camera-facing droplets and flat resting splats
        if (c.spray > 0) {
            double yaw = Math.toRadians(camera.getYaw()), pitch = Math.toRadians(camera.getPitch());
            float fx = (float) (-Math.sin(yaw) * Math.cos(pitch)), fy = (float) -Math.sin(pitch), fz = (float) (Math.cos(yaw) * Math.cos(pitch));
            // right = forward x worldUp, up = right x forward
            float rx = -fz, ry = 0f, rz = fx;
            float rl = (float) Math.sqrt(rx * rx + rz * rz);
            if (rl < 1e-4f) { rx = 1f; rz = 0f; rl = 1f; }
            rx /= rl; rz /= rl;
            float ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx;
            float drop = Math.max(0.05f, c.h * 0.32f), splat = Math.max(0.12f, c.h * 0.62f);
            for (int s = 0; s < c.spray; s++) {
                float x = c.sprayPos[s * 3], y = c.sprayPos[s * 3 + 1], z = c.sprayPos[s * 3 + 2];
                int col = c.sprayRgb[s];
                float foam = c.sprayFoam[s];
                float light = c.glow ? 1f : lightAt(world, c, env, x, y + 0.2f, z, now);
                float br = ((col >> 16) & 0xFF) / 255f, bg = ((col >> 8) & 0xFF) / 255f, bb = (col & 0xFF) / 255f;
                float clarity = ((col >>> 24) & 0xFF) / 255f;
                float lum = c.glow ? 1f : 0.15f + 0.85f * light;
                float w = Math.min(1f, 0.35f + foam); // droplets read whiter than the body
                float r = (br + (0.92f - br) * w) * lum, g = (bg + (0.94f - bg) * w) * lum, b = (bb + (0.97f - bb) * w) * lum;
                int o = n * 12;
                if (c.sprayKind[s] == 1) {
                    // wet film lying on the ground: flat, faint, not white
                    int argb = WaterShading.argb(0.28f + 0.5f * clarity, br * lum * 0.9f, bg * lum * 0.9f, bb * lum * 0.95f);
                    float yy = y + 0.012f;
                    put(c.qPos, o, x - splat, yy, z - splat); put(c.qPos, o + 3, x - splat, yy, z + splat);
                    put(c.qPos, o + 6, x + splat, yy, z + splat); put(c.qPos, o + 9, x + splat, yy, z - splat);
                    Arrays.fill(c.qCol, n * 4, n * 4 + 4, argb);
                } else {
                    int argb = WaterShading.argb(0.45f + 0.4f * Math.max(clarity, w), r, g, b);
                    float ax = (rx + ux) * drop, ay = (ry + uy) * drop, az = (rz + uz) * drop;
                    float bx = (rx - ux) * drop, by = (ry - uy) * drop, bz = (rz - uz) * drop;
                    put(c.qPos, o, x - ax, y - ay, z - az); put(c.qPos, o + 3, x + bx, y + by, z + bz);
                    put(c.qPos, o + 6, x + ax, y + ay, z + az); put(c.qPos, o + 9, x - bx, y - by, z - bz);
                    Arrays.fill(c.qCol, n * 4, n * 4 + 4, argb);
                }
                float ddx = x - cx, ddy = y - cy, ddz = z - cz;
                c.qKey[n] = ddx * ddx + ddy * ddy + ddz * ddz;
                n++;
            }
        }

        if (n == 0) { c.uploaded = false; return; }
        QuadSort.backToFront(c.qKey, n, c.order, c.counts);

        if (builder == null) builder = new BufferBuilder(1 << 18);
        BufferBuilder bb = builder;
        bb.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (int i = 0; i < n; i++) {
            int q = c.order[i];
            int po = q * 12, co = q * 4;
            for (int t = 0; t < 4; t++) {
                int argb = c.qCol[co + t];
                bb.vertex(c.qPos[po + t * 3], c.qPos[po + t * 3 + 1], c.qPos[po + t * 3 + 2])
                    .color((argb >> 16) & 0xFF, (argb >> 8) & 0xFF, argb & 0xFF, (argb >>> 24) & 0xFF)
                    .next();
            }
        }
        BufferBuilder.BuiltBuffer built = bb.end();
        if (c.vbo == null) c.vbo = new VertexBuffer(VertexBuffer.Usage.DYNAMIC);
        c.vbo.bind();
        c.vbo.upload(built);
        VertexBuffer.unbind();
        c.uploaded = true;
    }

    private static void put(float[] a, int o, float x, float y, float z) { a[o] = x; a[o + 1] = y; a[o + 2] = z; }

    // ------------------------------------------------------------------ draw

    private static void draw(WorldRenderContext ctx, Cache c, Vec3d cam) {
        MatrixStack ms = ctx.matrixStack();
        ms.push();
        ms.translate(c.ox - cam.x, c.oy - cam.y, c.oz - cam.z);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.disableCull(); // the surface is visible from underneath too
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        c.vbo.bind();
        c.vbo.draw(ms.peek().getPositionMatrix(), ctx.projectionMatrix(), GameRenderer.getPositionColorProgram());
        VertexBuffer.unbind();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        ms.pop();
    }

    private static float wrapDegrees(float d) {
        d %= 360f;
        if (d >= 180f) d -= 360f;
        if (d < -180f) d += 360f;
        return d;
    }
}

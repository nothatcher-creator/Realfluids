package net.realfluids.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import net.realfluids.RealFluidsMod;
import net.realfluids.config.RealFluidsConfig;
import net.realfluids.sim.DomainIO;
import net.realfluids.sim.FluidDomain;
import net.realfluids.sim.FluidProps;
import net.realfluids.sim.FluidSnapshot;
import net.realfluids.sim.SurfaceMesher;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Client-side owner of every simulated region. The game thread schedules work; one background
 * thread runs the solver and builds meshes, so a slow phone CPU lowers the simulation speed
 * instead of the frame rate.
 */
public final class FluidWorld {
    private static final FluidWorld INSTANCE = new FluidWorld();
    public static FluidWorld get() { return INSTANCE; }

    public final class Region {
        public final String dimension;
        public final FluidDomain sim;
        final SurfaceMesher mesher = new SurfaceMesher();
        private final SurfaceMesher.Mesh[] meshes = { new SurfaceMesher.Mesh(), new SurfaceMesher.Mesh() };
        private final FluidSnapshot[] snaps = { new FluidSnapshot(), new FluidSnapshot() };
        private int writeIndex;
        volatile SurfaceMesher.Mesh mesh;       // latest published mesh (lock it while reading)
        volatile long meshVersion;
        volatile FluidSnapshot snapshot;        // latest published snapshot (lock it while reading)
        final ConcurrentLinkedQueue<Consumer<FluidDomain>> commands = new ConcurrentLinkedQueue<>();
        volatile boolean busy;
        volatile int particles;
        volatile boolean sleeping;
        volatile float stepMillis;
        final WorldSampler sampler;
        int emptyTicks;
        /** Restored from disk: don't simulate until the terrain under it has loaded and been sampled. */
        boolean awaitingWorld;

        Region(String dimension, FluidDomain sim) {
            this.dimension = dimension;
            this.sim = sim;
            this.sampler = new WorldSampler(sim);
            this.particles = sim.particleCount();
        }

        public boolean contains(double x, double y, double z, double margin) { return sim.containsWorldPoint(x, y, z, margin); }

        /** Latest snapshot (may be null before the first step). Synchronize on it while reading. */
        public FluidSnapshot snapshot() { return snapshot; }
        public SurfaceMesher.Mesh mesh() { return mesh; }
        public long meshVersion() { return meshVersion; }
        public int particles() { return particles; }
        public boolean sleeping() { return sleeping; }
        public float stepMillis() { return stepMillis; }

        /** Runs on the simulation thread. */
        void work(float dt, RealFluidsConfig cfg) {
            try {
                Consumer<FluidDomain> c;
                while ((c = commands.poll()) != null) c.accept(sim);
                sim.evaporateSeconds = cfg.evaporateSeconds;
                sim.step(dt, cfg.maxSubsteps);
                int idx = writeIndex;
                writeIndex ^= 1;
                SurfaceMesher.Mesh m = meshes[idx];
                synchronized (m) {
                    mesher.build(sim, cfg.meshSmoothing, cfg.maxQuads, cfg.renderSpray ? cfg.maxSprayParticles : 0, m);
                }
                FluidSnapshot s = snaps[idx];
                synchronized (s) {
                    sim.fillSnapshot(s);
                }
                mesh = m;
                snapshot = s;
                meshVersion++;
                particles = sim.particleCount() + (sim.emitterCount() > 0 ? 1 : 0);
                sleeping = sim.isSleeping();
                stepMillis = sim.lastStepMillis;
            } catch (Throwable t) {
                RealFluidsMod.LOG.error("fluid simulation step failed; clearing region", t);
                sim.clear();
                particles = 0;
            } finally {
                busy = false;
            }
        }
    }

    private final List<Region> regions = new ArrayList<>();
    private ExecutorService worker;
    private boolean paused;
    private float accumulator;
    private String saveKey;

    private FluidWorld() { }

    private ExecutorService worker() {
        if (worker == null || worker.isShutdown()) {
            worker = Executors.newSingleThreadExecutor(r -> {
                Thread t = new Thread(r, "RealFluids-Sim");
                t.setDaemon(true);
                t.setPriority(Thread.NORM_PRIORITY - 1);
                return t;
            });
        }
        return worker;
    }

    public List<Region> regions() { return regions; }
    public boolean isPaused() { return paused; }
    public void setPaused(boolean p) { paused = p; }

    // ------------------------------------------------------------------ game thread API

    /** Pour fluid at a world position (already validated by the server, or local-only mode). */
    public void spawn(ClientWorld world, double x, double y, double z, float dx, float dy, float dz, FluidProps props) {
        Region r = regionFor(world, x, y, z, true);
        if (r == null) return;
        FluidProps p = props.copy().sanitize();
        r.commands.add(d -> d.spawn(x, y, z, dx, dy, dz, p));
        r.particles = Math.max(r.particles, 1);
        r.emptyTicks = 0;
    }

    /** What a scoop took out of the simulation: the mixed properties and how many cubic blocks. */
    public record Scooped(FluidProps props, float volume, int particles) { }

    /**
     * Removes fluid around a point. {@code maxVolume} is in cubic blocks (a bucket's worth).
     * {@code done} runs on the client thread once the simulation thread has removed it.
     */
    public void remove(ClientWorld world, double x, double y, double z, float radius, float maxVolume, Consumer<Scooped> done) {
        Region r = regionFor(world, x, y, z, false);
        if (r == null) {
            if (done != null) done.accept(new Scooped(null, 0f, 0));
            return;
        }
        r.commands.add(d -> {
            int max = Math.max(1, Math.round(maxVolume / (d.h * d.h * d.h) * d.ppc));
            FluidDomain.RemovalResult res = d.remove(x, y, z, radius, max);
            Scooped out = new Scooped(res.removed > 0 ? res.toProps(null) : null, res.volume(d), res.removed);
            if (out.props() != null) out.props().name = FluidProps.closestPresetName(out.props());
            if (done != null) MinecraftClient.getInstance().execute(() -> done.accept(out));
        });
    }

    /** Fluid occupancy (0..1) at a world point, read from the latest snapshot of whichever region holds it. */
    public float occupancyAt(ClientWorld world, double x, double y, double z) {
        Region r = find(world, x, y, z, 0.0);
        if (r == null) return 0f;
        FluidSnapshot s = r.snapshot;
        if (s == null) return 0f;
        synchronized (s) { return s.occupancyAt(x, y, z); }
    }

    public void impulse(Region r, double x, double y, double z, double radius, Vec3d vel, float strength) {
        r.commands.add(d -> d.addImpulse(x, y, z, radius, vel.x, vel.y, vel.z, strength));
    }

    public void clearAll() {
        for (Region r : regions) r.commands.add(FluidDomain::clear);
    }

    /** Region of the current dimension containing a point (with margin), or null. */
    public Region find(ClientWorld world, double x, double y, double z, double margin) {
        String dim = world.getRegistryKey().getValue().toString();
        for (Region r : regions) if (r.dimension.equals(dim) && r.contains(x, y, z, margin)) return r;
        return null;
    }

    private Region regionFor(ClientWorld world, double x, double y, double z, boolean create) {
        Region r = find(world, x, y, z, 1.5);
        if (r != null || !create) return r != null ? r : find(world, x, y, z, 0.0);
        RealFluidsConfig cfg = RealFluidsConfig.get();
        String dim = world.getRegistryKey().getValue().toString();
        long inDim = regions.stream().filter(q -> q.dimension.equals(dim)).count();
        if (inDim >= cfg.maxRegions) {
            // reuse the region with the least fluid
            Region victim = regions.stream().filter(q -> q.dimension.equals(dim)).min((a, b) -> Integer.compare(a.particles, b.particles)).orElse(null);
            if (victim != null && victim.particles > 0) {
                Hud.message("Too many fluid regions - use /realfluids clear, or raise maxRegions in config/realfluids.json");
                return null;
            }
            regions.remove(victim);
        }
        float h = cfg.cellSize;
        int nx = Math.max(8, Math.round(cfg.regionWidth / h)), nz = nx, ny = Math.max(8, Math.round(cfg.regionHeight / h));
        int ox = (int) Math.floor(x) - cfg.regionWidth / 2, oz = (int) Math.floor(z) - cfg.regionWidth / 2;
        int below = (int) Math.floor(cfg.regionHeight * 0.45);
        int oy = (int) Math.floor(y) - below;
        oy = Math.max(world.getBottomY(), Math.min(oy, world.getTopY() - cfg.regionHeight));
        FluidDomain d = new FluidDomain(ox, oy, oz, nx, ny, nz, h, cfg.particlesPerCell, cfg.maxParticles, System.nanoTime());
        Region region = new Region(dim, d);
        region.sampler.sampleAll(world, cfg.absorbIntoVanillaWater); // first mask synchronously so the pour lands on real ground
        region.commands.add(sim -> sim.setWorld(region.sampler.takeMask()));
        regions.add(region);
        RealFluidsMod.LOG.debug("new fluid region at {} {} {} ({}x{}x{} cells)", ox, oy, oz, nx, ny, nz);
        return region;
    }

    /** Called every client tick (game thread). */
    public void tick(MinecraftClient client) {
        ClientWorld world = client.world;
        if (world == null || client.player == null) return;
        if (paused || client.isPaused()) return;
        RealFluidsConfig cfg = RealFluidsConfig.get();
        String dim = world.getRegistryKey().getValue().toString();
        accumulator += 0.05f;
        float stepDt = 1f / cfg.simulationHz;
        if (accumulator < stepDt) return;
        float dt = Math.min(accumulator, 0.1f); // never more than 0.1 s per step: lag makes slow motion, not explosions
        accumulator = 0f;
        Vec3d pp = client.player.getPos();
        for (int i = regions.size() - 1; i >= 0; i--) {
            Region r = regions.get(i);
            if (!r.dimension.equals(dim)) continue;
            double cx = r.sim.ox + r.sim.nx * r.sim.h * 0.5, cz = r.sim.oz + r.sim.nz * r.sim.h * 0.5;
            if (Math.hypot(pp.x - cx, pp.z - cz) > cfg.simulateDistance) continue;
            if (r.awaitingWorld) {
                if (!terrainLoaded(world, r.sim)) continue; // saved fluid waits for its chunks instead of falling through them
                r.sampler.sampleAll(world, cfg.absorbIntoVanillaWater);
                byte[] mask = r.sampler.takeMask();
                r.commands.add(sim -> sim.setWorld(mask));
                r.awaitingWorld = false;
            } else if (r.sampler.sampleSome(world, cfg.absorbIntoVanillaWater)) {
                // keep the solid/sink mask fresh (players dig and build around the water)
                byte[] mask = r.sampler.takeMask();
                r.commands.add(sim -> sim.setWorld(mask));
            }
            if (r.particles == 0 && r.commands.isEmpty()) {
                if (++r.emptyTicks > 40) regions.remove(i);
                continue;
            }
            r.emptyTicks = 0;
            if (r.busy) continue; // still working on the previous step: the sim slows down instead of the game
            r.busy = true;
            worker().submit(() -> r.work(dt, cfg));
        }
    }

    private static boolean terrainLoaded(ClientWorld world, FluidDomain d) {
        int x0 = d.ox >> 4, z0 = d.oz >> 4;
        int x1 = (int) Math.floor(d.ox + d.nx * d.h) >> 4, z1 = (int) Math.floor(d.oz + d.nz * d.h) >> 4;
        for (int cx = x0; cx <= x1; cx++) for (int cz = z0; cz <= z1; cz++) if (!world.isChunkLoaded(cx, cz)) return false;
        return true;
    }

    // ------------------------------------------------------------------ persistence

    private static Path saveDir() {
        return net.fabricmc.loader.api.FabricLoader.getInstance().getGameDir().resolve("realfluids");
    }

    private static String sanitizeKey(String s) {
        return s.replaceAll("[^A-Za-z0-9._-]", "_");
    }

    /** Identifies the world/server so fluid is restored to the right save. */
    public static String worldKey(MinecraftClient client) {
        if (client.isIntegratedServerRunning() && client.getServer() != null) {
            return "sp_" + sanitizeKey(client.getServer().getSaveProperties().getLevelName());
        }
        if (client.getCurrentServerEntry() != null) return "mp_" + sanitizeKey(client.getCurrentServerEntry().address);
        return null;
    }

    public void onJoin(MinecraftClient client) {
        regions.clear();
        accumulator = 0f;
        paused = false;
        saveKey = worldKey(client);
        RealFluidsConfig cfg = RealFluidsConfig.get();
        if (!cfg.saveWithWorld || saveKey == null) return;
        Path file = saveDir().resolve(saveKey + ".rfld.gz");
        if (!Files.exists(file)) return;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new GZIPInputStream(Files.newInputStream(file))))) {
            int restored = 0;
            for (DomainIO.Saved s : DomainIO.read(in, cfg.maxParticles)) {
                Region r = new Region(s.dimension(), s.domain());
                r.awaitingWorld = true;
                regions.add(r);
                restored += s.domain().particleCount();
            }
            RealFluidsMod.LOG.info("restored {} fluid regions ({} particles) for {}", regions.size(), restored, saveKey);
        } catch (Exception e) {
            RealFluidsMod.LOG.warn("could not load saved fluid for {}: {}", saveKey, e.toString());
        }
    }

    public void onDisconnect() {
        RealFluidsConfig cfg = RealFluidsConfig.get();
        String key = saveKey;
        List<Region> snapshot = new ArrayList<>(regions);
        regions.clear();
        saveKey = null;
        if (worker == null) return;
        if (cfg.saveWithWorld && key != null) {
            Future<?> f = worker().submit(() -> {
                try {
                    Files.createDirectories(saveDir());
                    Path file = saveDir().resolve(key + ".rfld.gz");
                    List<DomainIO.Saved> saved = new ArrayList<>();
                    for (Region r : snapshot) {
                        Consumer<FluidDomain> c;
                        while ((c = r.commands.poll()) != null) c.accept(r.sim);
                        if (r.sim.particleCount() > 0) saved.add(new DomainIO.Saved(r.dimension, r.sim));
                    }
                    if (saved.isEmpty()) {
                        Files.deleteIfExists(file);
                        return;
                    }
                    Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
                    try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new GZIPOutputStream(Files.newOutputStream(tmp))))) {
                        DomainIO.write(out, saved);
                    }
                    Files.move(tmp, file, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                    RealFluidsMod.LOG.info("saved {} fluid regions for {}", saved.size(), key);
                } catch (Exception e) {
                    RealFluidsMod.LOG.warn("could not save fluid for {}: {}", key, e.toString());
                }
            });
            try { f.get(5, TimeUnit.SECONDS); } catch (Exception e) { RealFluidsMod.LOG.warn("fluid save timed out: {}", e.toString()); }
        }
        worker.shutdown();
        worker = null;
    }
}

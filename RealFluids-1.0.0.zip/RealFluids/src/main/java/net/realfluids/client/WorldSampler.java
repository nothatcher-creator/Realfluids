package net.realfluids.client;

import net.minecraft.block.BlockState;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.fluid.FluidState;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.shape.VoxelShape;
import net.realfluids.sim.FluidDomain;

import java.util.List;

/**
 * Builds the solid / sink mask for a region from real blocks (game thread only - world access is not
 * thread-safe). Partial blocks (slabs, stairs, fences, walls) are resolved per simulation cell from
 * their collision boxes. Work is spread over several ticks so it never causes a frame hitch.
 */
final class WorldSampler {
    private final FluidDomain sim;
    private final byte[] working;
    private byte[] ready;
    private int nextLayer;
    private final BlockPos.Mutable pos = new BlockPos.Mutable();

    WorldSampler(FluidDomain sim) {
        this.sim = sim;
        this.working = new byte[sim.nx * sim.ny * sim.nz];
    }

    void markDirty() { nextLayer = 0; }

    /** Samples the whole region now. */
    void sampleAll(ClientWorld world, boolean absorb) {
        for (int j = 0; j < sim.ny; j++) sampleLayer(world, j, absorb);
        ready = working.clone();
        nextLayer = 0;
    }

    /** Samples a few cell layers; returns true when a full pass finished and a new mask is ready. */
    boolean sampleSome(ClientWorld world, boolean absorb) {
        int layers = Math.max(1, sim.ny / 8); // full refresh every ~8 steps
        for (int n = 0; n < layers; n++) {
            sampleLayer(world, nextLayer, absorb);
            if (++nextLayer >= sim.ny) {
                nextLayer = 0;
                ready = working.clone();
                return true;
            }
        }
        return false;
    }

    byte[] takeMask() {
        byte[] m = ready;
        ready = null;
        return m != null ? m : working.clone();
    }

    private void sampleLayer(ClientWorld world, int j, boolean absorb) {
        final int nx = sim.nx, ny = sim.ny, nz = sim.nz;
        final float h = sim.h;
        double cy = sim.oy + (j + 0.5) * h;
        int by = (int) Math.floor(cy);
        for (int k = 0; k < nz; k++) {
            double cz = sim.oz + (k + 0.5) * h;
            int bz = (int) Math.floor(cz);
            for (int i = 0; i < nx; i++) {
                double cx = sim.ox + (i + 0.5) * h;
                int bx = (int) Math.floor(cx);
                working[i + nx * (j + ny * k)] = classify(world, bx, by, bz, cx - bx, cy - by, cz - bz, absorb);
            }
        }
    }

    private byte classify(ClientWorld world, int bx, int by, int bz, double fx, double fy, double fz, boolean absorb) {
        if (by < world.getBottomY() || by >= world.getTopY()) return FluidDomain.SOLID;
        if (!world.isChunkLoaded(bx >> 4, bz >> 4)) return FluidDomain.SOLID; // never leak into unloaded terrain
        pos.set(bx, by, bz);
        BlockState state = world.getBlockState(pos);
        if (state.isAir()) return FluidDomain.AIR;
        VoxelShape shape = state.getCollisionShape(world, pos);
        if (!shape.isEmpty()) {
            List<Box> boxes = shape.getBoundingBoxes();
            for (Box b : boxes) {
                if (fx >= b.minX && fx <= b.maxX && fy >= b.minY && fy <= b.maxY && fz >= b.minZ && fz <= b.maxZ) return FluidDomain.SOLID;
            }
        }
        FluidState fluid = state.getFluidState();
        if (absorb && !fluid.isEmpty() && (fluid.isIn(FluidTags.WATER) || fluid.isIn(FluidTags.LAVA))) return FluidDomain.SINK;
        return FluidDomain.AIR;
    }
}

package net.realfluids.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.realfluids.RealFluidsMod;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** config/realfluids.json - created with defaults on first launch. */
public final class RealFluidsConfig {
    /** low / medium / high: picks cell size and particle budget. "custom" uses the fields below as written. */
    public String quality = "medium";
    public float cellSize = 0.5f;          // blocks per simulation cell
    public int particlesPerCell = 8;
    public int maxParticles = 40000;       // per region
    public int maxRegions = 4;
    public int regionWidth = 24;           // blocks (x and z)
    public int regionHeight = 20;          // blocks
    public int simulationHz = 20;
    public int maxSubsteps = 4;
    public int meshSmoothing = 1;
    public int maxQuads = 60000;
    public int maxSprayParticles = 4000;
    public boolean renderSpray = true;
    public boolean playerPhysics = true;
    public boolean absorbIntoVanillaWater = true; // real water flowing into a lake/ocean merges into it
    public float evaporateSeconds = 45f;         // lone thin films soak away after this (0 = never)
    public boolean saveWithWorld = true;
    public float simulateDistance = 160f;        // regions farther than this from the player pause

    private static RealFluidsConfig instance;

    public static RealFluidsConfig get() {
        if (instance == null) instance = load();
        return instance;
    }

    public void applyQualityPreset() {
        switch (quality) {
            case "low" -> { cellSize = 1.0f; particlesPerCell = 8; maxParticles = 15000; meshSmoothing = 1; maxSubsteps = 3; }
            case "medium" -> { cellSize = 0.5f; particlesPerCell = 8; maxParticles = 40000; meshSmoothing = 1; maxSubsteps = 4; }
            case "high" -> { cellSize = 0.34f; particlesPerCell = 8; maxParticles = 90000; meshSmoothing = 1; maxSubsteps = 4; }
            default -> { }
        }
        sanitize();
    }

    public void sanitize() {
        cellSize = clamp(cellSize, 0.25f, 1.0f);
        particlesPerCell = (int) clamp(particlesPerCell, 1, 27);
        maxParticles = (int) clamp(maxParticles, 1000, 400000);
        maxRegions = (int) clamp(maxRegions, 1, 16);
        regionWidth = (int) clamp(regionWidth, 6, 64);
        regionHeight = (int) clamp(regionHeight, 6, 64);
        simulationHz = (int) clamp(simulationHz, 5, 60);
        maxSubsteps = (int) clamp(maxSubsteps, 1, 8);
        meshSmoothing = (int) clamp(meshSmoothing, 0, 3);
        maxQuads = (int) clamp(maxQuads, 1000, 500000);
        maxSprayParticles = (int) clamp(maxSprayParticles, 0, 50000);
        evaporateSeconds = clamp(evaporateSeconds, 0f, 3600f);
        simulateDistance = clamp(simulateDistance, 32f, 1024f);
        if (quality == null) quality = "medium";
    }

    private static float clamp(float v, float lo, float hi) { return Float.isNaN(v) ? lo : Math.max(lo, Math.min(hi, v)); }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path path() { return FabricLoader.getInstance().getConfigDir().resolve("realfluids.json"); }

    private static RealFluidsConfig load() {
        Path p = path();
        RealFluidsConfig c = null;
        if (Files.exists(p)) {
            try (Reader r = Files.newBufferedReader(p)) {
                c = GSON.fromJson(r, RealFluidsConfig.class);
            } catch (Exception e) {
                RealFluidsMod.LOG.warn("realfluids.json unreadable, using defaults: {}", e.toString());
            }
        }
        if (c == null) c = new RealFluidsConfig();
        c.applyQualityPreset();
        c.save();
        return c;
    }

    public void save() {
        try {
            Files.createDirectories(path().getParent());
            try (Writer w = Files.newBufferedWriter(path())) {
                GSON.toJson(this, w);
            }
        } catch (Exception e) {
            RealFluidsMod.LOG.warn("could not write realfluids.json: {}", e.toString());
        }
    }
}

package net.realfluids;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.BlockState;
import net.minecraft.block.FluidDrainable;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.realfluids.item.FluidBucketData;
import net.realfluids.net.Packets;
import net.realfluids.sim.FluidProps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Common/server side. The simulation itself runs on each client (it is visual + local physics);
 * the server owns the items: it validates pours and scoops, swaps buckets, and tells nearby
 * clients where to spawn or remove fluid so everyone sees the same pours.
 */
public class RealFluidsMod implements ModInitializer {
    public static final String MOD_ID = Packets.MOD_ID;
    public static final Logger LOG = LoggerFactory.getLogger("RealFluids");
    private static final double MAX_REACH_SQ = 9.0 * 9.0;

    @Override
    public void onInitialize() {
        ServerPlayNetworking.registerGlobalReceiver(Packets.CONFIGURE, (server, player, handler, buf, sender) -> {
            NbtCompound tag = buf.readNbt();
            boolean enabled = buf.readBoolean();
            server.execute(() -> configure(player, tag, enabled));
        });
        ServerPlayNetworking.registerGlobalReceiver(Packets.POUR, (server, player, handler, buf, sender) -> {
            double x = buf.readDouble(), y = buf.readDouble(), z = buf.readDouble();
            float dx = buf.readFloat(), dy = buf.readFloat(), dz = buf.readFloat();
            server.execute(() -> pour(player, x, y, z, dx, dy, dz));
        });
        ServerPlayNetworking.registerGlobalReceiver(Packets.SCOOP, (server, player, handler, buf, sender) -> {
            double x = buf.readDouble(), y = buf.readDouble(), z = buf.readDouble();
            float volume = buf.readFloat();
            NbtCompound tag = buf.readNbt();
            server.execute(() -> scoop(player, x, y, z, volume, tag));
        });
        ServerPlayNetworking.registerGlobalReceiver(Packets.STATUS, (server, player, handler, buf, sender) -> {
            byte flags = buf.readByte();
            server.execute(() -> status(player, flags));
        });

        // Stop vanilla from placing a water/lava block for real-fluid buckets, and let configured
        // empty buckets fill from vanilla sources while keeping their settings.
        // (Client-side use is handled in RealFluidsClient, which registers after this and only sees PASS here.)
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.isClient()) return TypedActionResult.pass(player.getStackInHand(hand));
            ItemStack stack = player.getStackInHand(hand);
            if (FluidBucketData.isRealFluidFull(stack)) {
                return TypedActionResult.fail(stack); // never place a vanilla block; the client sends POUR instead
            }
            if (FluidBucketData.isRealFluidEmpty(stack) && player instanceof ServerPlayerEntity sp) {
                ItemStack filled = fillFromVanillaSource(sp, (ServerWorld) world, hand, stack);
                if (filled != null) {
                    // Fabric only forwards the ActionResult, not the stack, so put the result in the hand ourselves
                    if (filled != stack) player.setStackInHand(hand, filled);
                    return TypedActionResult.success(filled, false);
                }
            }
            return TypedActionResult.pass(stack);
        });
        LOG.info("Real Fluids loaded");
    }

    // ------------------------------------------------------------------ handlers (server thread)

    private static void configure(ServerPlayerEntity player, NbtCompound tag, boolean enabled) {
        ItemStack stack = player.getMainHandStack();
        if (!FluidBucketData.isConfigurableBucket(stack)) return;
        if (!enabled) {
            FluidBucketData.clear(stack);
            return;
        }
        if (tag == null) return;
        FluidBucketData.write(stack, FluidBucketData.fromNbt(tag)); // fromNbt sanitizes
    }

    private static void pour(ServerPlayerEntity player, double x, double y, double z, float dx, float dy, float dz) {
        Hand hand = handHolding(player, true);
        if (hand == null) return;
        if (player.squaredDistanceTo(x, y, z) > MAX_REACH_SQ || !Double.isFinite(x + y + z)) return;
        ItemStack stack = player.getStackInHand(hand);
        FluidProps props = FluidBucketData.read(stack);
        if (!player.getAbilities().creativeMode) {
            ItemStack empty = new ItemStack(Items.BUCKET);
            FluidBucketData.write(empty, props); // the empty bucket remembers its recipe
            player.setStackInHand(hand, empty);
        }
        ServerWorld world = player.getServerWorld();
        world.playSound(null, BlockPos.ofFloored(x, y, z), props.hot ? SoundEvents.ITEM_BUCKET_EMPTY_LAVA : SoundEvents.ITEM_BUCKET_EMPTY,
            SoundCategory.BLOCKS, 1.0f, 1.0f);
        NbtCompound tag = FluidBucketData.toNbt(props);
        for (ServerPlayerEntity other : PlayerLookup.around(world, new Vec3d(x, y, z), Packets.SYNC_RADIUS)) {
            PacketByteBuf out = PacketByteBufs.create();
            out.writeDouble(x); out.writeDouble(y); out.writeDouble(z);
            out.writeFloat(dx); out.writeFloat(dy); out.writeFloat(dz);
            out.writeNbt(tag);
            ServerPlayNetworking.send(other, Packets.SPAWN, out);
        }
    }

    private static void scoop(ServerPlayerEntity player, double x, double y, double z, float volume, NbtCompound tag) {
        Hand hand = handHolding(player, false);
        if (hand == null || tag == null || volume <= 0.05f) return;
        if (player.squaredDistanceTo(x, y, z) > MAX_REACH_SQ || !Double.isFinite(x + y + z)) return;
        ItemStack stack = player.getStackInHand(hand);
        FluidProps props = FluidBucketData.fromNbt(tag);
        FluidProps recipe = FluidBucketData.isRealFluidEmpty(stack) ? FluidBucketData.read(stack) : props;
        props.volume = Math.max(0.25f, Math.min(volume, recipe.volume));
        props.shape = recipe.shape; props.mode = recipe.mode; props.speed = recipe.speed; props.duration = recipe.duration;
        ItemStack full = new ItemStack(props.hot ? Items.LAVA_BUCKET : Items.WATER_BUCKET);
        FluidBucketData.write(full, props);
        if (player.getAbilities().creativeMode) {
            if (!player.getInventory().insertStack(full)) player.dropItem(full, false);
        } else if (stack.getCount() == 1) {
            player.setStackInHand(hand, full);
        } else {
            stack.decrement(1);
            if (!player.getInventory().insertStack(full)) player.dropItem(full, false);
        }
        ServerWorld world = player.getServerWorld();
        world.playSound(null, BlockPos.ofFloored(x, y, z), props.hot ? SoundEvents.ITEM_BUCKET_FILL_LAVA : SoundEvents.ITEM_BUCKET_FILL, SoundCategory.BLOCKS, 1.0f, 1.0f);
        // tell everyone else to remove the same fluid (the scooper already removed it locally)
        int particles = Math.max(1, Math.round(volume * 64));
        for (ServerPlayerEntity other : PlayerLookup.around(world, new Vec3d(x, y, z), Packets.SYNC_RADIUS)) {
            if (other == player) continue;
            PacketByteBuf out = PacketByteBufs.create();
            out.writeDouble(x); out.writeDouble(y); out.writeDouble(z);
            out.writeFloat(2.0f);
            out.writeInt(particles);
            ServerPlayNetworking.send(other, Packets.REMOVE, out);
        }
    }

    private static void status(ServerPlayerEntity player, byte flags) {
        if ((flags & 1) != 0) {
            player.fallDistance = 0f;
            if ((flags & 2) != 0) {
                if (!player.isFireImmune()) player.setOnFireFor(4);
            } else if (player.isOnFire()) {
                player.extinguish();
            }
        }
    }

    // ------------------------------------------------------------------ helpers

    /** Which hand holds a real-fluid bucket (full) or any empty bucket. */
    private static Hand handHolding(ServerPlayerEntity player, boolean full) {
        for (Hand hand : Hand.values()) {
            ItemStack s = player.getStackInHand(hand);
            if (full ? FluidBucketData.isRealFluidFull(s) : s.isOf(Items.BUCKET)) return hand;
        }
        return null;
    }

    /** Vanilla bucket filling, but the result keeps the RealFluid settings. Returns null if nothing to fill from. */
    private static ItemStack fillFromVanillaSource(ServerPlayerEntity player, ServerWorld world, Hand hand, ItemStack bucket) {
        Vec3d eye = player.getEyePos();
        Vec3d end = eye.add(player.getRotationVec(1.0f).multiply(5.0));
        BlockHitResult hit = world.raycast(new RaycastContext(eye, end, RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.SOURCE_ONLY, player));
        if (hit.getType() != HitResult.Type.BLOCK) return null;
        BlockPos pos = hit.getBlockPos();
        if (!world.canPlayerModifyAt(player, pos)) return null;
        BlockState state = world.getBlockState(pos);
        if (!(state.getBlock() instanceof FluidDrainable drainable)) return null;
        boolean lava = world.getFluidState(pos).isIn(FluidTags.LAVA);
        if (!world.getFluidState(pos).isIn(FluidTags.WATER) && !lava) return null;
        ItemStack drained = drainable.tryDrainFluid(world, pos, state);
        if (drained.isEmpty()) return null;
        FluidProps props = FluidBucketData.read(bucket);
        if (lava && !props.hot) props = FluidProps.preset("lava");
        ItemStack full = new ItemStack(lava ? Items.LAVA_BUCKET : Items.WATER_BUCKET);
        FluidBucketData.write(full, props);
        world.playSound(null, pos, lava ? SoundEvents.ITEM_BUCKET_FILL_LAVA : SoundEvents.ITEM_BUCKET_FILL, SoundCategory.BLOCKS, 1.0f, 1.0f);
        if (player.getAbilities().creativeMode) {
            if (!player.getInventory().insertStack(full)) player.dropItem(full, false);
            return bucket;
        }
        if (bucket.getCount() == 1) return full;
        bucket.decrement(1);
        if (!player.getInventory().insertStack(full)) player.dropItem(full, false);
        return bucket;
    }
}

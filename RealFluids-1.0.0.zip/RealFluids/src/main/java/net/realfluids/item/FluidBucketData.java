package net.realfluids.item;

import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.realfluids.sim.FluidProps;

import java.util.HashMap;
import java.util.Map;

/** Stores {@link FluidProps} on a bucket under the "RealFluid" NBT compound. */
public final class FluidBucketData {
    public static final String KEY = "RealFluid";

    private FluidBucketData() { }

    /** Buckets the editor (Z) works on. */
    public static boolean isConfigurableBucket(ItemStack stack) {
        return stack.isOf(Items.BUCKET) || stack.isOf(Items.WATER_BUCKET) || stack.isOf(Items.LAVA_BUCKET);
    }

    /** A full bucket that pours simulated fluid instead of vanilla blocks. */
    public static boolean isRealFluidFull(ItemStack stack) {
        return (stack.isOf(Items.WATER_BUCKET) || stack.isOf(Items.LAVA_BUCKET)) && stack.getSubNbt(KEY) != null;
    }

    /** An empty bucket that remembers its settings (refills keep them). */
    public static boolean isRealFluidEmpty(ItemStack stack) {
        return stack.isOf(Items.BUCKET) && stack.getSubNbt(KEY) != null;
    }

    public static FluidProps read(ItemStack stack) {
        NbtCompound tag = stack.getSubNbt(KEY);
        if (tag == null) {
            return stack.isOf(Items.LAVA_BUCKET) ? FluidProps.preset("lava") : FluidProps.preset("water");
        }
        return fromNbt(tag);
    }

    public static void write(ItemStack stack, FluidProps props) {
        stack.setSubNbt(KEY, toNbt(props));
    }

    public static void clear(ItemStack stack) {
        stack.removeSubNbt(KEY);
    }

    public static NbtCompound toNbt(FluidProps props) {
        NbtCompound tag = new NbtCompound();
        for (Map.Entry<String, Object> e : props.copy().sanitize().toMap().entrySet()) {
            Object v = e.getValue();
            if (v instanceof String s) tag.putString(e.getKey(), s);
            else if (v instanceof Integer i) tag.putInt(e.getKey(), i);
            else if (v instanceof Float f) tag.putFloat(e.getKey(), f);
            else if (v instanceof Boolean b) tag.putBoolean(e.getKey(), b);
        }
        return tag;
    }

    public static FluidProps fromNbt(NbtCompound tag) {
        Map<String, Object> m = new HashMap<>();
        for (String key : tag.getKeys()) {
            byte type = tag.getType(key);
            switch (type) {
                case NbtElement.STRING_TYPE -> m.put(key, tag.getString(key));
                case NbtElement.INT_TYPE -> m.put(key, tag.getInt(key));
                case NbtElement.FLOAT_TYPE -> m.put(key, tag.getFloat(key));
                case NbtElement.DOUBLE_TYPE -> m.put(key, tag.getDouble(key));
                case NbtElement.BYTE_TYPE -> m.put(key, tag.getByte(key) != 0);
                default -> { }
            }
        }
        return FluidProps.fromMap(m);
    }
}

package net.realfluids.net;

import net.minecraft.util.Identifier;

/** Channel ids. Client -> server: CONFIGURE, POUR, SCOOP, STATUS. Server -> client: SPAWN, REMOVE. */
public final class Packets {
    public static final String MOD_ID = "realfluids";

    /** C2S: NbtCompound props, boolean enabled. Writes the props onto the held bucket. */
    public static final Identifier CONFIGURE = new Identifier(MOD_ID, "configure");
    /** C2S: x,y,z (double), dir x,y,z (float). Pours the held real-fluid bucket. */
    public static final Identifier POUR = new Identifier(MOD_ID, "pour");
    /** C2S: x,y,z (double), volume (float), NbtCompound props of what was scooped. Fills the held empty bucket. */
    public static final Identifier SCOOP = new Identifier(MOD_ID, "scoop");
    /** C2S: byte flags (1 = submerged, 2 = in hot fluid). Lets the server cancel fall damage / burn. */
    public static final Identifier STATUS = new Identifier(MOD_ID, "status");

    /** S2C: x,y,z (double), dir x,y,z (float), NbtCompound props. Every nearby client simulates the pour. */
    public static final Identifier SPAWN = new Identifier(MOD_ID, "spawn");
    /** S2C: x,y,z (double), radius (float), max particles (int). Another player scooped here. */
    public static final Identifier REMOVE = new Identifier(MOD_ID, "remove");

    public static final double SYNC_RADIUS = 160.0;

    private Packets() { }
}
